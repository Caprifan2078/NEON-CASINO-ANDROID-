# Handoff — NEON CASINO Android v1.8.9 CI R2

База: существующий проект `BUILD_READY_ANDROID_PROJECT` из `NEON_CASINO_v1_8_9_ANDROID_CI_HOTFIX_SOURCES.zip`.
Все 44 игры, баланс, HTML/CSS/JS и формат сохранений НЕ изменены. Точка продолжения — Android официальная APK-сборка.

**Изменённые файлы:** `app/build.gradle`, `.github/workflows/build-android.yml`, `tests/android_smoke.sh`, `tests/test_android_smoke_script.cjs`, `tests/test_android_release_gates.cjs`, `package.json`; добавлены `app/src/androidTest/java/com/neon/play/simulator/NeonWebViewInstrumentedTest.java`, `tests/test_android_instrumentation_gates.cjs`, актуализирована QA документация.

**Рабочие тесты:** `npm test && npm run audit && python3 tests/test_v189_browser.py && python3 tools/check_mobile.py && python3 tools/check_project.py`.

**Сборка/инструментальные тесты:** пока BLOCKED отсутствием Gradle и Android SDK/ADB. На GitHub используйте workflow в `.github/workflows/build-android.yml`; при отсутствии стабильного QA-ключа создаётся уникальный новый ID с `ci<run_id>`, а при наличии соответствующего QA-ключа — прежний `qa182`.

**Следующий шаг:** загрузить актуальные исходники в QA-ветку существующего GitHub-репозитория (не трогать `main`), выполнить GitHub Actions и разобрать фактические логи Gradle/emulator. Не выдавать результат за APK без прошедшего CI. Перед установкой сохранять JSON-профиль.
