 'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm'),crypto=require('node:crypto');
const js=fs.readFileSync('web/app.js','utf8');
const store={},elements=new Map();
function node(id){if(!elements.has(id))elements.set(id,{innerHTML:'',textContent:'',hidden:false,style:{},value:'',dataset:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},querySelectorAll(){return[]},addEventListener(){},appendChild(){},remove(){},getContext(){return new Proxy({},{get(){return()=>{}}})}});return elements.get(id)}
const ctx={console,JSON,Math,Number,Array,Set,Map,String,Date,Intl,crypto:crypto.webcrypto,performance:{now:()=>0},setTimeout(){return 1},setInterval(){return 1},clearInterval(){},clearTimeout(){},requestAnimationFrame:f=>f(),document:{getElementById:node,querySelector(){return null},querySelectorAll(){return[]},createElement(){return node('new')},body:{addEventListener(){},appendChild(){},classList:{toggle(){}}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},localStorage:{getItem:k=>store[k]??null,setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},confirm:()=>true};vm.createContext(ctx);vm.runInContext(js,ctx);const run=q=>vm.runInContext(q,ctx);
assert.equal(run('GAMES.length'),44);
run("setCasinoView('hall');hallZone='roulette';applyCasinoView()");
assert.equal(node('hallStage').innerHTML.includes('hall-quick-section'),false);
run("toggleFavorite('baccarat');rememberRecent('slots');applyCasinoView()");
const hall=node('hallStage').innerHTML;
assert.match(hall,/hall-quick-section/);assert.match(hall,/data-game="baccarat"/);assert.match(hall,/data-game="slots"/);
assert.match(hall,/data-action="hall-favorite"/);
const zone=run("hallZone='cards';casinoHallHTML()");assert.match(zone,/hall-station/);
// all 44 games are present in zoned access, favorites don't rewrite catalog
assert.equal(run('new Set(CASINO_ZONES.flatMap(z=>z.games)).size'),44);
const good={type:'slots',cells:['🍒','🍒','🍒','🍋','🍀','🔔','💎','🍀','🔔'],lines:[0]};
assert.equal(run('safeRoundReplay('+JSON.stringify(good)+').lines[0]'),0);
const tampered={...good,lines:[1]};assert.equal(run('safeRoundReplay('+JSON.stringify(tampered)+')'),null);
assert.equal(run('safeRoundReplay({type:"slots",cells:["bad"],lines:[]})'),null);
run("state.reserved=100;state.balance-=100;settle('Слоты',100,200,'1 линия',"+JSON.stringify(good)+")");
assert.equal(run('state.journal[0].replay.type'),'slots');
assert.match(run('roundReplayHTML(combinedJournal()[0])'),/replay-slots/);
const old=run('state.balance');run('roundReplayHTML(combinedJournal()[0])');assert.equal(run('state.balance'),old);
// Day summary really opens on finishing; counters are saved from the completed day only.
run("switchMode('daily');dailyProgress.rounds=3;dailyProgress.wagered=250;dailyProgress.paid=400;state.balance=1150");
assert.equal(run("finishDailyDay('manual')"),true);
assert.equal(run('state.modal'),'day-summary');
assert.equal(run('dailyProgress.history[0].paid'),400);
assert.equal(run('dailyProgress.history[0].wagered'),250);
assert.equal(run('state.balance'),1000);
assert.match(node('modalHost').innerHTML,/Итог игрового дня/);
assert.match(node('modalHost').innerHTML,/Продолжить/);
assert.equal(run('snapshot().version'),5);
console.log('PASS v1.8.7 hall favorites + recent shortcuts, validated reel replay and day summary');
