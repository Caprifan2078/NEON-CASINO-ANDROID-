const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const project=path.resolve(__dirname,'..');
const windowsWeb=path.resolve(project,'../BUILD_READY_WINDOWS_LAUNCHER/web');
const windowsPresent=fs.existsSync(windowsWeb);
// Android's standalone GitHub checkout has no Windows launcher beside it.
// Always verify Android assets; verify cross-platform bytes when the sibling exists.
for(const file of ['app.js','app.css','index.html','sw.js','icon-192.png','icon-512.png','icon.svg','manifest.webmanifest']){
 const web=fs.readFileSync(path.join(project,'web',file));
 assert.deepEqual(web,fs.readFileSync(path.join(project,'app/src/main/assets/web',file)),file+' Android assets differ');
 if(windowsPresent){
  assert.deepEqual(web,fs.readFileSync(path.join(windowsWeb,file)),file+' Windows assets differ');
 }
}
if(!windowsPresent) console.log('SKIP optional Windows resource comparison: Android-only checkout');
const css=fs.readFileSync(path.join(project,'web/app.css'),'utf8');
for(const rule of ['.topbar #menuButton{min-width:44px;min-height:44px',' .game-area .chip-button{min-width:44px;min-height:44px']) assert(css.includes(rule),rule);
const version=require('../package.json').version;
assert(fs.readFileSync(path.join(project,'app/build.gradle'),'utf8').includes(`versionName '${version}'`));
assert(fs.readFileSync(path.join(project,'web/app.js'),'utf8').includes(`version:'${version}'`));
assert(fs.readFileSync(path.join(project,'web/index.html'),'utf8').includes(version));
console.log('PASS shared Android assets, current version and touch target source guards');
