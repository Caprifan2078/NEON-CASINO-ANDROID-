'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const src=fs.readFileSync('web/app.js','utf8');
function launch(seed={}){
 const store={...seed},nodes=new Map();
 function el(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',className:'',style:{},dataset:{},disabled:false,clientWidth:440,hidden:false,classList:{add(){},remove(){},toggle(){}},querySelectorAll(){return []},querySelector(){return null},setAttribute(){},appendChild(){},click(){},remove(){},addEventListener(){},getContext(){return new Proxy({}, {get(){return ()=>{}}})}});return nodes.get(id)}
 const c={Math,JSON,Number,Date,Array,Set,Map,Object,String,Intl,console,crypto:crypto.webcrypto,Blob,performance:{now:()=>1},setTimeout(){return {}},setInterval(){return {}},clearInterval(){},clearTimeout(){},requestAnimationFrame(fn){fn()},localStorage:{getItem(k){return store[k]||null},setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},document:{getElementById:el,querySelector(){return null},querySelectorAll(){return []},createElement(){return el('new'+Math.random())},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},confirm(){return true},URL:{createObjectURL(){return 'blob:backup'},revokeObjectURL(){}}};
 vm.createContext(c);vm.runInContext(src,c,{filename:'app.js'});
 return {run(q){return vm.runInContext(q,c)},store,c,el};
}
const a=launch(),run=a.run;
assert.equal(run('GAMES.length'),44);
assert.equal(run('window.NEON_INFO.version'),'1.8.9');
let order=Array.from(run('sortedGamesForNavigation().map(x=>x.id)'));
assert.equal(order.length,44);assert.equal(new Set(order).size,44);
assert.equal(order[0],'slots');assert.equal(order[1],'slots5');
assert(order.indexOf('roulette')<order.indexOf('fantan'));
assert(order.indexOf('blackjack')<order.indexOf('rps'));
run("toggleFavorite('fantan');toggleFavorite('rps')");
order=Array.from(run('sortedGamesForNavigation().map(x=>x.id)'));
assert.deepEqual(order.slice(0,2),['fantan','rps']);
assert.deepEqual(JSON.parse(a.store['neon-casino-favorites-v1']),['fantan','rps']);
run("toggleFavorite('fantan')");
order=Array.from(run('sortedGamesForNavigation().map(x=>x.id)'));
assert.equal(order[0],'rps');assert.equal(order[1],'slots');
const reload=launch({'neon-casino-favorites-v1':a.store['neon-casino-favorites-v1']});
assert.equal(reload.run('sortedGamesForNavigation()[0].id'),'rps');
assert.match(a.el('featuredGames').innerHTML,/data-game="rps"/);
// Lifetime analytics must remain independent of free-chip top-ups.
run('addChips(1000000)');assert.equal(run('state.recordWin'),0);
run("state.rouletteUseCustom=true;state.rouletteCustomStake='20000';rouletteBet('number','17')");
assert.equal(run('state.reserved'),20000);
run("settle('Рулетка',20000,720000,'17');rt.bets=[]");
assert.equal(run('state.recordWin'),700000);
assert.equal(run('state.lifetime.paid-state.lifetime.wagered'),700000);
const chart=run('profileTrendHTML([{day:"2026-10-29",paid:720000,wagered:20000},{day:"2026-10-28",paid:0,wagered:5000}])');
assert.match(chart,/trend-grid/);assert.match(chart,/2026-10-29/);assert.match(chart,/trend-neg/);
assert.match(run("profileTab='overview';profileHTML()"),/ЛУЧШИЙ ЗАФИКСИРОВАННЫЙ РАУНД/);
assert.equal(run('state.recordLoss'),0);
const save=JSON.parse(run('JSON.stringify(snapshot())'));
assert.equal(save.version,5);assert.equal(save.profiles.free.recordWin,700000);
const reopened=launch({'neon-casino-local-v1':a.store['neon-casino-local-v1']});
assert.equal(reopened.run('state.recordWin'),700000);
// Roulette repeat and double require real reservations, never produce free chips.
run("state.rouletteUseCustom=true;state.rouletteCustomStake='5000';rouletteBet('color','red')");
assert.equal(run('rt.bets.length'),1);
run('rouletteDouble()');assert.equal(run('rt.bets.length'),2);
assert.equal(run('state.reserved'),10000);
run('rouletteDouble()');assert.equal(run('rt.bets.length'),4);
assert.equal(run('state.reserved'),20000);
const beforeSpin=run('state.balance');
// Simulate the completed round's only transition, bypassing animation's timer.
run('lastRouletteBets=rt.bets.map(b=>({...b}));const stake=rt.bets.reduce((n,b)=>n+b.amount,0);rt.bets=[];settle("Рулетка",stake,0,"red")');
assert.equal(run('state.reserved'),0);
run('rouletteRepeat()');assert.equal(run('rt.bets.length'),4);
assert.equal(run('state.reserved'),20000);
assert.equal(run('state.balance'),beforeSpin-20000);
// Repeating with bets already on table must not debit again.
const balance=run('state.balance');run('rouletteRepeat()');assert.equal(run('state.balance'),balance);
// Wallet write failure must leave no duplicate bet on the table.
run('state.balance=0');const pending=run('state.reserved');run('rouletteDouble()');
assert.equal(run('state.reserved'),pending);assert.equal(run('rt.bets.length'),4);
run('resetRuntime()');assert.equal(run('lastRouletteBets.length'),0);
assert.equal(run('state.recordLoss'),20000);
console.log('PASS v1.8.3: ranked 44 games, persistent favorite priority, zero fake popularity telemetry, records, day graph, atomic repeat/double');
