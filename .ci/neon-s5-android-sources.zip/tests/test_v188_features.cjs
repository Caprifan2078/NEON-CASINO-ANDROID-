'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const source=fs.readFileSync('web/app.js','utf8');
function boot(seed={},opts={}){
 const store={...seed},nodes=new Map();
 function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',hidden:false,style:{},value:'',classList:{add(){},remove(){},toggle(){}},setAttribute(){},querySelectorAll(){return[]},addEventListener(){},appendChild(){},remove(){},getContext(){return new Proxy({},{get(){return()=>{}}})}});return nodes.get(id)}
 const ctx={console,Math,JSON,Number,Date,Array,Set,Map,Object,String,Intl,crypto:crypto.webcrypto,requestAnimationFrame:f=>f(),performance:{now:()=>1},setTimeout(){return 1},setInterval(){return 1},clearInterval(){},clearTimeout(){},document:{getElementById:el,querySelector(){return null},querySelectorAll(){return []},createElement(){return el('new')},body:{addEventListener(){},appendChild(){},classList:{toggle(){}}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},localStorage:{getItem:k=>store[k]??null,setItem(k,v){if(opts.failCheckpoint && k==='neon-casino-preimport-v1')throw Error('quota');store[k]=v},removeItem(k){delete store[k]}},confirm:()=>true};
 vm.createContext(ctx);vm.runInContext(source,ctx);return{store,el,run:q=>vm.runInContext(q,ctx)};
}
const a=boot(),run=a.run;
run("setCasinoView('hall');hallZone='roulette'");
assert.match(run('casinoHallHTML()'),/hallSearchInput/);
run("setHallQuery('баккара')");
let html=a.el('hallStage').innerHTML;
assert.match(html,/data-game="baccarat"/);
assert.doesNotMatch(html,/data-game="roulette"/);
assert.match(html,/1 из 44/);
run("setHallQuery('НЕТТАКОЙИГРЫ')");
assert.match(a.el('hallStage').innerHTML,/Ничего не найдено/);
run("setHallQuery('')");
assert.match(a.el('hallStage').innerHTML,/Салон рулетки/);
assert.equal(run('GAMES.length'),44);
// Backups of BOTH wallets/preferences before replacement. Manual granting is never income.
run("setCasinoView('casual')");run('state.balance=777;save()');
run("toggleFavorite('keno')");
const before=JSON.parse(run('JSON.stringify(snapshot())'));
const incoming=structuredClone(before);incoming.balance=123;incoming.profiles.free.balance=123;incoming.preferences.favorites=['roulette'];incoming.preferences.view='hall';
const incomingJSON=JSON.stringify(incoming);
assert.equal(run('loadBackup('+JSON.stringify(incomingJSON)+')'),true);
assert.equal(run('state.balance'),123);assert.equal(a.store['neon-casino-view-v1'],'hall');
assert.ok(a.store['neon-casino-preimport-v1']);
assert.equal(JSON.parse(a.store['neon-casino-preimport-v1']).profiles.free.balance,777);
// Pre-import checkpoint survives a simulated app restart.
const rebootStore={...a.store};delete rebootStore['neon-casino-active-instance-v1'];
const reboot=boot(rebootStore);assert.equal(reboot.run('state.balance'),123);assert.equal(reboot.run('preImportBackup()!==null'),true);

assert.match(run("walletUndoHTML()"),/Вернуть состояние до импорта/);
assert.equal(run('restorePreImportBackup()'),true);
assert.equal(run('state.balance'),777);assert.equal(a.store['neon-casino-view-v1'],'casual');
assert.equal(run("favoriteGames.has('keno')"),true);
assert.equal(a.store['neon-casino-preimport-v1'],undefined);
const failed=boot({}, {failCheckpoint:true});
failed.run('state.balance=987;save()');
const badImport=JSON.parse(failed.run('JSON.stringify(snapshot())'));badImport.balance=55;badImport.profiles.free.balance=55;
assert.throws(()=>failed.run('loadBackup('+JSON.stringify(JSON.stringify(badImport))+')'),/страховочн|копи|недоступ/i);
assert.equal(failed.run('state.balance'),987);
console.log('PASS v1.8.8 hall global search and one-step pre-import safety restore');
