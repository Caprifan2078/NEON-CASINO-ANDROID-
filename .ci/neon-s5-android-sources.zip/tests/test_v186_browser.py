"""Live Chromium checks for both casino UI modes, all game tabs and replay."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text())
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text();js=(web/'app.js').read_text();errors=[]
def load(page):
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate('''()=>{const store={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>store[k]||null,setItem(k,v){store[k]=v},removeItem(k){delete store[k]}}});window.__getStore=()=>store}''')
 page.add_script_tag(content=js)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,640),(390,844),(1440,900)]:
  context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
  page=context.new_page();page.on('pageerror',lambda e,w=width:errors.append(f'{w}: {e}'))
  load(page)
  assert page.evaluate('GAMES.length')==44
  assert page.evaluate('casinoView')=='casual'
  page.locator('[data-action="casino-view"][data-value="hall"]').click()
  assert page.locator('#hallStage').is_visible()
  assert page.locator('#featuredSection').is_hidden()
  assert page.evaluate('casinoView')=='hall'
  for z in ['roulette','cards','slots','lucky']:
   page.locator(f'[data-action="hall-zone"][data-value="{z}"]').click()
   assert page.locator('#hallStage .hall-table').count()>=4
  page.locator('[data-action="hall-zone"][data-value="cards"]').click()
  page.locator('[data-action="hall-open"][data-game="holdem"]').click()
  assert page.evaluate('state.game')=='holdem'
  assert page.evaluate('state.balance')==50000
  page.locator('[data-action="casino-view"][data-value="casual"]').click()
  assert page.locator('#hallStage').is_hidden()
  assert page.locator('#featuredSection').is_visible()
  # all games have a renderable working panel
  assert page.evaluate('''()=>GAMES.every(g=>{navigate(g.id);return document.getElementById('gameArea').innerHTML.length>100})''')
  # new round archive with structured data; do not mutate the wallet by viewing
  page.evaluate('''()=>{navigate('roulette');rouletteBet('number','17');let n=rt.bets[0].amount;settle('Рулетка',n,0,'Число 4',{type:'roulette',number:4,bets:rt.bets});rt.bets=[]}''')
  page.locator('#profileButton').click()
  page.locator('[data-action="profile-tab"][data-value="journal"]').click()
  page.locator('[data-action="replay-round"]').first.click()
  assert page.locator('.replay-card').count()==1
  assert page.locator('.replay-bets').inner_text().find('17')!=-1
  balance=page.evaluate('state.balance')
  page.locator('[data-action="close-modal"]').click()
  assert page.evaluate('state.balance')==balance
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1'),f'overflow {width}'
  if width==390:
   page.locator('[data-action="casino-view"][data-value="hall"]').click()
   page.screenshot(path='/mnt/data/neon_v186_work/HALL_MOBILE.png',full_page=True)
  if width==1440:
   page.locator('[data-action="casino-view"][data-value="hall"]').click()
   page.screenshot(path='/mnt/data/neon_v186_work/HALL_DESKTOP.png',full_page=True)
  context.close()
 browser.close()
assert not errors,errors
print('PASS v1.8.6 Chromium: 3 viewports, two presentation modes, 44 renders, all hall zones, round replay, no pageerrors/overflow')
