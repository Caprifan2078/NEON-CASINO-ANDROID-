"use strict";
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root,file),'utf8');
const gradle = read('app/build.gradle');
const smoke = read('tests/android_smoke.sh');
const workflows = ['.github/workflows/build-android.yml'];
assert.match(gradle,/neonQaBaselineCode/);
assert.match(gradle,/versionCode\(neonQaBaselineCode == null \? 190 : 189\)/);
assert.match(smoke,/NEON_PREVIOUS_APK/);
assert.match(smoke,/prior_package.*package/);
assert.match(smoke,/prior_code.*final_code/);
assert.match(smoke,/signing certificates differ/);
assert.match(smoke,/adb install -r "\$first_apk"/);
assert.match(smoke,/adb install -r "\$apk"/);
assert.match(smoke,/verifyPersistentWalletCheckpoint/);
for(const workflow of workflows){
 const yml=read(workflow);
 assert.match(yml,/neonQaBaselineCode=189/);
 assert.match(yml,/NEON_PREVIOUS_APK:/);
 assert.match(yml,/android-emulator-runner/);
 assert.ok(yml.indexOf('neonQaBaselineCode=189') < yml.indexOf('android-emulator-runner'));
}
console.log('PASS: lower-to-higher versionCode upgrade gated on package, signer and persisted-wallet check (source only; not emulator).');
