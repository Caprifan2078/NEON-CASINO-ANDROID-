"""Browser QA v1.8.3: favorite priority, one wallet debit, roulette repeat, profile graph."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text())
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text();js=(web/'app.js').read_text()
def load(page):
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate('''()=>{const data={};Object.defineProperty(window,'localStorage',{value:{getItem(k){return data[k]||null},setItem(k,v){data[k]=v},removeItem(k){delete data[k]}}});window.__dump=()=>data;}''')
 page.add_script_tag(content=js)
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,520),(320,640),(390,844),(667,360),(1440,900)]:
  ctx=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
  page=ctx.new_page();page.on('pageerror',lambda e,w=width:errors.append(f'{w}: {e}'))
  load(page)
  assert page.locator('#featuredGames .feature-game').count()==6
  assert page.evaluate('sortedGamesForNavigation()[0].id')=='slots'
  if width<=960:
   page.locator('#menuButton').click()
  target=page.locator('#gameNav [data-action="favorite-toggle"][data-game="fantan"]')
  target.click()
  assert page.evaluate('sortedGamesForNavigation()[0].id')=='fantan'
  assert page.locator('#gameNav .nav-item').first.get_attribute('data-game')=='fantan'
  assert page.locator('#featuredGames .feature-game').first.get_attribute('data-game')=='fantan'
  if width<=960:
   page.locator('#closeSidebar').click()
  page.locator('#rouletteCustomAmount').fill('100')
  page.locator('[data-action="roulette-bet"][data-type="number"][data-value="17"]').click()
  assert page.evaluate('state.reserved')==100
  page.locator('[data-action="roulette-double"]').click()
  assert page.evaluate('state.reserved')==200
  assert page.evaluate('rt.bets.length')==2
  page.locator('[data-action="roulette-spin"]').click()
  page.wait_for_timeout(520)
  assert page.evaluate('state.reserved')==0
  assert page.evaluate('state.lifetime.rounds')==1
  assert page.locator('[data-action="roulette-repeat"]').is_enabled()
  before=page.evaluate('state.balance')
  page.locator('[data-action="roulette-repeat"]').click()
  assert page.evaluate('state.reserved')==200
  assert page.evaluate('state.balance')==before-200
  page.locator('[data-action="roulette-clear"]').click()
  assert page.evaluate('state.balance')==before
  page.locator('#profileButton').click()
  assert page.locator('.trend-grid').count()==1
  assert page.locator('#profile-lifetime').is_visible()
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2'),f'overflow: {width}'
  if width==390:page.screenshot(path='/mnt/data/neon_v183/profile_v183.png')
  if width==1440:page.screenshot(path='/mnt/data/neon_v183/desktop_v183.png',full_page=True)
  ctx.close()
 browser.close()
assert not errors,errors
print('PASS v1.8.3 Chromium 5 viewports; favorite priority, roulette double/spin/repeat, chart, no page errors or overflows')
