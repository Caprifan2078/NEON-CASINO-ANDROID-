'use strict';
// Tests the QA script's control flow with a MOCK adb. This is NOT an Android emulator test.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'neon-android-ci-smoke-'));
try {
  const dir = path.join(tmp, 'app/build/outputs/apk/debug');
  const androidTestDir = path.join(tmp, 'app/build/outputs/apk/androidTest/debug');
  const bin = path.join(tmp, 'bin');
  fs.mkdirSync(dir, {recursive:true});
  fs.mkdirSync(androidTestDir, {recursive:true});
  fs.mkdirSync(bin);
  // Deliberately fake: this only exercises CI shell orchestration, never APK validity.
  fs.writeFileSync(path.join(dir, 'app-debug.apk'), 'MOCK-DO-NOT-INSTALL');
  fs.writeFileSync(path.join(androidTestDir,'app-debug-androidTest.apk'), 'MOCK-NOT-REAL');
  fs.copyFileSync(path.join(__dirname, '..', 'package.json'), path.join(tmp, 'package.json'));
  fs.copyFileSync(path.join(__dirname, 'android_smoke.sh'), path.join(tmp, 'android_smoke.sh'));
  const aaptDir = path.join(tmp, 'android-sdk/build-tools/35.0.0');
  fs.mkdirSync(aaptDir, {recursive:true});
  const aapt = path.join(aaptDir, 'aapt');
  fs.writeFileSync(aapt, `#!/usr/bin/env bash
set -euo pipefail
code=190
pkg='com.neon.play.simulator.ci123456'
if [[ "$*" == *neon-baseline.apk* ]]; then
  code=189
  if [[ "\${MOCK_BAD_PACKAGE:-}" == '1' ]]; then pkg='com.neon.play.simulator.OTHER'; fi
fi
if [[ "\${MOCK_BAD_VERSION:-}" == '1' ]]; then code=190; fi
printf "%s\n" "package: name='\${pkg}' versionCode='\${code}' versionName='1.8.9'" "launchable-activity: name='com.neon.play.simulator.MainActivity'"
`);
  fs.chmodSync(aapt, 0o700);
  const apksigner = path.join(aaptDir, 'apksigner');
  fs.writeFileSync(apksigner, `#!/usr/bin/env bash
set -euo pipefail
sig='ABCDEF1234'
if [[ "\${MOCK_BAD_SIGNATURE:-}" == '1' && "$*" == *neon-baseline.apk* ]]; then sig='DIFFERENT'; fi
printf 'Signer #1 certificate SHA-256 digest: %s\n' "$sig"
`);
  fs.chmodSync(apksigner, 0o700);
  const adb = path.join(bin, 'adb');
  fs.writeFileSync(adb, `#!/usr/bin/env bash
set -euo pipefail
echo "$*" >> "$MOCK_ADB_LOG"
case "$*" in
  'install -r '*) echo 'Success';;
  'shell am start -W '*) echo 'Status: ok';;
  'shell pidof '*) echo 1234;;
  'shell am instrument -w '*)
    if [[ "\${MOCK_FAIL_VERIFY:-}" == '1' && "$*" == *verifyPersistentWalletCheckpoint* ]]; then
      printf '%s\n' 'FAILURES!!!' 'INSTRUMENTATION_CODE: 0'
    else
      echo 'OK (1 test)'
    fi
    ;;
  'logcat -d -s NEON_QA:I '*) echo "WEB_READY_v${require('../package.json').version}_games44";;
  *) :;;
esac
`);
  fs.chmodSync(adb, 0o700);
  const log = path.join(tmp, 'calls.log');
  const r = cp.spawnSync('bash', ['android_smoke.sh'], {cwd:tmp,encoding:'utf8',timeout:10000,env:{...process.env,PATH:bin+path.delimiter+process.env.PATH,MOCK_ADB_LOG:log,ANDROID_HOME:path.join(tmp,'android-sdk')}});
  assert.equal(r.status,0,`Mock smoke must succeed:\n${r.stdout}\n${r.stderr}`);
  assert.match(r.stdout,/first_launch/);
  assert.match(r.stdout,/second_launch/);
  const calls = fs.readFileSync(log,'utf8').split('\n');
  assert.equal(calls.filter(x=>x.startsWith('install -r ')).length,3,'Must install app, instrumented tests, and reinstall app');
  assert.equal(calls.filter(x=>x.includes('am instrument -w ')).length,3,'Must run ordered three instrumentation checks');
  assert.equal(calls.filter(x=>x.startsWith('shell am start -W ')).length,2,'Must launch twice');
  assert.ok(calls.some(x=>x.includes('com.neon.play.simulator.ci123456')),
    'Must use actual APK package ID rather than the old static QA package');
  // A real JUnit failure may be reported while adb itself exits with code zero.
  // It MUST stop the release pipeline rather than being interpreted as success.
  const bad = cp.spawnSync('bash', ['android_smoke.sh'], {cwd:tmp, encoding:'utf8',timeout:10000,
    env:{...process.env,PATH:bin+path.delimiter+process.env.PATH,MOCK_ADB_LOG:log,MOCK_FAIL_VERIFY:'1',ANDROID_HOME:path.join(tmp,'android-sdk')}});
  assert.notEqual(bad.status,0,'JUnit FAILURE with adb exit code 0 must be rejected');
  assert.match(bad.stderr,/did not pass/,'Smoke script must report the instrument failure');
  const baseline = path.join(tmp, 'neon-baseline.apk');
  fs.writeFileSync(baseline, 'MOCK-BASELINE-DO-NOT-INSTALL');
  const upgrade = cp.spawnSync('bash', ['android_smoke.sh'], {cwd:tmp,encoding:'utf8',timeout:10000,
    env:{...process.env,PATH:bin+path.delimiter+process.env.PATH,MOCK_ADB_LOG:log,
      NEON_PREVIOUS_APK:baseline,ANDROID_HOME:path.join(tmp,'android-sdk')}});
  assert.equal(upgrade.status, 0,`VersionCode upgrade rehearsal must pass:\n${upgrade.stdout}\n${upgrade.stderr}`);
  assert.match(upgrade.stdout,/189 -> 190/);
  const upgradeCalls = fs.readFileSync(log,'utf8').split('\n').filter(x=>x.startsWith('install -r '));
  assert.ok(upgradeCalls.some(x=>x.endsWith('neon-baseline.apk')),'Real upgrade must first install lower code');
  for (const [flag, message] of [
    ['MOCK_BAD_SIGNATURE','signing certificates differ'],
    ['MOCK_BAD_VERSION','must be lower than final'],
    ['MOCK_BAD_PACKAGE','package mismatch']
  ]) {
    const neg = cp.spawnSync('bash',['android_smoke.sh'], {cwd:tmp,encoding:'utf8',timeout:10000,
      env:{...process.env,PATH:bin+path.delimiter+process.env.PATH,MOCK_ADB_LOG:log,
        NEON_PREVIOUS_APK:baseline,[flag]:'1',ANDROID_HOME:path.join(tmp,'android-sdk')}});
    assert.notEqual(neg.status,0,`Must reject ${flag}`);
    assert.ok(neg.stderr.includes(message),`Expected ${message}: ${neg.stderr}`);
  }
  console.log('PASS mock versionCode 189 -> 190; wrong signer, package or non-upgrade blocked before installation');
  console.log('PASS mocked Android smoke: 3 instrumented stages; a failed persistence assertion BLOCKS release (not an emulator)');
} finally {
  fs.rmSync(tmp,{recursive:true,force:true});
}
