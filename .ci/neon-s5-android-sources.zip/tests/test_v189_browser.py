"""Chromium v1.8.9: verify rendered ticket, staggered slots, two views and mobile layout."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
root=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','', (root/'index.html').read_text()).replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(root/'app.css').read_text(); js=(root/'app.js').read_text()
errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(240,680),(390,844),(1440,900)]:
  context=browser.new_context(viewport={'width':w,'height':h},reduced_motion='reduce')
  page=context.new_page();page.set_default_timeout(10000)
  page.on('pageerror', lambda err, width=w: errors.append(f'{width}: {err}'))
  page.set_content(html);page.add_style_tag(content=css)
  page.evaluate('''()=>{const data={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>data[k]??null,setItem(k,v){data[k]=v},removeItem(k){delete data[k]}}})}''')
  page.add_script_tag(content=js)
  assert page.evaluate('window.NEON_INFO.version')=='1.8.9'
  assert page.evaluate('GAMES.length')==44
  # deterministic roulette outcome 0, for checks without relying on probability
  page.evaluate('rnd=()=>0;qualityMode="lite"')
  page.locator('[data-action="roulette-bet"][data-type="number"][data-value="0"]').click()
  starting=page.evaluate('state.balance + state.reserved')
  page.locator('[data-action="roulette-spin"]').click()
  page.locator('.roulette-ticket').wait_for(timeout=8000)
  assert 'ЧЕК ПОСЛЕДНЕГО ВРАЩЕНИЯ' in page.locator('.roulette-ticket').inner_text()
  assert 'Выигравшие ставки: 1' in page.locator('.roulette-ticket').inner_text()
  assert page.evaluate('state.balance')==starting+3500
  assert page.evaluate('state.stats.rounds')==1
  page.locator('[data-action="casino-view"][data-value="hall"]').click()
  assert page.locator('.hall-stage:not([hidden])').count()==1
  page.locator('[data-action="casino-view"][data-value="casual"]').click()
  assert page.locator('.roulette-ticket').count()==1
  # Switch via the real menu action; verify progressive reels and stored journal.
  page.evaluate('''()=>document.querySelector('[data-action="nav"][data-game="slots"]').click()''')
  assert page.evaluate('state.game')=='slots'
  page.locator('[data-action="slots-spin"]').click()
  page.wait_for_function('rt.slots && !rt.slots.spinning',timeout=8000)
  assert page.evaluate('rt.slots.lockedColumns.length')==3
  assert page.evaluate('state.reserved')==0
  assert page.evaluate('state.stats.rounds')==2
  assert page.evaluate('state.journal[0].replay.cells.length')==9
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),w
  if w==390:
   page.evaluate("document.querySelector('[data-action=\"nav\"][data-game=\"roulette\"]').click()")
   page.screenshot(path='/mnt/data/neon_v189_work/roulette_ticket_mobile.png',full_page=True)
  context.close()
 browser.close()
assert not errors,errors
print('PASS Chromium v1.8.9: 3 widths, settled ticket, saved slot reels, two hall modes, no JS errors or page overflow')
