"""Chromium smoke: searchable hall and rollback to pre-import state. Offline DOM injection."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text()).replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text();js=(web/'app.js').read_text()
errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,640),(320,700),(390,844),(768,960),(1440,900)]:
  context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
  page=context.new_page();page.set_default_timeout(6500);page.on('pageerror',lambda e,w=width:errors.append(f'{w}: {e}'))
  page.set_content(html);page.add_style_tag(content=css)
  page.evaluate('''()=>{const store={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>store[k]??null,setItem(k,v){store[k]=v},removeItem(k){delete store[k]}}});window.confirm=()=>true}''')
  page.add_script_tag(content=js)
  assert page.evaluate('GAMES.length')==44
  page.locator('[data-action="casino-view"][data-value="hall"]').click()
  search=page.locator('#hallSearchInput');search.fill('баккара')
  assert page.locator('.hall-table').count()==1,(width,page.locator('.hall-table').count())
  assert page.locator('.hall-table[data-game="baccarat"]').count()==1
  assert page.locator('#hallSearchInput').evaluate('(el)=>document.activeElement===el')
  page.locator('[data-action="hall-search-clear"]').click()
  assert page.locator('.hall-table').count()==4
  page.locator('#hallSearchInput').fill('zzzzzzz')
  assert page.locator('.hall-table').count()==0
  assert 'Ничего не найдено' in page.locator('.hall-search-empty').inner_text()
  page.locator('[data-action="hall-zone"][data-value="cards"]').click()
  assert page.locator('.hall-table').count()==14
  page.locator('[data-action="hall-open"][data-game="baccarat"]').first.click()
  assert page.evaluate('state.game')=='baccarat'
  # Test import rollback through wallet action and actual localStorage persistence.
  page.evaluate('''()=>{state.balance=4321;save();window.testBackup=JSON.stringify(snapshot());const other=JSON.parse(window.testBackup);other.profiles.free.balance=12;other.balance=12;loadBackup(JSON.stringify(other));}''')
  assert page.evaluate('state.balance')==12
  page.locator('[data-action="wallet"]').first.click()
  assert page.locator('[data-action="backup-undo"]').count()==1
  page.locator('[data-action="backup-undo"]').click()
  assert page.evaluate('state.balance')==4321
  assert page.locator('[data-action="backup-undo"]').count()==0
  assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),width
  if width in (390,1440):
   page.locator('[data-action="casino-view"][data-value="hall"]').click()
   page.evaluate("document.getElementById('toastHost').innerHTML=''")
   screenshot=Path('/mnt/data/neon_v188_work')/('HALL_MOBILE_v188.png' if width==390 else 'HALL_DESKTOP_v188.png')
   page.screenshot(path=str(screenshot),full_page=True)
  context.close()
 browser.close()
assert not errors,errors
print('PASS Chromium v1.8.8: 5 sizes, focus-preserving search, global result, absent result, cross-zone, import undo, zero JS errors/overflow')
