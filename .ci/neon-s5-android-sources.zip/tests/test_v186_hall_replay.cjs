'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const script=fs.readFileSync('web/app.js','utf8');
function boot(seed={}){
 const store={...seed},nodes=new Map();
 function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',hidden:false,style:{},value:'',dataset:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},querySelectorAll(){return[]},addEventListener(){},appendChild(){},remove(){},getContext(){return new Proxy({}, {get(){return()=>{}}})}});return nodes.get(id)}
 const ctx={console,Math,JSON,Number,Date,Array,Set,Map,Object,String,Intl,crypto:crypto.webcrypto,requestAnimationFrame:f=>f(),performance:{now:()=>1},setTimeout(){return 1},setInterval(){return 1},clearInterval(){},clearTimeout(){},document:{getElementById:el,querySelector(){return null},querySelectorAll(){return []},createElement(){return el('new')},body:{addEventListener(){},appendChild(){},classList:{toggle(){}}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},localStorage:{getItem:k=>store[k]??null,setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},confirm:()=>true};
 vm.createContext(ctx);vm.runInContext(script,ctx);
 return {store,el,run:q=>vm.runInContext(q,ctx)};
}
const x=boot(),r=x.run;
assert.equal(r('GAMES.length'),44);
assert.equal(r('casinoView'),'casual');
assert.equal(r('CASINO_ZONES.flatMap(z=>z.games).length'),44);
assert.equal(r('new Set(CASINO_ZONES.flatMap(z=>z.games)).size'),44);
assert.equal(r('CASINO_ZONES.flatMap(z=>z.games).filter(id=>!GAMES.some(g=>g.id===id)).length'),0);
r("setCasinoView('hall')");
assert.equal(r('casinoView'),'hall');assert.equal(x.store['neon-casino-view-v1'],'hall');
for(const z of ['roulette','cards','slots','lucky']){r(`hallZone='${z}';applyCasinoView()`);assert.match(x.el('hallStage').innerHTML,/hall-table/)}
r("openHallTable('holdem')");assert.equal(r('state.game'),'holdem');
const old=r('state.balance');r("setCasinoView('casual')");assert.equal(r('state.balance'),old);
const saved=JSON.parse(r('JSON.stringify(snapshot())'));assert.equal(saved.preferences.view,'casual');
const b=boot({'neon-casino-view-v1':'hall'});assert.equal(b.run('casinoView'),'hall');
// Verify structured snapshots only preserve genuine settled roulette rounds.
r("state.reserved=150;state.balance-=150;settle('Рулетка',150,0,'Число 4',{type:'roulette',number:4,bets:[{type:'number',value:'1',amount:100},{type:'color',value:'red',amount:50}]})");
assert.equal(r('state.journal[0].replay.bets.length'),2);assert.equal(r('state.journal[0].replay.number'),4);
const before=r('state.balance');const record=r('combinedJournal()[0]');assert.match(r('roundReplayHTML(combinedJournal()[0])'),/Число 1|Число 4/);assert.equal(r('state.balance'),before);
assert.equal(r('safeRoundReplay({type:"roulette",number:37,bets:[]})'),null);
assert.equal(r('safeRoundReplay({type:"roulette",number:2,bets:[{type:"number",value:"1",amount:-2}]})'),null);
const snapshot=r('JSON.stringify(snapshot())');assert.equal(JSON.parse(snapshot).version,5);assert.equal(JSON.parse(snapshot).preferences.view,'casual');
console.log('PASS v1.8.6 hall two modes, 44 games in four zones, preference and wallet, roulette genuine replay, malformed import rejected');
