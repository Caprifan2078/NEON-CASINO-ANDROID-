from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text())
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [320,390,1440]:
  page=browser.new_page(viewport={'width':width,'height':790});page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html);page.add_style_tag(content=(web/'app.css').read_text());page.add_script_tag(content=(web/'app.js').read_text())
  page.locator('[data-action="game-guide"]').first.click()
  page.locator('[data-action="fairness"]').click()
  before=page.evaluate('({balance:state.balance,reserved:state.reserved,rounds:state.stats.rounds})')
  page.locator('[data-action="fairness-test"]').click()
  after=page.evaluate('({balance:state.balance,reserved:state.reserved,rounds:state.stats.rounds})')
  assert before==after,(before,after)
  result=page.evaluate('fairnessSample')
  assert result['draws']==3700 and 0<result['minimum']<=result['maximum']<3700,result
  assert 'не являются независимой сертификацией' in page.locator('.modal-main').inner_text()
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+1'),width
  if width==390:page.screenshot(path='/mnt/data/neon_v185/fairness_mobile.png')
  page.close()
 browser.close()
assert not errors,errors
print('PASS v1.8.6 actual Chromium fairness UI and 3,700 local crypto draws on 3 viewport sizes, wallet unchanged')
