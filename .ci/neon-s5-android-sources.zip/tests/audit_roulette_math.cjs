'use strict';
// Deterministic 37-outcome exhaustive mathematics; NOT a certification of other 43 games.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const src=fs.readFileSync('web/app.js','utf8'),storage={},nodes={};
function el(name){return nodes[name]||=({innerHTML:'',textContent:'',className:'',style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},appendChild(){},remove(){},addEventListener(){},querySelectorAll(){return []},clientWidth:300})}
const c={console,Math,Date,JSON,Intl,Array,Set,Map,Object,Number,String,crypto:crypto.webcrypto,performance:{now:()=>0},setTimeout(){},clearTimeout(){},setInterval(){},clearInterval(){},requestAnimationFrame(fn){fn()},confirm(){return true},localStorage:{getItem(k){return storage[k]||null},setItem(k,v){storage[k]=v},removeItem(k){delete storage[k]}},document:{getElementById:el,createElement(){return el('temp')},querySelector(){return null},querySelectorAll(){return []},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{}};
vm.createContext(c);vm.runInContext(src,c);const r=s=>vm.runInContext(s,c);
const bets=[{type:'number',value:'17'}, {type:'color',value:'red'}, {type:'color',value:'black'}, {type:'low',value:'low'}, {type:'high',value:'high'}, {type:'odd',value:'odd'}, {type:'even',value:'even'}, {type:'dozen',value:'1'}, {type:'column',value:'1'}];
for(const [kind,anchor] of [['split-right',1],['split-up',2],['street',11],['corner',1],['sixline',11]]){
 const group=r(`rouletteGroup('${kind}',${anchor})`);
 bets.push({type:'combo',value:Array.from(group).join(',')});
}
for(const b of bets){const sum=r(`Array.from({length:37},(_,n)=>rouletteWin(${JSON.stringify(b)},n)>0?1+rouletteWin(${JSON.stringify(b)},n):0).reduce((a,b)=>a+b,0)`);assert.equal(sum,36,`RTP != 36/37 for ${JSON.stringify(b)}: ${sum}`)}
// Each of five wheel neighbors is a separate straight-up wager; no 5x free winnings.
const neighbours=Array.from(r('rouletteGroup("neighbors",0)'));assert.equal(neighbours.length,5);assert.equal(new Set(neighbours).size,5);assert.equal(r('RNUM.length'),37);assert.equal(r('new Set(RNUM).size'),37);
const freq=new Array(37).fill(0);for(let i=0;i<37000;i++)freq[r('rnd(37)')]++;
// Loose 6-sigma empirical smoke, not a proof of RNG uniformity or crypto quality.
for(const [i,v] of freq.entries())assert(Math.abs(v-1000)<195,`RNG sample cell ${i} has ${v}, unusually outside smoke tolerance`);
console.log('PASS 14 roulette bet types x 37 outcomes: exact theoretical return 36/37, five neighbors, 37 distinct wheel numbers, crypto.getRandomValues smoke (37k draws). Independent certification NOT performed.');
