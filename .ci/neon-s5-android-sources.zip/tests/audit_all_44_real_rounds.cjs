'use strict';
// User-facing audit: run one actual end-to-end round of every registered game,
// test ledger conservation and persisted per-game accounting, not just existence.
const fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const source=fs.readFileSync('web/app.js','utf8');
const stored={};let clock=1000;
const nodes=new Map(),timers=[],intervals=[];
function el(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',clientWidth:460,parentElement:{clientWidth:460},style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}},setAttribute(){},querySelector(){return null},querySelectorAll(){return []},appendChild(){},addEventListener(){},click(){},remove(){},getContext(){return new Proxy({},{get(){return ()=>{}}})}});return nodes.get(id)}
const c={console,Math,Date,JSON,Intl,Array,Set,Map,Object,Number,String,Blob,crypto:crypto.webcrypto,performance:{now:()=>clock},requestAnimationFrame(fn){fn()},setTimeout(fn,ms=0){const t={fn,ms,active:true};timers.push(t);return t},clearTimeout(t){if(t)t.active=false},setInterval(fn){const t={fn,active:true};intervals.push(t);return t},clearInterval(t){if(t)t.active=false},confirm(){return true},localStorage:{getItem(k){return stored[k]||null},setItem(k,v){stored[k]=v},removeItem(k){delete stored[k]}},document:{getElementById:el,createElement(){return el('tmp-'+nodes.size)},querySelector(){return null},querySelectorAll(){return []},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return{matches:false}}},navigator:{},URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}}};
vm.createContext(c);vm.runInContext(source,c,{filename:'app.js'});
const run=(s)=>vm.runInContext(s,c);const round=JSON.parse(JSON.stringify(run('GAMES.map(x=>({id:x.id,name:x.name}))')));
assert.equal(round.length,44);
const actions={
 roulette:`rouletteBet('number',17);spinRoulette()`,
 blackjack:`dealBlackjack();if(rt.bj?.stage==='playing')bjAction('bj-stand')`,
 wheel:`spinWheel()`,crash:`startCrash();cashCrash()`,slots:`spinSlots()`,
 mines:`startMines();openMine(0);if(rt.mines?.active)cashMines()`,
 plinko:`dropPlinko()`,dice:`rollDice()`,baccarat:`playBaccarat()`,coin:`flipCoin()`,
 keno:`state.kenoPicks=[1,2,3,4,5];playKeno()`,
 poker:`pokerDeal();pokerDraw()`,sicbo:`playSicbo()`,limbo:`playLimbo()`,hilo:`if(!rt.hilo)rt.hilo={current:hiloCard()};state.hiloBet=RANKS.indexOf(rt.hilo.current.rank)<12?'higher':'lower';playHilo()`,
 craps:`rollCraps();for(let i=0;i<120&&rt.craps?.active;i++)rollCraps()`,
 'roulette-us':`vrBet('n:17');vrSpin()`, 'roulette-fr':`vrBet('n:17');vrSpin()`,
 threecard:`threeDeal();threeFinish(true)`,war:`warDeal();if(rt.war?.tied)warResolve(false)`,
 dragontiger:`dragonDeal()`,tower:`towerStart();towerPick(0,0);if(rt.tower?.active)towerCash()`,
 bingo:`bingoPlay()`,lotto:`state.lottoPicks=[1,2,3,4,5,6];lottoPlay()`,
 scratch:`scratchStart();for(let i=0;i<9;i++)scratchOpen(i)`,seven:`sevenRoll()`,dicepoker:`dicePokerRoll()`,treasure:`treasureStart();treasureOpen(0)`,
 andar:`playAndar()`,reddog:`playRedDog()`,pick3:`playPick3()`,bingo90:`playBingo90()`,
 keno80:`state.keno80Picks=[1,2,3,4,5,6];playKeno80()`,cardsuit:`playCardsuit()`,
 ladder:`ladderStart();for(let i=0;i<8&&rt.ladder?.active;i++)ladderNext()`,
 slots5:`playSlots5()`,holdem:`playHoldem()`,letitride:`letItRideStart();letItRideNext(false);letItRideNext(false)`,
 rps:`playRps()`,colors:`playColorDice()`,caribbean:`caribbeanStart();caribbeanFinish(true)`,
 teenpatti:`teenStart();teenFinish(true)`,fantan:`fanPlay()`,crown:`crownPlay()`
};
assert.deepEqual(Object.keys(actions).sort(),round.map(g=>g.id).sort());
function flush(){for(let iteration=0;iteration<60;iteration++){
  const todo=timers.filter(x=>x.active);for(const t of todo){t.active=false;clock+=t.ms;t.fn()}
  const ongoing=intervals.filter(x=>x.active);for(const t of ongoing){clock+=200;t.fn()}
  if(!timers.some(x=>x.active)&&!intervals.some(x=>x.active))break;
}}
const audit=[];
for(const game of round){
 try{
  run(`navigate(${JSON.stringify(game.id)});state.stake=100;state.chip=100;`);
  const before={balance:run('state.balance'),reserved:run('state.reserved'),rounds:run('state.stats.rounds'),wagered:run('state.stats.wagered'),paid:run('state.stats.paid')};
  assert.equal(before.reserved,0,'previous round must not leak reserved funds');
  run(actions[game.id]);flush();
  const after={balance:run('state.balance'),reserved:run('state.reserved'),rounds:run('state.stats.rounds'),wagered:run('state.stats.wagered'),paid:run('state.stats.paid')};
  assert.equal(after.rounds,before.rounds+1,'no round settled or duplicated settlement');
  assert.equal(after.reserved,0,'reserved funds remained after completed round');
  assert.equal(after.balance-before.balance,(after.paid-before.paid)-(after.wagered-before.wagered),'wallet accounting conservation');
  assert(after.wagered-before.wagered>=100,'expected stake missing');
  // Actual export->fresh decode of one game statistics must preserve its ID.
  const persisted=JSON.parse(stored['neon-casino-local-v1']);
  assert.equal(persisted.profiles.free.lifetimeGames[game.id]?.rounds,1,'per-game lifetime game ID not stored under canonical ID');
  const safe=JSON.parse(run(`JSON.stringify(safeProfile(JSON.parse(${JSON.stringify(JSON.stringify(persisted.profiles.free))}),50000).lifetimeGames)`));
  assert.equal(safe[game.id]?.rounds,1,'per-game lifetime data lost by sanitizer on reload');
  audit.push({...game,ok:true,stake:after.wagered-before.wagered,payout:after.paid-before.paid});
 }catch(e){audit.push({...game,ok:false,error:e.message});console.error('FAIL',game.id,e.stack||e);}
}
const errors=audit.filter(x=>!x.ok);
const output={total:audit.length,pass:audit.length-errors.length,fail:errors.length,results:audit};
fs.writeFileSync('tests/AUDIT_44_RESULTS.json',JSON.stringify(output,null,2));
console.log(`AUDIT ${output.pass}/${output.total}`);for(const bad of errors)console.error('FAIL',bad.id,bad.error);
if(errors.length)process.exitCode=1;
