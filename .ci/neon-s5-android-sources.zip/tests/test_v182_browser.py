"""Interactive Chromium smoke for v1.8.3 profile, custom roulette and small screens."""
from pathlib import Path
import re, json
from playwright.sync_api import sync_playwright

web=Path(__file__).resolve().parents[1]/'web'
html=(web/'index.html').read_text()
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',html)
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text()
js=(web/'app.js').read_text()
def load(page, seed=None):
 page.set_content(html)
 page.add_style_tag(content=css)
 page.evaluate('''(seed) => {const data={...seed};Object.defineProperty(window,'localStorage',{value:{getItem(k){return data[k]||null},setItem(k,v){data[k]=v},removeItem(k){delete data[k]}}});window.__dumpData=()=>data;}''',seed or {})
 page.add_script_tag(content=js)
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,520),(320,650),(390,844),(667,360),(1440,900)]:
  context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce',accept_downloads=True)
  page=context.new_page();page.on('pageerror',lambda e,w=width: errors.append(f'{w}: {e}'))
  load(page)
  assert page.locator('#profileButton').is_visible(),f'profile hidden at {width}'
  assert page.locator('#rouletteCustomAmount').count()==1
  page.locator('#profileButton').click()
  assert page.locator('#modalHost #profile-lifetime').count()==1
  for tab in ['days','games','journal','overview']:
   page.locator(f'#modalHost [data-action="profile-tab"][data-value="{tab}"]').click()
   assert page.locator('#profile-lifetime').count()==1
  assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2'),f'overflow profile at {width}'
  if width==390: page.screenshot(path='/mnt/data/neon_v183/preview_profile.png',full_page=False)
  page.locator('#modalHost [data-action="close-modal"]').click()
  page.locator('.topbar .wallet').click()
  page.locator('#modalHost [data-action="add-chips"][data-value="100000"]').click()
  assert page.evaluate('state.balance')==150000
  page.locator('#modalHost [data-action="close-modal"]').click()
  page.locator('#rouletteCustomAmount').fill('75000')
  assert page.evaluate('state.rouletteUseCustom')
  page.locator('[data-action="roulette-bet"][data-type="number"][data-value="17"]').click()
  assert page.evaluate('rt.bets[0].amount')==75000
  assert page.evaluate('state.balance')==75000
  page.locator('#profileButton').click()
  assert page.evaluate('allTimeTotals().wagered')==0
  assert page.evaluate('allTimeTotals().manualGranted')==100000
  page.locator('#modalHost [data-action="close-modal"]').click()
  page.locator('[data-action="roulette-clear"]').click()
  assert page.evaluate('state.balance')==150000
  saved=page.evaluate("window.__dumpData()")
  saved.pop("neon-casino-active-instance-v1",None)
  page.close()
  page=context.new_page();page.on("pageerror",lambda e,w=width: errors.append(f"{w} reload: {e}"))
  load(page,saved)
  assert page.evaluate('state.balance')==150000
  assert page.evaluate('allTimeTotals().manualGranted')==100000
  assert page.evaluate('window.NEON_INFO.version')=='1.8.6'
  if width==390: page.screenshot(path='/mnt/data/neon_v183/preview_mobile.png',full_page=True)
  if width==1440: page.screenshot(path='/mnt/data/neon_v183/preview_desktop.png',full_page=True)
  context.close()
 browser.close()
assert not errors,errors
print('PASS v1.8.3 live Chromium 5 viewports: profile tabs, actual custom wager, refund, manual credit isolation, reload; 0 pageerrors')
