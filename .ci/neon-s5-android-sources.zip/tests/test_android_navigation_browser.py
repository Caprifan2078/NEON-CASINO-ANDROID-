"""Browser preflight for the same 44-game DOM interaction used by Android instrumentation.
Not a substitute for running Android WebView on an emulator.
"""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','', (root/'index.html').read_text())
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
js=(root/'app.js').read_text()
css=(root/'app.css').read_text()
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for width, height in ((240,680),(390,844),(1440,900)):
        context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
        page=context.new_page()
        page.on('pageerror',lambda err: errors.append(str(err)))
        page.set_content(html)
        page.add_style_tag(content=css)
        page.evaluate('''()=>{const kv={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>kv[k]??null,setItem(k,v){kv[k]=v},removeItem(k){delete kv[k]}}})}''')
        page.add_script_tag(content=js)
        result=page.evaluate('''() => {
          const navs=[...document.querySelectorAll('#gameNav [data-action=nav]')];
          if(navs.length!==44) return {error:'incorrect navigation count',count:navs.length};
          const before=state.balance;
          for(const b of navs){
            const id=b.dataset.game;
            b.click();
            if(state.game!==id || !document.querySelector('#gameArea').children.length)
              return {error:'navigation failed',id,active:state.game};
          }
          return {passed:navs.length,unchangedWallet:before===state.balance};
        }''')
        assert result=={'passed':44,'unchangedWallet':True}, (width,result)
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),width
        context.close()
    browser.close()
assert not errors, errors
print('PASS Chromium navigation: 44/44 games on each of 3 viewport sizes; wallet unchanged; no JS exceptions')
