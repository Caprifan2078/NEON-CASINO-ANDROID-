"""Chromium checks v1.8.7 new hall shortcuts, complete day summary, and slot replay."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text()).replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text();js=(web/'app.js').read_text()
errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,640),(320,700),(390,844),(768,960),(1440,900)]:
  context=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
  page=context.new_page();page.on('pageerror',lambda e,w=width:errors.append(f'{w}: {e}'))
  page.set_content(html);page.add_style_tag(content=css)
  page.evaluate('''()=>{const store={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>store[k]||null,setItem(k,v){store[k]=v},removeItem(k){delete store[k]}}})}''')
  page.add_script_tag(content=js)
  assert page.evaluate('GAMES.length')==44
  page.locator('[data-action="casino-view"][data-value="hall"]').click()
  page.locator('[data-action="hall-zone"][data-value="cards"]').click()
  page.locator('.hall-star[data-game="baccarat"]').click()
  assert page.locator('.hall-quick[data-game="baccarat"]').count()==1
  page.locator('.hall-quick[data-game="baccarat"]').click()
  assert page.evaluate('state.game')=='baccarat'
  page.locator('[data-action="hall-zone"][data-value="slots"]').click()
  assert page.locator('.hall-quick[data-game="baccarat"]').count()==1
  page.locator('.hall-table[data-game="slots"]').click()
  assert page.evaluate('state.game')=='slots'
  # Record a controlled *validated* outcome, then replay without money movement.
  page.evaluate('''()=>{const cells=['🍒','🍒','🍒','🍋','🔔','🍀','💎','🍀','🔔'];state.reserved=100;state.balance-=100;settle('Слоты',100,200,'1 линия',{type:'slots',cells,lines:[0]})}''')
  balance=page.evaluate('state.balance')
  page.locator('#profileButton').click()
  page.locator('[data-action="profile-tab"][data-value="journal"]').click()
  page.locator('[data-action="replay-round"]').first.click()
  assert page.locator('.replay-slots .replay-slot').count()==9
  assert page.locator('.replay-slot.won').count()==3
  page.locator('[data-action="close-modal"]').click()
  assert page.evaluate('state.balance')==balance
  # End a day via public UI; use synthetic bookkeeping but real end-day flow.
  page.evaluate('''()=>{switchMode('daily');dailyProgress.rounds=4;dailyProgress.wagered=500;dailyProgress.paid=600;}''')
  page.once('dialog',lambda dialog: dialog.accept())
  page.locator('[data-action="daily-next"]').first.click()
  assert page.locator('.day-summary').count()==1
  assert page.locator('.day-summary').inner_text().find('ДЕНЬ 1 ЗАВЕРШЁН')!=-1
  assert page.evaluate('state.balance')==1000
  page.locator('.day-summary [data-action="close-modal"]').click()
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1'),f'Horizontal overflow on {width}px'
  if width in [390,1440]:
   page.evaluate("setCasinoView('hall');hallZone='cards';applyCasinoView()")
   out=Path('/mnt/data/neon_v187_work')/('HALL_MOBILE_v187.png' if width==390 else 'HALL_DESKTOP_v187.png')
   page.screenshot(path=str(out),full_page=True)
  context.close()
 browser.close()
assert not errors,errors
print('PASS Chromium v1.8.7: 5 screen sizes, cross-zone favorite, recent, archive 9 reels, saved win-lines, daily day summary, no JS errors or overflow')
