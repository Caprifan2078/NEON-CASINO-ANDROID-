'use strict';
// Deterministic 37-outcome exhaustive mathematics; NOT a certification of other 43 games.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const src=fs.readFileSync('web/app.js','utf8'),storage={},nodes={};
function el(name){return nodes[name]||=({innerHTML:'',textContent:'',className:'',style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},appendChild(){},remove(){},addEventListener(){},querySelectorAll(){return []},clientWidth:300})}
const c={console,Math,Date,JSON,Intl,Array,Set,Map,Object,Number,String,crypto:crypto.webcrypto,performance:{now:()=>0},setTimeout(){},clearTimeout(){},setInterval(){},clearInterval(){},requestAnimationFrame(fn){fn()},confirm(){return true},localStorage:{getItem(k){return storage[k]||null},setItem(k,v){storage[k]=v},removeItem(k){delete storage[k]}},document:{getElementById:el,createElement(){return el('temp')},querySelector(){return null},querySelectorAll(){return []},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{}};
vm.createContext(c);vm.runInContext(src,c);const r=s=>vm.runInContext(s,c);
const report=[];
function record(game,variant,expected,limit=1.02){assert(Number.isFinite(expected)&&expected>=0,`${game} ${variant} bad RTP`);report.push({game,variant,rtp:Number(expected.toFixed(6))});assert(expected<limit,`${game} ${variant}: RTP ${(expected*100).toFixed(2)}% suspicious`)}
for(const [variant,nums] of [['us',r('R_US')],['fr',r('R_FR')]]){
 for(const bet of [...Array.from(nums,n=>'n:'+n),...Array.from(r('SIMPLE_ROULETTE_BETS'),x=>x[0])]){
  const payouts=nums.reduce((s,n)=>s+r(`rouletteVariantWin(${JSON.stringify(bet)},${JSON.stringify(n)},${JSON.stringify(variant)},100)`),0);
  record(variant,bet,payouts/(nums.length*100));
 }
}
for(const bet of Array.from(r('SICBO_IDS'))){let sum=0;for(let x=1;x<=6;x++)for(let y=1;y<=6;y++)for(let z=1;z<=6;z++)sum+=r(`sicboMultiplier([${x},${y},${z}],${JSON.stringify(bet)})`);record('sicbo',bet,sum/216,1.2)}
for(const bet of Array.from(r('FAN_BETS'),x=>x[0])){let total=0;for(let n=1;n<=4;n++)total+=r(`fanPayment(${JSON.stringify(bet)},${n},10000)`);record('fantan',bet,total/40000)}
for(const bet of ['under','over','seven','double','even']){let count=0;for(let x=1;x<=6;x++)for(let y=1;y<=6;y++)if(r(`sevenOutcome([${x},${y}],${JSON.stringify(bet)})`))count++;record('seven',bet,count*({under:2.2,over:2.2,seven:5.7,double:5.6,even:1.9}[bet])/36,1.2)}
for(const pick of Array.from(r('COLORS'))){for(const kind of ['any','two','three']){let count=0;const colors=Array.from(r('COLORS'));for(const a of colors)for(const b of colors)for(const d of colors)if(r(`colorDiceWin(${JSON.stringify([a,b,d])},${JSON.stringify(pick)},${JSON.stringify(kind)})`))count++;record('colors',kind,count*r(`COLOR_MULT[${JSON.stringify(kind)}]`)/27)}}
for(let pick=0;pick<6;pick++){let sum=0;for(let a=0;a<6;a++)for(let b=0;b<6;b++)for(let d=0;d<6;d++)sum+=r(`crownPayment([${a},${b},${d}],${pick},100)`);record('crown',String(pick),sum/21600)}
record('coin','heads',1.95/2);record('rps','rock',(1.94+1)/3);
for(const c of [5,10,25,50,90]){const multi=.97*100/c;record('dice',`chance-${c}`,c/100*multi)}
for(const [k,frequency] of [['number',1],['color',18],['dozen',12]]){
 const odds={number:35,color:1,dozen:2}[k];record('roulette',k,frequency*(1+odds)/37);
}
fs.writeFileSync('tests/AUDIT_MATH_RESULTS.json',JSON.stringify(report,null,2));
console.log('Mathematical probability outcomes',report.length,'RTP range',Math.min(...report.map(x=>x.rtp)),Math.max(...report.map(x=>x.rtp)));
