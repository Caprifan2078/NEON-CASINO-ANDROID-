'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const src=fs.readFileSync('web/app.js','utf8');
function boot(seed={}){
 const saved={...seed},nodes=new Map();
 function el(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',className:'',style:{},dataset:{},clientWidth:480,hidden:false,classList:{add(){},remove(){},toggle(){}},setAttribute(){},querySelector(){return null},querySelectorAll(){return []},appendChild(){},remove(){},click(){},addEventListener(){},getContext(){return new Proxy({}, {get(){return ()=>{}}})}});return nodes.get(id)}
 const ctx={console,Math,JSON,Number,Date,Array,Set,Map,Object,String,Intl,Blob,crypto:crypto.webcrypto,performance:{now:()=>1},requestAnimationFrame(f){f()},setTimeout(){return 0},clearTimeout(){},setInterval(){return 0},clearInterval(){},confirm(){return true},localStorage:{getItem(k){return saved[k]||null},setItem(k,v){saved[k]=v},removeItem(k){delete saved[k]}},document:{getElementById:el,querySelector(){return null},querySelectorAll(){return []},createElement(){return el('temp')},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},URL:{createObjectURL(){return 'blob:x'},revokeObjectURL(){}}};
 vm.createContext(ctx);vm.runInContext(src,ctx);
 return {saved,run:q=>vm.runInContext(q,ctx),ctx,el};
}
const x=boot(),r=x.run;
assert.equal(r('window.NEON_INFO.version'),'1.8.9');
assert.equal(r('GAMES.length'),44);
assert.deepEqual(Array.from(r('GAMES.filter(g=>!gameRules()[g.id]).map(g=>g.id)')),[],'every game should have basic game-specific rules');
assert.match(r("guideHTML('roulette')"),/35:1/);
assert.match(r('fairnessHTML()'),/не являются независимой сертификацией/);
assert.match(r("profileTab='awards';profileHTML()"),/Награды|Первый раунд/);
assert.equal(r('achievementStatus().filter(x=>x.unlocked).length'),0);
r('addChips(1000000)');assert.equal(r('achievementStatus().filter(x=>x.unlocked).length'),0,'credits never earn badges');
r("rouletteBet('number','17');settle('Рулетка',100,3600,'17');rt.bets=[];");
assert(r('achievementStatus().some(x=>x.id===\'first\'&&x.unlocked)'));
assert(r('achievementStatus().some(x=>x.id===\'roulette\'&&x.unlocked)'));
assert.equal(r('achievementStatus().find(x=>x.id===\'record\').unlocked'),false);
// Paytable math. Each bet of a covered group must have total return 36 on the 37 equiprobable numbers.
for(const [kind,anchor,size,odds] of [['split-right',1,2,17],['split-up',1,2,17],['street',14,3,11],['corner',1,4,8],['sixline',2,6,5]]){
 const nums=Array.from(r(`rouletteGroup('${kind}',${anchor})`));
 assert.equal(nums.length,size);
 assert.equal(new Set(nums).size,size);
 assert(nums.every(n=>n>=1&&n<=36));
 const winnings=r(`Array.from({length:37},(_,n)=>rouletteWin({type:'combo',value:'${nums.join(',')}',amount:100},n)).reduce((a,b)=>a+b,0)`);
 assert.equal(winnings,size*odds,kind+' net odds sum');
 assert.equal((size*(odds+1))/37,36/37,kind+' total expected return');
}
assert.equal(r('rouletteGroup(\'split-up\',3)'),null,'invalid edge split disabled');
assert.equal(r('rouletteGroup(\'corner\',36)'),null);
assert.equal(r('rouletteGroup(\'split-right\',34)'),null);
assert.equal(r('rouletteGroup(\'street\',0)'),null);
assert.equal(r('rouletteGroup(\'neighbors\',0).length'),5);
assert.equal(new Set(Array.from(r('rouletteGroup(\'neighbors\',0)'))).size,5);
r("state.rouletteAnchor=17;state.rouletteUseCustom=true;state.rouletteCustomStake='2500';roulettePlaceCombo('corner')");
assert.equal(r('state.reserved'),2500);assert.equal(r('rt.bets.length'),1);
assert.equal(r("rouletteWin(rt.bets[0],17)"),8);assert.equal(r("rouletteWin(rt.bets[0],18)"),8);
assert.equal(r("rouletteWin(rt.bets[0],20)"),8);assert.equal(r("rouletteWin(rt.bets[0],21)"),8);
assert.equal(r("rouletteWin(rt.bets[0],19)"),0);
r('refund(rt.bets.pop().amount)'); assert.equal(r('state.reserved'),0);
r("roulettePlaceCombo('neighbors')");assert.equal(r('rt.bets.length'),5);assert.equal(r('state.reserved'),12500);
const blocked=r('state.balance=0;roulettePlaceCombo(\'neighbors\');rt.bets.length');assert.equal(blocked,5,'insufficient funds must not create ghost bets');
r('refund(rt.bets.reduce((s,b)=>s+b.amount,0));rt.bets=[]');
// Saved backup restores favorites and recent, both wallets and honors old v4 files.
r("toggleFavorite('fantan');toggleFavorite('rps');rememberRecent('fantan')");
const snap=r('JSON.stringify(snapshot())');const data=JSON.parse(snap);assert.equal(data.version,5);
assert(data.preferences.favorites.includes('fantan'));assert.equal(data.preferences.recent[0],'fantan');
const y=boot();assert.equal(y.run(`loadBackup(${JSON.stringify(snap)})`),true);
assert.equal(y.run('favoriteGames.has(\'fantan\')'),true);
assert.equal(y.run('recentGames[0]'),'fantan');
assert.equal(y.run('state.lifetime.rounds'),1);
const old=JSON.parse(snap);old.version=4;delete old.preferences;
assert.equal(boot().run(`loadBackup(${JSON.stringify(JSON.stringify(old))})`),true);
// malformed v5 preferences rejected before side effects
const invalid=JSON.parse(snap);invalid.preferences.favorites=['outside-game'];
const z=boot();assert.throws(()=>z.run(`loadBackup(${JSON.stringify(JSON.stringify(invalid))})`),/избранное/);
assert.equal(z.run('state.balance'),50000);
// crypto not available should never fall back to unseeded Math.random to pick game outcome
x.ctx.crypto=undefined;
assert.throws(()=>r('rnd(37)'),/Безопасный генератор/);
const available=x.run('state.balance');assert.equal(r('spend(100)'),false);assert.equal(r('state.balance'),available);assert.equal(r('state.reserved'),0);
console.log('PASS v1.8.6 rules 44/44, 10 achievements, backup v5 + v4 migration, roulette canonical payouts and wheel neighbors, blocked bets, crypto RNG fail closed');
