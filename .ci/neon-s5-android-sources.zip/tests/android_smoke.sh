#!/usr/bin/env bash
set -euo pipefail

apk='app/build/outputs/apk/debug/app-debug.apk'
baseline_apk="${NEON_PREVIOUS_APK:-}"
# Read the actual package ID from the compiled APK. For runs without a stable
# signing key, the package has a run-specific suffix to prevent update conflicts.
aapt="${ANDROID_HOME:?ANDROID_HOME is required}/build-tools/35.0.0/aapt"
test -x "$aapt" || { echo "FAIL: aapt unavailable: $aapt" >&2; exit 1; }
badging="$("$aapt" dump badging "$apk")"
package="$(printf '%s\n' "$badging" | sed -n "s/^package: name='\([^']*\)'.*/\1/p" | head -n 1)"
launch="$(printf '%s\n' "$badging" | sed -n "s/^launchable-activity: name='\([^']*\)'.*/\1/p" | head -n 1)"
test -n "$package" && test -n "$launch" || {
  echo 'FAIL: cannot determine APK package or launcher activity' >&2; exit 1;
}
activity="$package/$launch"
echo "TESTING PACKAGE: $package"
version="$(node -p "require('./package.json').version")"
ready_tag="WEB_READY_v${version}_games44"

test -s "$apk" || { echo "FAIL: APK does not exist: $apk" >&2; exit 1; }

relaunch() {
  local label="$1" ready=0
  adb shell am force-stop "$package" >/dev/null 2>&1 || true
  adb logcat -c
  adb shell am start -W -n "$activity"
  for attempt in $(seq 1 30); do
    if adb logcat -d -s AndroidRuntime:E '*:S' | grep -q 'FATAL EXCEPTION'; then
      echo "FAIL: Android application crashed at $label" >&2
      adb logcat -d -s AndroidRuntime:E '*:S' | tail -100
      exit 1
    fi
    if adb logcat -d -s NEON_QA:I '*:S' | grep -Fq "$ready_tag"; then
      ready=1
      break
    fi
    sleep 1
  done
  if [[ "$ready" -ne 1 ]]; then
    echo "FAIL: no $ready_tag on $label" >&2
    adb logcat -d -s NEON_QA:I NEON_QA:E AndroidRuntime:E '*:S' | tail -120
    exit 1
  fi
  if [[ -z "$(adb shell pidof "$package" | tr -d '\r')" ]]; then
    echo "FAIL: Android app exited after $label" >&2
    exit 1
  fi
  echo "PASS: $label, correct game version $version, 44 games, process alive"
}

# A successful installation is a real PackageManager acceptance, not a ZIP check.
# This is an emulator-installed TEST APK, not a fake JS engine.
test_apk='app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'
test -s "$test_apk" || { echo "FAIL: Gradle did not build instrumentation APK: $test_apk" >&2; exit 1; }

test_package="${package}.test"
runner='androidx.test.runner.AndroidJUnitRunner'
test_class='com.neon.play.simulator.NeonWebViewInstrumentedTest'

run_test() {
  local method="$1" output
  output="$(adb shell am instrument -w -e class "${test_class}#${method}" "${test_package}/${runner}")"
  printf '%s\n' "$output"
  # 'am instrument' does not reliably return a nonzero shell exit on JUnit failure.
  if ! printf '%s\n' "$output" | grep -Eq 'OK \(1 test\)' || \
      printf '%s\n' "$output" | grep -Eq 'FAILURES|INSTRUMENTATION_FAILED|Process crashed'; then
    echo "FAIL: emulator instrumentation ${method} did not pass" >&2
    exit 1
  fi
}

# A CI baseline is a different versionCode of the SAME 1.8.9 sources.
# This proves package-manager upgrade + persistent data, but does not claim
# migration from a historical 1.8.8 or older APK.
if [[ -n "$baseline_apk" ]]; then
  test -s "$baseline_apk" || { echo "FAIL: missing baseline APK: $baseline_apk" >&2; exit 1; }
  prior_badging="$("$aapt" dump badging "$baseline_apk")"
  prior_package="$(printf '%s\n' "$prior_badging" | sed -n "s/^package: name='\([^']*\)'.*/\1/p" | head -n 1)"
  prior_code="$(printf '%s\n' "$prior_badging" | sed -n "s/^package: .*versionCode='\([0-9]*\)'.*/\1/p" | head -n 1)"
  final_code="$(printf '%s\n' "$badging" | sed -n "s/^package: .*versionCode='\([0-9]*\)'.*/\1/p" | head -n 1)"
  [[ "$prior_package" == "$package" && "$prior_code" =~ ^[0-9]+$ && "$final_code" =~ ^[0-9]+$ ]] || {
    echo 'FAIL: baseline/final APK package mismatch or unreadable versionCode' >&2; exit 1;
  }
  (( 10#$prior_code < 10#$final_code )) || {
    echo "FAIL: baseline versionCode ($prior_code) must be lower than final ($final_code)" >&2; exit 1;
  }
  apksigner="${ANDROID_HOME}/build-tools/35.0.0/apksigner"
  test -x "$apksigner" || { echo "FAIL: missing apksigner" >&2; exit 1; }
  prior_sig="$("$apksigner" verify --print-certs "$baseline_apk" | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | head -n 1)"
  final_sig="$("$apksigner" verify --print-certs "$apk" | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | head -n 1)"
  [[ -n "$prior_sig" && "$prior_sig" == "$final_sig" ]] || {
    echo 'FAIL: baseline and final APK signing certificates differ' >&2; exit 1;
  }
  first_apk="$baseline_apk"
  echo "PASS: staged Android upgrade $prior_code -> $final_code, same package and signing certificate"
else
  first_apk="$apk"
  echo 'NOTE: no NEON_PREVIOUS_APK; only same-build reinstall is being tested'
fi
adb install -r "$first_apk"
relaunch first_launch
adb install -r "$test_apk"
# Run the full UI audit; no balance changes from visiting all 44 games.
run_test webViewOpensProfileAndRetainsLocalDataAfterRecreation
# Stage a persistent checkpoint in the FIRST instrumentation process.
run_test stagePersistentWalletCheckpoint
adb shell am force-stop "$package" >/dev/null || true
adb shell am force-stop "$test_package" >/dev/null || true
# If NEON_PREVIOUS_APK is set, this is a real lower-code -> higher-code upgrade.
# Both builds use the same 1.8.9 game source; historical migration remains untested.
adb install -r "$apk"
relaunch second_launch
# Read the persisted checkpoint in a completely NEW instrumentation process.
run_test verifyPersistentWalletCheckpoint

echo 'PASS: emulator installed APK, all 44 games navigated, wallet persisted across process restart and APK replacement'
echo 'NOTE: upgrading from a historical 1.8.8 (or older) signed APK remains UNTESTED.'
