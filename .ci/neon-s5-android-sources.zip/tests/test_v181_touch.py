"""Browser regression for mobile touch targets and 44-panel viewport overflow.
Run: python3 tests/test_v181_touch.py (requires playwright Python + Chromium).
No network or HTTP server; inline web assets are loaded from this source tree.
"""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1] / 'web'
html = (root / 'index.html').read_text(encoding='utf-8')
css = (root / 'app.css').read_text(encoding='utf-8')
js = (root / 'app.js').read_text(encoding='utf-8')
html = re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>', '', html)
html = html.replace('<link rel="stylesheet" href="app.css">', '')
html = html.replace('<script src="app.js" defer></script>', '')
widths = [(240, 480), (280, 500), (320, 568), (360, 640),
          (390, 844), (480, 700), (667, 320), (768, 900),
          (1024, 768), (1440, 900), (1920, 1080), (2560, 1440)]
issues, runtime_errors = [], []
checks = 0
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',
                                args=['--no-sandbox', '--disable-dev-shm-usage'])
    for width, height in widths:
        page = browser.new_page(viewport={'width': width, 'height': height},
                                reduced_motion='reduce')
        page.on('pageerror', lambda e, w=width: runtime_errors.append(f'{w}: {e}'))
        page.set_content(html)
        page.add_style_tag(content=css)
        page.add_script_tag(content=js)
        page.wait_for_timeout(100)  # wait for WebKit/Chromium layout after dynamic stylesheet
        assert page.evaluate('window.NEON_INFO.gameCount') == 44
        if width <= 768:
            # Check that visible primary mobile actions offer at least 44x44 CSS pixels.
            # Exclude intentionally dense roulette numbered cells, which are scrolled in-panel.
            targets = page.evaluate('''() => {
              const selectors=['#menuButton','#qualityToggle','.topbar .wallet',
                  '#compactToggle','#modeBar .mode-choice','.chip-button'];
              return selectors.flatMap(s=>[...document.querySelectorAll(s)]
                  .filter(e=>{const r=e.getBoundingClientRect(),c=getComputedStyle(e);
                    return r.width>0&&r.height>0&&c.visibility!=='hidden';})
                  .map(e=>({selector:s,width:e.getBoundingClientRect().width,
                            height:e.getBoundingClientRect().height})))
            }''')
            for target in targets:
                if target['width'] < 43.99 or target['height'] < 43.99:
                    issues.append(f"{width}x{height}: {target['selector']} {target['width']:.1f}x{target['height']:.1f}")
        for game in page.locator('.nav-item').evaluate_all('(els)=>els.map(e=>e.dataset.game)'):
            sizes = page.evaluate('''(id) => {
              document.querySelector(`[data-action="nav"][data-game="${id}"]`).click();
              return [document.documentElement.scrollWidth,window.innerWidth]
            }''', game)
            checks += 1
            if sizes[0] > sizes[1] + 2:
                issues.append(f'{width}x{height}: {game} document overflow {sizes}')
        if width <= 768:
            page.locator('#menuButton').click()
            assert 'open' in (page.locator('.sidebar').get_attribute('class') or '')
            assert page.locator('#menuButton').get_attribute('aria-expanded') == 'true'
            page.locator('#closeSidebar').click()
            assert 'open' not in (page.locator('.sidebar').get_attribute('class') or '')
            page.locator('.topbar .wallet').click()
            assert page.locator('#modalHost .modal').count() == 1
            page.locator('#modalHost [data-action="close-modal"]').click()
            assert page.locator('#modalHost .modal').count() == 0
        page.close()
    browser.close()
assert not runtime_errors, 'JS errors: ' + '; '.join(runtime_errors)
assert not issues, 'Touchable controls / viewport regressions:\n' + '\n'.join(issues[:60])
print(f'PASS mobile touch targets >=44x44 and {checks} game/viewport navigations, mobile drawer and wallet-modal smoke across {len(widths)} viewports; JS errors 0')
