'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const source=fs.readFileSync(path.resolve(__dirname,'../web/app.js'),'utf8');
function app(seed={}){
 const store={...seed},nodes=new Map();
 function el(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',className:'',style:{},dataset:{},disabled:false,clientWidth:440,classList:{add(){},remove(){},toggle(){}},setAttribute(){},appendChild(){},click(){},remove(){},addEventListener(){},getContext(){return new Proxy({}, {get(){return ()=>{}}})}});return nodes.get(id)}
 const c={Math,JSON,Number,Date,Array,Set,Map,Object,String,Intl,console,crypto:crypto.webcrypto,Blob,performance:{now:()=>1},setTimeout(){return {}},setInterval(){return {}},clearInterval(){},clearTimeout(){},requestAnimationFrame(fn){fn()},localStorage:{getItem(k){return store[k]||null},setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},document:{getElementById:el,querySelector(){return null},querySelectorAll(){return []},createElement(){return el('new'+Math.random())},body:{addEventListener(){},appendChild(){}}},window:{addEventListener(){},matchMedia(){return {matches:false}}},navigator:{},confirm(){return true},URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}}};
 vm.createContext(c);vm.runInContext(source,c,{filename:'app.js'});
 return {run(s){return vm.runInContext(s,c)},store,el,c};
}
const g=app(),run=g.run;
assert.match(g.el('rouletteCustomAmount').innerHTML||run('rouletteHTML()'),/rouletteCustomAmount/);
assert.match(g.el('modalHost').innerHTML||run("state.modal='profile';renderModal();document.getElementById('modalHost').innerHTML"),/profile-lifetime/);
run('addChips(1000000)');
assert.equal(run('state.balance'),1050000);
assert.equal(run('state.lifetime.wagered'),0);
assert.equal(run('state.manualGranted'),1000000);
run("state.rouletteUseCustom=true;state.rouletteCustomStake='75000';rouletteBet('number','17')");
assert.equal(run('rt.bets[0].amount'),75000);
assert.equal(run('state.reserved'),75000);
assert.equal(run('state.lifetime.wagered'),0);
run("settle('Рулетка',75000,2700000,'number17')");
assert.equal(run('state.lifetime.wagered'),75000);
assert.equal(run('state.lifetime.paid'),2700000);
assert.equal(run('state.lifetime.positiveNet'),2625000);
assert.equal(run('state.lifetime.negativeNet'),0);
assert.equal(run('state.journal.length'),1);
run("handleAction({dataset:{action:'reset-stats'}})");
assert.equal(run('state.lifetime.wagered'),75000);
run("switchMode('daily'); spend(100); settle('Рулетка',100,0)");
assert.equal(run('state.lifetime.negativeNet'),100);
assert.equal(run('allTimeTotals().wagered'),75100);
assert.equal(run('allTimeTotals().paid'),2700000);
assert.equal(run('allTimeTotals().manualGranted'),1000000);
const backup=JSON.parse(run('JSON.stringify(snapshot())'));
assert.equal(backup.version,5);
assert.equal(backup.profiles.free.lifetime.wagered,75000);
assert.equal(backup.profiles.daily.lifetime.wagered,100);
const reload=app({'neon-casino-local-v1':g.store['neon-casino-local-v1']});
assert.equal(reload.run('allTimeTotals().wagered'),75100);
assert.equal(reload.run('allTimeTotals().manualGranted'),1000000);
reload.c.importData=JSON.stringify(backup);
assert.equal(reload.run('loadBackup(importData)'),true);
assert.equal(reload.run('allTimeTotals().wagered'),75100);
assert.equal(reload.run('allTimeTotals().paid'),2700000);
// A v3 save has no lifetime; its existing statistics must seed the new independent ledger.
const legacy=structuredClone(backup);legacy.version=3;
for(const p of Object.values(legacy.profiles)){delete p.lifetime;delete p.lifetimeGames;delete p.manualGranted;delete p.journal;delete p.dayBuckets;}
legacy.profiles.free.stats={rounds:3,wins:2,wagered:550,paid:620};legacy.stats=legacy.profiles.daily.stats;
reload.c.importData=JSON.stringify(legacy);
assert.equal(reload.run('loadBackup(importData)'),true);
assert.equal(reload.run('allTimeTotals().wagered'),650);
assert.equal(reload.run('allTimeTotals().paid'),620);
assert.equal(reload.run('allTimeTotals().manualGranted'),0);
// Permit the maximum 100m custom bet, preserve accounting on undo.
reload.run('switchMode("free");addChips(100000000);state.rouletteUseCustom=true;state.rouletteCustomStake="100000000";rouletteBet("number","17")');
assert.equal(reload.run('rt.bets[0].amount'),100000000);
reload.run('refund(rt.bets.pop().amount)');
// Reject malformed and out-of-range numbers without charging a single chip.
const before=reload.run('state.balance');
for(const val of ['1.1','-2','nan','100000001','0','1e9']){reload.c.bad=val;reload.run("state.rouletteUseCustom=true;state.rouletteCustomStake=bad;rouletteBet('number','12')");}
assert.equal(reload.run('state.balance'),before);
assert.equal(reload.run('rt.bets.length'),0);
console.log('PASS v1.8.2 lifetime profile, custom roulette, legacy backups and validations');
