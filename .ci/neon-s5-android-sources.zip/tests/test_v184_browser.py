"""Actual Chromium navigation for v1.8.6 features on phone and desktop."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re
web=Path(__file__).resolve().parents[1]/'web'
html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]+>','',(web/'index.html').read_text())
html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js" defer></script>','')
css=(web/'app.css').read_text();js=(web/'app.js').read_text()
def load(page):
 page.set_content(html);page.add_style_tag(content=css)
 page.evaluate('''()=>{const data={};Object.defineProperty(window,'localStorage',{value:{getItem(k){return data[k]||null},setItem(k,v){data[k]=v},removeItem(k){delete data[k]}}});window.__dump=()=>data;}''')
 page.add_script_tag(content=js)
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height in [(240,520),(320,640),(390,844),(667,360),(1440,900)]:
  ctx=browser.new_context(viewport={'width':width,'height':height},reduced_motion='reduce')
  page=ctx.new_page();page.on('pageerror',lambda e,w=width:errors.append(f'{w}: {e}'))
  load(page)
  assert page.evaluate('GAMES.length')==44
  assert page.locator('[data-action="roulette-table"]').count()==2
  page.locator('[data-action="roulette-table"][data-value="pro"]').click()
  assert page.locator('[data-action="roulette-combo"]').count()==7
  page.locator('#rouletteCustomAmount').fill('100')
  anchor=page.locator('[data-action="roulette-anchor"][data-value="17"]');anchor.click()
  assert page.evaluate('state.rouletteAnchor')==17
  page.locator('[data-action="roulette-combo"][data-value="corner"]').click()
  assert page.evaluate('state.reserved')==100
  assert page.evaluate('rouletteWin(rt.bets[0],17)')==8
  page.locator('[data-action="roulette-undo"]').click()
  assert page.evaluate('state.reserved')==0
  page.locator('[data-action="roulette-combo"][data-value="neighbors"]').click()
  assert page.evaluate('state.reserved')==500
  assert page.evaluate('rt.bets.length')==5
  page.locator('[data-action="roulette-clear"]').click()
  assert page.evaluate('state.reserved')==0
  page.locator('[data-action="roulette-table"][data-value="classic"]').click()
  page.locator('[data-action="roulette-bet"][data-type="number"][data-value="17"]').click()
  assert page.evaluate('state.reserved')==100
  page.locator('[data-action="roulette-clear"]').click()
  assert page.evaluate('state.reserved')==0
  page.locator('[data-action="game-guide"]').first.click()
  assert page.locator('.guide-steps>div').count()==4
  page.locator('[data-action="fairness"]').click()
  assert 'crypto.getRandomValues' in page.locator('.modal-main').inner_text()
  page.locator('[data-action="close-modal"]').click()
  page.locator('#profileButton').click()
  page.locator('[data-action="profile-tab"][data-value="awards"]').click()
  assert page.locator('.achievement-card').count()==10
  assert page.locator('.achievement-summary').count()==1
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1'),f'horizontal overflow {width}'
  if width==390:
   page.screenshot(path='/mnt/data/neon_v184/preview_achievements.png')
   page.locator('[data-action="close-modal"]').click()
   page.locator('[data-action="roulette-table"][data-value="pro"]').click()
   page.screenshot(path='/mnt/data/neon_v184/preview_roulette_mobile.png',full_page=True)
  if width==1440:
   page.screenshot(path='/mnt/data/neon_v184/preview_achievements_desktop.png')
  ctx.close()
 browser.close()
assert not errors,errors
print('PASS v1.8.6 Chromium: 5 viewports, 44 games, pro & classic roulette, 5 neighbors accounting, game guides, fairness help, 10 achievements, zero JS pageerrors or document overflow')
