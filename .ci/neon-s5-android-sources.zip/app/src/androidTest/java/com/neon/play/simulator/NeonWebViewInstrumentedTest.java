package com.neon.play.simulator;

import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/** Runs in a real Android emulator. Does not fake WebView or PackageManager. */
@RunWith(AndroidJUnit4.class)
public final class NeonWebViewInstrumentedTest {
    private static WebView findWebView(View current) {
        if (current instanceof WebView) return (WebView) current;
        if (current instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) current;
            for (int i = 0; i < group.getChildCount(); i++) {
                WebView match = findWebView(group.getChildAt(i));
                if (match != null) return match;
            }
        }
        return null;
    }

    private static String evaluate(ActivityScenario<MainActivity> scenario, String javascript)
            throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> answer = new AtomicReference<>("MISSING_WEBVIEW");
        scenario.onActivity(activity -> {
            View root = activity.findViewById(android.R.id.content);
            WebView webView = findWebView(root);
            if (webView == null) {
                latch.countDown();
            } else {
                webView.evaluateJavascript(javascript, result -> {
                    answer.set(result);
                    latch.countDown();
                });
            }
        });
        assertTrue("WebView JS callback timed out", latch.await(8, TimeUnit.SECONDS));
        return answer.get();
    }

    private static void awaitGame(ActivityScenario<MainActivity> scenario)
            throws InterruptedException {
        long deadline = System.currentTimeMillis() + 25000;
        String version = BuildConfig.VERSION_NAME.replaceFirst("-qa$", "");
        while (System.currentTimeMillis() < deadline) {
            if ("true".equals(evaluate(scenario,
                    "Boolean(window.NEON_INFO && window.NEON_INFO.version==='" + version + "' && " +
                    "window.NEON_INFO.gameCount===44 && " +
                    "document.querySelector('#gameArea') && document.querySelector('#profileButton'))"))) {
                return;
            }
            Thread.sleep(350);
        }
        throw new AssertionError("Casino UI did not become ready with all 44 games");
    }

    @Test public void webViewOpensProfileAndRetainsLocalDataAfterRecreation()
            throws InterruptedException {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            awaitGame(scenario);
            // Switch both lobby views through the actual UI, not by mutating internal state.
            assertEquals("true", evaluate(scenario,
                    "(document.querySelector('[data-action=casino-view][data-value=hall]').click()," +
                    " Boolean(document.querySelector('#hallStage') && " +
                    " !document.querySelector('#hallStage').hidden))"));
            assertEquals("true", evaluate(scenario,
                    "(document.querySelector('[data-action=casino-view][data-value=casual]').click()," +
                    " Boolean(document.querySelector('#hallStage') && " +
                    " document.querySelector('#hallStage').hidden))"));
            assertEquals("true", evaluate(scenario,
                    "(document.querySelector('#profileButton').click(), " +
                    "Boolean(document.querySelector('.modal-overlay') && " +
                    "document.querySelector('[data-value=awards]')))"));
            assertEquals("true", evaluate(scenario,
                    "(document.querySelector('[data-action=close-modal]').click()," +
                    " !document.querySelector('.modal-overlay'))"));
            // Exercise every genuine game navigation control and verify the rendered
            // game panel, while preserving the initial wallet. This is a real WebView
            // interaction, not a mocked list of names.
            assertEquals("true", evaluate(scenario,
                    "(function(){var navs=[...document.querySelectorAll('#gameNav [data-action=nav]')];" +
                    "if(navs.length!==44)return false;var before=state.balance;" +
                    "for(var i=0;i<navs.length;i++){var id=navs[i].dataset.game;" +
                    "navs[i].click();if(state.game!==id||" +
                    "!document.querySelector('#gameArea').children.length)return false;}" +
                    "return before===state.balance;})()"));
            // Persist a real snapshot, then compare the wallet against disk after restart.
            assertEquals("true", evaluate(scenario,
                    "(save(), localStorage.getItem('neon-casino-local-v1')!==null)"));
            String balanceBefore = evaluate(scenario, "String(state.balance)");
            assertEquals("true", evaluate(scenario,
                    "(localStorage.setItem('__neon_instrumented_persist','unchanged')," +
                    "localStorage.getItem('__neon_instrumented_persist')==='unchanged')"));
            scenario.recreate();
            awaitGame(scenario);
            assertEquals(balanceBefore, evaluate(scenario, "String(state.balance)"));
            assertEquals("true", evaluate(scenario,
                    "localStorage.getItem('__neon_instrumented_persist')==='unchanged'"));
            assertEquals("true", evaluate(scenario,
                    "(localStorage.removeItem('__neon_instrumented_persist'),true)"));
        }
    }

    /**
     * Stage a genuine localStorage checkpoint in one independent instrumentation run.
     * CI then force-stops the process and reinstalls the SAME APK without clearing data.
     * The follow-up test runs in a NEW instrumentation process.
     */
    @Test public void stagePersistentWalletCheckpoint() throws InterruptedException {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            awaitGame(scenario);
            assertEquals("true", evaluate(scenario,
                    "(function(){save();" +
                    "var wallet=localStorage.getItem('neon-casino-local-v1');" +
                    "if(!wallet)return false;" +
                    "var item=JSON.stringify({balance:String(state.balance)," +
                    "version:window.NEON_INFO.version,tag:'NEON_QA_S4'});" +
                    "localStorage.setItem('__neon_android_s4_cold_reinstall',item);" +
                    "return localStorage.getItem('__neon_android_s4_cold_reinstall')===item;})()"));
        }
    }

    /** Read the checkpoint ONLY after CI has closed the previous process and reinstalled. */
    @Test public void verifyPersistentWalletCheckpoint() throws InterruptedException {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            awaitGame(scenario);
            assertEquals("true", evaluate(scenario,
                    "(function(){var raw=localStorage.getItem('__neon_android_s4_cold_reinstall');" +
                    "if(!raw)return false;var item=JSON.parse(raw);" +
                    "if(item.tag!=='NEON_QA_S4'||" +
                    "item.version!==window.NEON_INFO.version||" +
                    "item.balance!==String(state.balance)||" +
                    "!localStorage.getItem('neon-casino-local-v1'))return false;" +
                    "localStorage.removeItem('__neon_android_s4_cold_reinstall');" +
                    "return true;})()"));
        }
    }
}
