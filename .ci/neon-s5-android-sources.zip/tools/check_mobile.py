from pathlib import Path
import hashlib,re,sys,json
root=Path(__file__).resolve().parents[1]
web=root/'web'; bundled=root/'app/src/main/assets/web'
files=['index.html','app.css','app.js','icon.svg','icon-192.png','icon-512.png','manifest.webmanifest','sw.js']
for name in files:
    assert (web/name).read_bytes()==(bundled/name).read_bytes(),f'Different Android assets: {name}'
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' not in manifest
assert 'usesCleartextTraffic="false"' in manifest
source=(root/'app/src/main/java/com/neon/play/simulator/MainActivity.java').read_text()
assert 'shouldInterceptRequest' in source
assert 'onRenderProcessGone' in source
assert 'isBundled(Uri uri)' in source
assert 'MAX_BACKUP_CHARS' in source
assert 'backupResult(written)' in source
assert 'onBackPressed()' in source
assert "window.neonNativeBackupComplete" in (web/'app.js').read_text()
version=json.loads((root/'package.json').read_text())['version']
# The APK version is supplied by Gradle, rather than duplicated in Java.
assert 'BuildConfig.VERSION_NAME' in source
assert 'window.NEON_INFO.version ===' in source
assert f"version:'{version}'" in (web/'app.js').read_text()
assert 'android:launchMode="singleTask"' in manifest
assert 'soleNativeActivity' in (web/'app.js').read_text()
assert 'Content-Security-Policy' in (web/'index.html').read_text()
assert "connect-src 'self'" in (web/'index.html').read_text()
assert "frame-src 'none'" in (web/'index.html').read_text()
gradle=(root/'app/build.gradle').read_text()
assert f"versionName '{version}'" in gradle
code=re.search(r'\bversionCode\s+(\d+)',gradle)
assert code and int(code.group(1))>=100, 'Invalid Android versionCode'
print('PASS Android asset integrity, origin isolation, backup callback, error screen, version, no INTERNET permission')
print('JS SHA256:',hashlib.sha256((web/'app.js').read_bytes()).hexdigest())

assert '"WEB_READY_v" + expectedWebVersion + "_games44"' in source
smoke=(root/'tests/android_smoke.sh').read_text()
assert 'package.json' in smoke and 'ready_tag' in smoke
assert 'WEB_READY_v1.8.6_games44' not in smoke
