# Android APK v1.8.9 через GitHub Actions

Исходная папка проекта: `BUILD_READY_ANDROID_PROJECT`. Загрузить **её содержимое**, а не внешнюю папку или ZIP, в корень отдельного репозитория GitHub. Путь к workflow в репозитории должен быть `.github/workflows/build-android.yml`.

1. Открыть **Actions → NEON ROYALE — Android SDK build + emulator installation QA → Run workflow**.
2. После успешного выполнения открыть артефакт **`NEON-v1.8.9-ANDROID-EMULATOR-TESTED`**, скачать ZIP с `app-debug.apk` и `SIGNING_STATUS.txt`.
3. Перед установкой **экспортировать JSON-сохранение** текущей версии.
4. Если статус **FRESH-INSTALL-ONLY**, не пытаться обновлять старый пакет с другой подписью. Для обновлений необходимо добавить приватный старый ключ в GitHub Secrets согласно `README_RU.md`.
5. Проверить установку APK и перенос сохранений на телефоне. Пакет: `com.neon.play.simulator.qa182`.

Публикация нового APK доступна **только после реального прохода эмулятора** в GitHub Actions. Этот workflow здесь не запускался, готового APK я не заявляю.
