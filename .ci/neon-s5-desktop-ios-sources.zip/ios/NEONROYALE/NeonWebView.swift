import SwiftUI
import WebKit
import UIKit

// Offline shell for the existing NEON CASINO ROYALE web game.
// The app uses the persistent WKWebsiteDataStore. No remote websites are allowed.
struct NeonWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.allowsInlineMediaPlayback = true
        config.userContentController.add(context.coordinator, name: "neonBackup")
        // Bridge compatible with the existing game's exportBackup() call.
        let bridge = """
        window.NeonBridge = { saveBackup: function(data) {
            window.webkit.messageHandlers.neonBackup.postMessage(data);
        }};
        """
        config.userContentController.addUserScript(
            WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 7/255, green: 11/255, blue: 22/255, alpha: 1)
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        context.coordinator.webView = webView
        if let entry = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            webView.loadFileURL(entry, allowingReadAccessTo: entry.deletingLastPathComponent())
        } else {
            let html = "<h2 style='color:white'>Ресурсы NEON CASINO не найдены</h2>"
            webView.loadHTMLString(html, baseURL: nil)
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel); return
            }
            decisionHandler(url.isFileURL || url.scheme == "about" ? .allow : .cancel)
        }

        // The simulator smoke test checks actual game JS readiness, not merely app launch.
        // Wait briefly for deferred scripts; never log a false success for an empty WebView.
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            verifyGameReady(webView, attempts: 20)
        }

        private func verifyGameReady(_ target: WKWebView, attempts: Int) {
            guard webView === target else { return }
            target.evaluateJavaScript("Boolean(window.NEON_INFO && window.NEON_INFO.version === '1.8.9' && window.NEON_INFO.gameCount === 44)") { [weak self, weak target] result, _ in
                guard let self, let target, self.webView === target else { return }
                if (result as? Bool) == true {
                    NSLog("NEON_IOS_READY_v1.8.9_games44")
                    // Only simulator QA uses a tiny sentinel; never touch user wallets.
                    if ProcessInfo.processInfo.arguments.contains("-NEON_QA_SMOKE") {
                        let script = """
                        (function(){try {var key='__neon_ios_s2_qa';
                        var before=localStorage.getItem(key);
                        localStorage.setItem(key,'ready');
                        return localStorage.getItem(key)==='ready'
                          ? (before==='ready' ? 'PERSISTED' : 'FIRST_LAUNCH')
                          : 'FAILED';}catch(e){return 'FAILED';}})()
                        """
                        target.evaluateJavaScript(script) { result, _ in
                            switch result as? String {
                            case "FIRST_LAUNCH": NSLog("NEON_IOS_STORAGE_FIRST_LAUNCH")
                            case "PERSISTED": NSLog("NEON_IOS_STORAGE_PERSISTED")
                            default: NSLog("NEON_IOS_STORAGE_FAILED")
                            }
                        }
                    }
                } else if attempts > 1 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self, weak target] in
                        guard let self, let target else { return }
                        self.verifyGameReady(target, attempts: attempts - 1)
                    }
                } else {
                    NSLog("NEON_IOS_STARTUP_FAILED")
                }
            }
        }

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "neonBackup", let backup = message.body as? String,
                  backup.utf8.count <= 1_000_000 else {
                completion(false); return
            }
            let file = FileManager.default.temporaryDirectory
                .appendingPathComponent("neon-casino-save.json")
            do {
                try backup.write(to: file, atomically: true, encoding: .utf8)
                guard let presenter = topController() else { completion(false); return }
                let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                share.popoverPresentationController?.sourceView = presenter.view
                share.popoverPresentationController?.sourceRect = CGRect(
                    x: presenter.view.bounds.midX, y: presenter.view.bounds.midY,
                    width: 1, height: 1)
                share.completionWithItemsHandler = { [weak self] _, completed, _, _ in
                    self?.completion(completed)
                }
                presenter.present(share, animated: true)
            } catch {
                completion(false)
            }
        }

        private func completion(_ ok: Bool) {
            webView?.evaluateJavaScript("window.neonNativeBackupComplete(\(ok ? "true" : "false"));")
        }

        private func topController() -> UIViewController? {
            var vc = webView?.window?.rootViewController
            while let next = vc?.presentedViewController { vc = next }
            return vc
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            guard let vc = topController() else { completionHandler(); return }
            let alert = UIAlertController(title: "NEON CASINO", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            vc.present(alert, animated: true)
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping (Bool) -> Void) {
            guard let vc = topController() else { completionHandler(false); return }
            let alert = UIAlertController(title: "NEON CASINO", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "Подтвердить", style: .default) { _ in completionHandler(true) })
            vc.present(alert, animated: true)
        }

        func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                     defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                     completionHandler: @escaping (String?) -> Void) {
            guard let vc = topController() else { completionHandler(nil); return }
            let alert = UIAlertController(title: "NEON CASINO", message: prompt, preferredStyle: .alert)
            alert.addTextField { $0.text = defaultText }
            alert.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                completionHandler(alert.textFields?.first?.text)
            })
            vc.present(alert, animated: true)
        }
    }
}
