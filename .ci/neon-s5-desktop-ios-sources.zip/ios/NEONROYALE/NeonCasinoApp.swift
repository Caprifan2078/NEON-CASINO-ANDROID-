import SwiftUI

@main
struct NeonCasinoApp: App {
    var body: some Scene {
        WindowGroup {
            NeonWebView()
                .ignoresSafeArea()
        }
    }
}
