package main

import (
	"io/fs"
	"testing"
	"testing/fstest"
)

// The loopback launcher must never reuse a server merely because it reports
// the same human-readable version. Test that every bundled asset contributes
// to the content fingerprint and that missing resources are fatal.
func TestContentFingerprintCoversAllAssets(t *testing.T) {
	realAssets, err := fs.Sub(assets, "web")
	if err != nil {
		t.Fatal(err)
	}
	original, err := contentFingerprint(realAssets)
	if err != nil {
		t.Fatal(err)
	}
	if len(original) != 64 {
		t.Fatalf("bad sha256 length: %q", original)
	}
	snapshot := fstest.MapFS{}
	for _, name := range fingerprintAssets {
		b, err := fs.ReadFile(realAssets, name)
		if err != nil {
			t.Fatal(err)
		}
		snapshot[name] = &fstest.MapFile{Data: append([]byte(nil), b...)}
	}
	exact, err := contentFingerprint(snapshot)
	if err != nil || exact != original {
		t.Fatalf("unchanged snapshot differs: %v", err)
	}
	for _, name := range fingerprintAssets {
		changed := fstest.MapFS{}
		for k, v := range snapshot {
			changed[k] = &fstest.MapFile{Data: append([]byte(nil), v.Data...)}
		}
		changed[name].Data = append(changed[name].Data, '\n')
		updated, err := contentFingerprint(changed)
		if err != nil {
			t.Fatal(err)
		}
		if updated == original {
			t.Fatalf("modifying %s did not change fingerprint", name)
		}
		delete(changed, name)
		if _, err := contentFingerprint(changed); err == nil {
			t.Fatalf("missing %s was not rejected", name)
		}
	}
}
