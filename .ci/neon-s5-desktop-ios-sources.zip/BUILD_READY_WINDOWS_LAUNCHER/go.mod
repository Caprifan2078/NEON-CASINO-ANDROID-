module neon-casino-pc

go 1.23
