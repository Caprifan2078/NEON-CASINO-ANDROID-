// NEON CASINO PC v1.8.9 — self-contained local simulator (virtual chips only).
// Web assets are embedded in this executable. No network or installer required.
package main

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed web
var assets embed.FS
var lastPing atomic.Int64
var addr = "127.0.0.1:17877"
var endpoint = "http://" + addr

// A plain version label is insufficient: two binaries of 1.8.9 may bundle
// different HTML/JS assets. Compare this fingerprint before reusing a live
// loopback server; otherwise an upgrade can silently display old game code.
var fingerprintAssets = []string{
	"index.html", "app.js", "app.css", "sw.js", "manifest.webmanifest",
	"icon.svg", "icon-192.png", "icon-512.png",
}

func contentFingerprint(content fs.FS) (string, error) {
	digest := sha256.New()
	for _, name := range fingerprintAssets {
		body, err := fs.ReadFile(content, name)
		if err != nil {
			return "", fmt.Errorf("asset %s: %w", name, err)
		}
		if _, err := fmt.Fprintf(digest, "%s:%d\n", name, len(body)); err != nil {
			return "", err
		}
		if _, err := digest.Write(body); err != nil {
			return "", err
		}
	}
	return hex.EncodeToString(digest.Sum(nil)), nil
}

func main() {
	silent := flag.Bool("no-browser", false, "Start the local server without opening a browser (for automated testing)")
	if len(os.Args) > 1 && os.Args[1] == "--version" {
		fmt.Println("NEON CASINO 1.8.9")
		return
	}
	flag.Parse()
	content, err := fs.Sub(assets, "web")
	if err != nil {
		log.Fatal(err)
	}
	buildID, err := contentFingerprint(content)
	if err != nil {
		log.Fatal(err)
	}
	listener, err := net.Listen("tcp", addr)
	if err != nil {
		// Bound the probe: an unrelated or wedged listener on this port must not freeze startup.
		// Never follow a redirect from an untrusted local process to a remote endpoint.
		probeClient := &http.Client{Timeout: 1500 * time.Millisecond, CheckRedirect: func(_ *http.Request, _ []*http.Request) error { return http.ErrUseLastResponse }}
		if existing, issue := probeClient.Get(endpoint + "/__appcheck"); issue == nil {
			io.Copy(io.Discard, existing.Body)
			existing.Body.Close()
			if existing.StatusCode == 200 && existing.Header.Get("X-Neon-Simulator") == "1.8.9" &&
				existing.Header.Get("X-Neon-Build") == buildID {
				if !*silent {
					openBrowser(endpoint)
				}
				return
			}
		}
		// Another release occupies the stable port. Never show its UI as ours.
		// A fallback port avoids starting a stale game; browser storage then has a different origin.
		for port := 17878; port <= 17888; port++ {
			candidate := fmt.Sprintf("127.0.0.1:%d", port)
			if candidateListener, listenError := net.Listen("tcp", candidate); listenError == nil {
				listener = candidateListener
				addr = candidate
				endpoint = "http://" + addr
				fmt.Fprintln(os.Stderr, "ВНИМАНИЕ: основной порт занят другой или устаревшей сборкой. Баланс на запасном порту будет отдельным. Для переноса сохранения используй экспорт и импорт.")
				break
			}
		}
		if listener == nil {
			log.Fatalf("Не удалось открыть свободный локальный адрес: %v", err)
		}
	}
	defer listener.Close()
	lastPing.Store(time.Now().Unix())
	files := http.FileServer(http.FS(content))
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Host != addr && r.Host != "localhost:"+strings.TrimPrefix(addr, "127.0.0.1:") {
			http.Error(w, "Invalid host", http.StatusBadRequest)
			return
		}
		w.Header().Set("X-Neon-Build", buildID)
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self' data:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
		w.Header().Set("Cache-Control", "no-store")
		if r.URL.Path == "/__appcheck" {
			w.Header().Set("X-Neon-Simulator", "1.8.9")
			fmt.Fprint(w, "NEON CASINO 1.8.9")
			return
		}
		if r.URL.Path == "/__ping" {
			lastPing.Store(time.Now().Unix())
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if strings.HasPrefix(r.URL.Path, "/__") {
			http.NotFound(w, r)
			return
		}
		files.ServeHTTP(w, r)
	})
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second, IdleTimeout: 30 * time.Second}
	go func() {
		clock := time.NewTicker(time.Minute)
		defer clock.Stop()
		for range clock.C {
			if time.Now().Unix()-lastPing.Load() > 300 {
				server.Close()
				return
			}
		}
	}()
	fmt.Println("NEON CASINO 1.8.9 — автономная ПК-версия, только виртуальные фишки")
	fmt.Println("Игра:", endpoint)
	fmt.Println("Нужен установленный браузер. Чтобы завершить игру, закройте браузер: сервер остановится сам.")
	if !*silent {
		go func() {
			time.Sleep(400 * time.Millisecond)
			if err := openBrowser(endpoint); err != nil {
				fmt.Fprintln(os.Stderr, "Откройте ссылку вручную:", endpoint, "(", err, ")")
			}
		}()
	}
	if err := server.Serve(listener); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}

func openBrowser(url string) error {
	var candidates []string
	if runtime.GOOS == "windows" {
		for _, base := range []string{os.Getenv("PROGRAMFILES(X86)"), os.Getenv("PROGRAMFILES"), os.Getenv("LOCALAPPDATA")} {
			if base == "" {
				continue
			}
			candidates = append(candidates, filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
			candidates = append(candidates, filepath.Join(base, "Google", "Chrome", "Application", "chrome.exe"))
		}
	} else {
		candidates = []string{"chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "brave-browser"}
	}
	for _, candidate := range candidates {
		resolved := candidate
		if !filepath.IsAbs(resolved) {
			var err error
			resolved, err = exec.LookPath(candidate)
			if err != nil {
				continue
			}
		} else if _, err := os.Stat(resolved); err != nil {
			continue
		}
		cmd := exec.Command(resolved, "--app="+url)
		if runtime.GOOS == "linux" {
			cmd.Args = append(cmd.Args, "--no-first-run")
		}
		cmd.Stdout = io.Discard
		cmd.Stderr = io.Discard
		if err := cmd.Start(); err == nil {
			go cmd.Wait()
			return nil
		}
	}
	if runtime.GOOS == "windows" {
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	}
	if runtime.GOOS == "darwin" {
		return exec.Command("open", url).Start()
	}
	return exec.Command("xdg-open", url).Start()
}
