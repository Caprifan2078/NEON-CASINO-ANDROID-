/* NEON CASINO — offline, simulated chips only. No network, accounts or purchases. */
'use strict';
const GAMES=[
 {id:'roulette',icon:'◉',name:'Рулетка',title:'Европейская рулетка',sub:'Классический стол · 37 чисел · Живая лента'},
 {id:'blackjack',icon:'♠',name:'Блэкджек',title:'Блэкджек 21',sub:'Дилер, двойная ставка и разделение пары'},
 {id:'wheel',icon:'✺',name:'Колесо удачи',title:'Колесо множителей',sub:'24 сектора · Множители до ×10'},
 {id:'crash',icon:'↗',name:'Crash',title:'Crash · Забери вовремя',sub:'Растущий коэффициент и мгновенный вывод фишек'},
 {id:'slots',icon:'▦',name:'Слоты',title:'Неоновые слоты',sub:'3 барабана · 5 линий выплат'},
 {id:'mines',icon:'◆',name:'Mines',title:'Mines · Минное поле',sub:'Открывай безопасные клетки и забирай выигрыш'},
 {id:'plinko',icon:'∴',name:'Plinko',title:'Plinko · Шарик удачи',sub:'8 уровней · Множители от ×0.2 до ×10'},
 {id:'dice',icon:'⚄',name:'Dice',title:'Dice · Бросок',sub:'Выбирай вероятность выигрыша'},
 {id:'baccarat',icon:'♣',name:'Баккара',title:'Баккара · Punto Banco',sub:'Стандартные правила третьей карты'},
 {id:'coin',icon:'◐',name:'Монетка',title:'Орел или решка',sub:'Честный случайный бросок · ×1.95'},
 {id:'keno',icon:'✳',name:'Кено',title:'Кено · 5 из 40',sub:'Выбери 5 чисел · розыгрыш 10 чисел · таблица выплат'},
 {id:'poker',icon:'♥',name:'Видеопокер',title:'Видеопокер · Jacks or Better',sub:'Собери комбинацию · удерживай карты · меняй остальные'},
 {id:'sicbo',icon:'⚂',name:'Sic Bo',title:'Sic Bo · Три кубика',sub:'Ставь на малое, большое или три одинаковых'},
 {id:'limbo',icon:'⇡',name:'Limbo',title:'Limbo · Выбери множитель',sub:'Шанс и выплата меняются с выбранной целью'},
 {id:'hilo',icon:'⇵',name:'Выше / ниже',title:'Карты · Выше или ниже',sub:'Угадай ранг следующей карты · равенство возвращает ставку'},
 {id:'craps',icon:'⚅',name:'Craps',title:'Craps · Pass / Don’t Pass',sub:'Выбор линии · первый бросок · пойнт · исход'}
];
// Bugfix 1.7.1: prevent two windows from silently overwriting the same wallet.
// The lease is local to this app origin; no network or third-party service is used.
const INSTANCE_KEY='neon-casino-active-instance-v1',INSTANCE_TTL=30000;
const INSTANCE_TOKEN=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
let instanceWritable=false,instanceStorageAvailable=true,volatileMode=false;
function leaseRead(){try{const raw=localStorage.getItem(INSTANCE_KEY);return raw?JSON.parse(raw):null}catch(e){instanceStorageAvailable=false;return null}}
function claimInstance(){
 if(!instanceStorageAvailable){volatileMode=true;return true}
 const current=leaseRead(),now=Date.now();
 // Android uses a singleTask Activity. A killed WebView renderer must reclaim its
 // own wallet immediately; browser tabs still require the normal 30-second lease.
 const soleNativeActivity=typeof window!=='undefined'&&Boolean(window.NeonBridge);
 if(current&&current.token!==INSTANCE_TOKEN&&Number.isFinite(current.at)&&current.at<=now&&now-current.at<INSTANCE_TTL&&!soleNativeActivity)return false;
 try{localStorage.setItem(INSTANCE_KEY,JSON.stringify({token:INSTANCE_TOKEN,at:now}));const after=leaseRead();return Boolean(after&&after.token===INSTANCE_TOKEN)}
 catch(e){instanceStorageAvailable=false;volatileMode=true;return true}
}
instanceWritable=claimInstance();
function canModify(){
 if(volatileMode)return true;
 if(!instanceWritable||!instanceStorageAvailable)return false;
 const current=leaseRead();
 if(!current||current.token!==INSTANCE_TOKEN){instanceWritable=false;return false}
 return true
}
function leaseHeartbeat(){if(volatileMode||!canModify())return;try{localStorage.setItem(INSTANCE_KEY,JSON.stringify({token:INSTANCE_TOKEN,at:Date.now()}))}catch(e){instanceStorageAvailable=false;instanceWritable=false}}
function leaseBlock(){toast(instanceStorageAvailable?'Другое окно уже использует этот кошелёк. Закрой его и обнови страницу.':'Не удалось записать прогресс. Проверь доступное место и перезапусти игру.',true)}
const BALANCE_CAP=9000000000000000;
const STORAGE='neon-casino-local-v1',fmt=n=>Math.round(Number(n)||0).toLocaleString('ru-RU'),money=n=>`${fmt(n)} ◈`,esc=s=>String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
// Restrict and normalize untrusted/corrupted local saves (including older v1 saves).
const safeAmount=(n,fallback=0)=>Number.isSafeInteger(n)&&n>=0&&n<=BALANCE_CAP?n:fallback;
const safeStats=v=>({rounds:safeAmount(v?.rounds),wins:safeAmount(v?.wins),wagered:safeAmount(v?.wagered),paid:safeAmount(v?.paid)});
let persisted={};try{persisted=JSON.parse(localStorage.getItem(STORAGE)||'{}')||{}}catch(e){}
if(!persisted||typeof persisted!=='object'||Array.isArray(persisted))persisted={};
const safeHistory=items=>Array.isArray(items)?items.filter(x=>x&&Number.isInteger(x.n)&&x.n>=0&&x.n<=36&&Number.isFinite(x.at)&&x.at>=0&&x.at<=8640000000000000).slice(0,80).map(x=>({n:x.n,at:x.at,stake:safeAmount(x.stake),payout:safeAmount(x.payout)})):[];
const safeActivity=items=>Array.isArray(items)?items.filter(x=>x&&typeof x==='object').slice(0,20).map(x=>({game:String(x.game||'').slice(0,35),detail:String(x.detail||'').slice(0,100),profit:Number.isSafeInteger(x.profit)?x.profit:0,at:String(x.at||'').slice(0,12)})):[];
const safeGameStats=items=>{const result={};if(items&&typeof items==='object'&&!Array.isArray(items))for(const id of GAMES.map(g=>g.id).concat(['caribbean','teenpatti','fantan','crown','roulette-us','roulette-fr','threecard','war','dragontiger','tower','bingo','lotto','scratch','seven','dicepoker','treasure','andar','reddog','pick3','bingo90','keno80','cardsuit','ladder','slots5','holdem','letitride','rps','colors'])){if(items[id])result[id]=safeStats(items[id])}return result};
// Lifetime counters do not change when the player clears the recent session statistics.
// Old v3 saves have exact aggregate wagers/payouts but cannot reconstruct individual
// profitable or losing rounds, so the latter start at zero on migration.
const JOURNAL_LIMIT=240,DAY_BUCKET_LIMIT=120,MAX_ROULETTE_BET=100000000;
const safeLifetime=(raw,legacy)=>{
 const v=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:null;
 const base=safeStats(v||legacy);
 return {...base,positiveNet:safeAmount(v?.positiveNet),negativeNet:safeAmount(v?.negativeNet)};
};
const safeRoundReplay=raw=>{
 if(raw?.type==='slots'){
  const symbols=['🍒','🍋','🔔','🍀','💎','7️⃣'];
  if(!Array.isArray(raw.cells)||raw.cells.length!==9||raw.cells.some(x=>typeof x!=='string'||!symbols.includes(x)))return null;
  if(!Array.isArray(raw.lines)||raw.lines.length>5||raw.lines.some(x=>!Number.isInteger(x)||x<0||x>4)||new Set(raw.lines).size!==raw.lines.length)return null;
  const layouts=[[0,1,2],[3,4,5],[6,7,8],[0,4,8],[2,4,6]];
  const expected=layouts.map((line,i)=>line.every(idx=>raw.cells[idx]===raw.cells[line[0]])?i:null).filter(i=>i!==null);
  if(expected.length!==raw.lines.length||expected.some(i=>!raw.lines.includes(i)))return null;
  return {type:'slots',cells:raw.cells.slice(),lines:raw.lines.slice()};
 }
 if(!raw||raw.type!=='roulette'||!Number.isInteger(raw.number)||raw.number<0||raw.number>36||!Array.isArray(raw.bets)||raw.bets.length>300)return null;
 const bets=[];for(const b of raw.bets){
  if(!b||!['number','color','low','high','odd','even','dozen','column','combo'].includes(b.type)||!Number.isSafeInteger(b.amount)||b.amount<1||b.amount>MAX_ROULETTE_BET||String(b.value||'').length>110)return null;
  bets.push({type:b.type,value:String(b.value),amount:b.amount});
 }
 return {type:'roulette',number:raw.number,bets};
};
const safeJournal=xs=>Array.isArray(xs)?xs.slice(0,JOURNAL_LIMIT).filter(x=>x&&typeof x==='object'&&Number.isFinite(x.at)&&x.at>=0&&x.at<=8640000000000000&&safeAmount(x.stake)===x.stake&&safeAmount(x.payout)===x.payout).map(x=>({at:x.at,game:String(x.game||'').slice(0,50),stake:x.stake,payout:x.payout,detail:String(x.detail||'').slice(0,100),replay:safeRoundReplay(x.replay)})):[];
const safeBuckets=xs=>Array.isArray(xs)?xs.slice(0,DAY_BUCKET_LIMIT).filter(x=>x&&typeof x.day==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(x.day)).map(x=>({day:x.day,...safeStats(x)})):[];
const localDay=at=>{const d=new Date(at);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const incrementStat=(s,stake,payout)=>{s.rounds=Math.min(BALANCE_CAP,s.rounds+1);s.wagered=Math.min(BALANCE_CAP,s.wagered+stake);s.paid=Math.min(BALANCE_CAP,s.paid+payout);if(payout>stake)s.wins=Math.min(BALANCE_CAP,s.wins+1)};
// Two completely independent chip wallets. Legacy v1/v1.1 saves migrate into Free Play.
const DAILY_CREDIT=1000,DAILY_HISTORY_LIMIT=100;
const validMode=v=>v==='daily'?'daily':'free';
const safeProfile=(raw,initial)=>({
 balance:safeAmount(raw?.balance,initial),reserved:safeAmount(raw?.reserved),
 stats:safeStats(raw?.stats),gameStats:safeGameStats(raw?.gameStats),
 rouletteHistory:safeHistory(raw?.rouletteHistory),activity:safeActivity(raw?.activity),
 lifetime:safeLifetime(raw?.lifetime,raw?.stats),lifetimeGames:safeGameStats(raw?.lifetimeGames||raw?.gameStats),
 manualGranted:safeAmount(raw?.manualGranted),journal:safeJournal(raw?.journal),dayBuckets:safeBuckets(raw?.dayBuckets),
 recordWin:safeAmount(raw?.recordWin,Math.max(0,...safeJournal(raw?.journal).map(x=>x.payout-x.stake))),
 recordLoss:safeAmount(raw?.recordLoss,Math.max(0,...safeJournal(raw?.journal).map(x=>x.stake-x.payout)))
});
const profileSnapshots={
 free:safeProfile(persisted.profiles?.free||persisted,50000),
 daily:safeProfile(persisted.profiles?.daily,DAILY_CREDIT)
};
// Recovery of interrupted wagers must happen independently in each wallet.
for(const mode of ['free','daily']){
 const p=profileSnapshots[mode];
 if(p.reserved){p.balance=Math.min(BALANCE_CAP,p.balance+p.reserved);p.reserved=0}
}
const safeDayHistory=items=>Array.isArray(items)?items.slice(0,DAILY_HISTORY_LIMIT).filter(x=>x&&Number.isSafeInteger(x.day)&&x.day>=1).map(x=>({
 day:x.day,rounds:safeAmount(x.rounds),wagered:safeAmount(x.wagered),paid:safeAmount(x.paid),
 leftover:safeAmount(x.leftover),reason:x.reason==='empty'?'empty':'manual',
 at:Number.isFinite(x.at)?x.at:Date.now()
})):[];
const rawDaily=persisted.dailyProgress;
let dailyProgress={
 day:Math.max(1,Math.min(100000000, safeAmount(rawDaily?.day,1))),
 rounds:safeAmount(rawDaily?.rounds),wagered:safeAmount(rawDaily?.wagered),
 paid:safeAmount(rawDaily?.paid),startedAt:Number.isFinite(rawDaily?.startedAt)?rawDaily.startedAt:Date.now(),
 history:safeDayHistory(rawDaily?.history)
};
const state={...profileSnapshots[validMode(persisted.mode)],mode:validMode(persisted.mode),game:'roulette',stake:100,chip:100,rouletteUseCustom:false,rouletteCustomStake:'5000',rouletteTableMode:'classic',rouletteAnchor:17,diceChance:50,diceSide:'under',minesCount:3,baccaratBet:'player',coinBet:'heads',kenoPicks:[],limboTarget:2,sicboBet:'small',hiloBet:'higher',modal:null};
// Active rounds cannot survive reload: refund reserved stakes once; never duplicate payouts.
// A migrated profile is written at startup only after state and save() exist.
if(persisted.reserved>0||persisted.profiles?.free?.reserved>0||persisted.profiles?.daily?.reserved>0)save();
let lastRouletteBets=[];
const RNUM=[0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const REDS=new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
const WIN_SECTORS=[1,0,0.5,0,1,0,2,0,1,0,3,0,1,0,0.5,0,1,0,10,0,1,0,1,0];
const PLINKO_PAY=[10,3,1.4,.8,.2,.8,1.4,3,10];
const SYMS=['🍒','🍋','🔔','🍀','💎','7️⃣'];
const SLOT_MULT={'🍒':10,'🍋':15,'🔔':20,'🍀':30,'💎':45,'7️⃣':85};
const SUITS=['♠','♥','♦','♣'],RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
let roundEpoch=0;
const rt={bets:[],rouletteSpinning:false,rouletteRotation:0,rouletteResult:null,rouletteNotice:'',rouletteTape:null,rouletteTicket:null,wheelSpinning:false,wheelRotation:0,wheelResult:null,wheelNotice:'',bj:null,crash:null,slots:null,mines:null,plinko:null,diceRoll:null,diceNotice:'',baccarat:null,coin:null,keno:null,poker:null,sicbo:null,limbo:null,hilo:null,craps:null};
function currentProfile(){return {balance:state.balance,reserved:state.reserved,stats:state.stats,rouletteHistory:state.rouletteHistory,activity:state.activity,gameStats:state.gameStats,lifetime:state.lifetime,lifetimeGames:state.lifetimeGames,manualGranted:state.manualGranted,journal:state.journal,dayBuckets:state.dayBuckets,recordWin:state.recordWin,recordLoss:state.recordLoss}}
function save(){
 if(!canModify())return false;
 if(volatileMode){profileSnapshots[state.mode]=currentProfile();return true}
 profileSnapshots[state.mode]=currentProfile();
 try{localStorage.setItem(STORAGE,JSON.stringify({...currentProfile(),mode:state.mode,profiles:profileSnapshots,dailyProgress}));return true}
 catch(e){instanceStorageAvailable=false;instanceWritable=false;return false}
}
// QA 1.7.2: memory and persistent wallet must agree even if a write fails.
// Capture both profiles because a mode switch, import or reset modifies both.
function walletCheckpoint(){return JSON.parse(JSON.stringify({mode:state.mode,current:currentProfile(),free:profileSnapshots.free,daily:profileSnapshots.daily,progress:dailyProgress}))}
function walletRestore(checkpoint){
 state.mode=checkpoint.mode;
 Object.assign(state,checkpoint.current);
 profileSnapshots.free=checkpoint.free;
 profileSnapshots.daily=checkpoint.daily;
 dailyProgress=checkpoint.progress;
}
function commitWallet(checkpoint){
 if(save())return true;
 walletRestore(checkpoint);
 updateBalance();leaseBlock();return false;
}
function switchMode(mode){
 if(!canModify()){leaseBlock();return}
 if(!['daily','free'].includes(mode)||mode===state.mode)return;
 if(state.reserved>0&&!confirm('Есть незавершённые ставки. Отменить их и вернуть фишки перед переключением режима?'))return;
 const previous=walletCheckpoint();
 if(state.reserved>0){state.balance=Math.min(BALANCE_CAP,state.balance+state.reserved);state.reserved=0}
 profileSnapshots[state.mode]=currentProfile();
 state.mode=mode;
 Object.assign(state,safeProfile(profileSnapshots[mode],mode==='daily'?DAILY_CREDIT:50000));
 if(!commitWallet(previous))return;
 resetRuntime();state.modal=null;render();toast(mode==='daily'?`Режим «Игровые дни»: день ${dailyProgress.day}`:'Свободный режим с пополнением фишек');
}
function finishDailyDay(reason='manual'){
 if(!canModify()){leaseBlock();return false}
 if(state.mode!=='daily')return false;
 if(state.reserved>0){toast('Сначала заверши ставки или отмени их на игровом столе.',true);return false}
 if(reason==='manual'&&!confirm(`Завершить день ${dailyProgress.day}? Остаток ${money(state.balance)} сгорит; на следующий день выдаётся ${money(DAILY_CREDIT)}.`))return false;
 const previous=walletCheckpoint();
 dailyProgress.history.unshift({day:dailyProgress.day,rounds:dailyProgress.rounds,wagered:dailyProgress.wagered,paid:dailyProgress.paid,leftover:state.balance,reason:reason==='empty'?'empty':'manual',at:Date.now()});
 dailyProgress.history=dailyProgress.history.slice(0,DAILY_HISTORY_LIMIT);
 dailyProgress.day=dailyProgress.day>=100000000?1:dailyProgress.day+1;dailyProgress.rounds=0;dailyProgress.wagered=0;dailyProgress.paid=0;dailyProgress.startedAt=Date.now();
 state.balance=DAILY_CREDIT;state.reserved=0;
 if(!commitWallet(previous))return false;
 resetRuntime();state.modal='day-summary';render();
 toast(`День ${dailyProgress.day}: начислено ${money(DAILY_CREDIT)}.`);return true;
}
function modeBarHTML(){const daily=state.mode==='daily';return `<div class="mode-card"><div class="mode-row"><div class="mode-title">РЕЖИМ ИГРЫ <span class="mode-help">Без настоящих денег</span></div><div class="mode-buttons"><button class="mode-choice ${daily?'':'active'}" data-action="mode-free" aria-pressed="${!daily}">∞ Свободный</button><button class="mode-choice ${daily?'active':''}" data-action="mode-daily" aria-pressed="${daily}">◷ Игровые дни</button></div></div>${daily?`<div class="daily-row"><div><strong>ДЕНЬ ${dailyProgress.day}</strong><span> На день: ${money(DAILY_CREDIT)} · Остаток: <b>${money(state.balance)}</b> · Сыграно раундов: ${dailyProgress.rounds} · Итог ставок: <b>${signedMoney(dailyProgress.paid-dailyProgress.wagered)}</b></span></div><div class="daily-actions"><button class="btn small" data-action="daily-history">История дней</button>${dailyProgress.history.length?`<button class="btn small" data-action="day-summary">Последний итог</button>`:''}<button class="btn gold small" data-action="daily-next" ${state.reserved?'disabled title="Сначала завершите все ставки"':''}>Завершить день</button></div></div>`:`<div class="free-note">Пополняй фишки сколько угодно. В режиме «Игровые дни» отдельный баланс, который невозможно пополнить вручную.</div>`}</div>`}
function renderModeBar(){const bar=document.getElementById('modeBar');if(bar)bar.innerHTML=modeBarHTML();const add=document.querySelector('.add-money');if(add)add.textContent=state.mode==='daily'?'◷':'＋';const label=document.querySelector('.wallet small');if(label)label.textContent=state.mode==='daily'?'ФИШКИ ЭТОГО ДНЯ':'МОЙ БАЛАНС'}
function rnd(max){if(max<=0)throw Error('Invalid random bound');if(globalThis.crypto?.getRandomValues){const limit=Math.floor(4294967296/max)*max;const a=new Uint32Array(1);do{crypto.getRandomValues(a)}while(a[0]>=limit);return a[0]%max}throw Error('Безопасный генератор случайных чисел недоступен')}
function unit(){return (rnd(1000000000)+.5)/1000000000}
function spend(n,maxTransaction=1000000){
 if(!globalThis.crypto?.getRandomValues){toast('В этом окружении нет безопасного генератора случайных чисел. Ставки недоступны.',true);return false}
 if(!canModify()){leaseBlock();return false}
 if(!Number.isSafeInteger(n)||n<=0||n>maxTransaction||!Number.isSafeInteger(state.reserved+n))return false;
 if(state.balance<n){toast(state.mode==='daily'?'Недостаточно фишек. Заверши день и получи новый лимит.':'Недостаточно фишек. Пополни демо-баланс.',true);return false}
 state.balance-=n;state.reserved+=n;
 if(!save()){state.balance+=n;state.reserved-=n;leaseBlock();return false}
 updateBalance();return true
}
// Reserve grouped casino bets in a single durable wallet transaction.
// Each hand remains capped at 1m. A failed save never leaves a partial debit.
function spendGrouped(stake,hands){
 if(!Number.isSafeInteger(stake)||stake<=0||stake>1000000||!Number.isInteger(hands)||hands<2||hands>3)return false;
 return spend(stake*hands,stake*hands)
}
function refund(n){
 if(!canModify()){leaseBlock();return false}
 if(!Number.isSafeInteger(n)||n<=0||n>state.reserved)throw Error('Неверный возврат фишек');
 const previous=walletCheckpoint();
 state.balance=Math.min(BALANCE_CAP,state.balance+n);state.reserved-=n;
 if(!commitWallet(previous))return false;
 updateBalance();return true
}
function settle(game,stake,payout,detail='',replay=null){if(!canModify()){leaseBlock();return false}stake=Math.round(stake);payout=Math.max(0,Math.round(payout));if(!Number.isSafeInteger(stake)||stake<=0||!Number.isSafeInteger(payout)||stake>state.reserved)throw Error('Некорректный расчёт ставки');const previous=walletCheckpoint();state.reserved-=stake;state.balance=Math.min(BALANCE_CAP,state.balance+payout);state.stats.rounds=Math.min(BALANCE_CAP,state.stats.rounds+1);state.stats.wagered=Math.min(BALANCE_CAP,state.stats.wagered+stake);state.stats.paid=Math.min(BALANCE_CAP,state.stats.paid+payout);if(payout>stake)state.stats.wins=Math.min(BALANCE_CAP,state.stats.wins+1);const id=GAMES.find(x=>x.name===game)?.id||({ 'Блэкджек':'blackjack','Колесо':'wheel','Слоты':'slots','Монетка':'coin','Рулетка':'roulette','Баккара':'baccarat','Кено':'keno','Видеопокер':'poker','Рулетка Франции':'roulette-fr','Лотерея':'lotto','Скретч':'scratch','Сундуки':'treasure'})[game]||game.toLowerCase();const g=state.gameStats[id]||(state.gameStats[id]={rounds:0,wins:0,wagered:0,paid:0});g.rounds=Math.min(BALANCE_CAP,g.rounds+1);g.wagered=Math.min(BALANCE_CAP,g.wagered+stake);g.paid=Math.min(BALANCE_CAP,g.paid+payout);if(payout>stake)g.wins=Math.min(BALANCE_CAP,g.wins+1);
 state.recordWin=Math.max(state.recordWin,payout-stake,0);state.recordLoss=Math.max(state.recordLoss,stake-payout,0);
 incrementStat(state.lifetime,stake,payout);
 if(payout>stake)state.lifetime.positiveNet=Math.min(BALANCE_CAP,state.lifetime.positiveNet+payout-stake);
 else if(payout<stake)state.lifetime.negativeNet=Math.min(BALANCE_CAP,state.lifetime.negativeNet+stake-payout);
 const lifetimeGame=state.lifetimeGames[id]||(state.lifetimeGames[id]={rounds:0,wins:0,wagered:0,paid:0});
 incrementStat(lifetimeGame,stake,payout);
 const at=Date.now(),day=localDay(at);
 let bucket=state.dayBuckets.find(x=>x.day===day);
 if(!bucket){bucket={day,rounds:0,wins:0,wagered:0,paid:0};state.dayBuckets.unshift(bucket);state.dayBuckets=state.dayBuckets.slice(0,DAY_BUCKET_LIMIT)}
 incrementStat(bucket,stake,payout);
 state.journal.unshift({at,game,stake,payout,detail,replay:safeRoundReplay(replay)});state.journal=state.journal.slice(0,JOURNAL_LIMIT);
 state.activity.unshift({game,profit:payout-stake,detail,at:new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})});state.activity=state.activity.slice(0,20);
 if(state.mode==='daily'){
  dailyProgress.rounds=Math.min(BALANCE_CAP,dailyProgress.rounds+1);dailyProgress.wagered=Math.min(BALANCE_CAP,dailyProgress.wagered+stake);dailyProgress.paid=Math.min(BALANCE_CAP,dailyProgress.paid+payout);
 }
 if(!commitWallet(previous))return false;updateBalance();let net=payout-stake;toast(`${game}: ${net>0?'выигрыш +'+money(net):net<0?'−'+money(-net):'возврат ставки'}`,net<0);
 if(state.mode==='daily'&&state.balance<10&&state.reserved===0)finishDailyDay('empty');
 return true;
}
function toast(message,negative=false){const host=document.getElementById('toastHost');while(host.children?.length>=3)host.firstElementChild.remove();const t=document.createElement('div');t.className='toast'+(negative?' negative':'');t.textContent=message;document.getElementById('toastHost').appendChild(t);setTimeout(()=>t.remove(),3300)}
function updateBalance(){const e=document.getElementById('balanceText');if(e)e.textContent=fmt(state.balance)}
function info(g){return GAMES.find(x=>x.id===g)||GAMES[0]}
function navigate(g){if(!GAMES.some(x=>x.id===g))return;state.game=g;state.modal=null;setMobileNav(false);rememberRecent(g);render();if(typeof window.scrollTo==='function')window.scrollTo(0,0)}
function openHallTable(id){navigate(id);document.getElementById('gameArea')?.scrollIntoView?.({behavior:'smooth',block:'start'})}
// Favorites are UI preferences, independent of saved chips and both wallets.
// Editorial offline discoverability order. Based on recognisability of game types,
// NOT on fictitious app-wide usage statistics. Favorites override this order.
const POPULARITY_ORDER=[
 'slots','slots5','blackjack','roulette','roulette-fr','roulette-us',
 'baccarat','poker','holdem','crash','plinko','mines','dice','coin',
 'wheel','keno','keno80','sicbo','hilo','threecard','caribbean','letitride',
 'craps','seven','bingo','bingo90','lotto','scratch','limbo','dicepoker',
 'war','dragontiger','teenpatti','andar','reddog','tower','treasure',
 'fantan','crown','pick3','cardsuit','ladder','rps','colors'
];
const POPULARITY_RANK=new Map(POPULARITY_ORDER.map((id,index)=>[id,index]));
// V1.8.6: presentation-only entry modes. Neither mode changes RNG, bets, or wallet.
const VIEW_KEY='neon-casino-view-v1';
let casinoView='casual';
try{casinoView=localStorage.getItem(VIEW_KEY)==='hall'?'hall':'casual'}catch(e){}
const CASINO_ZONES=[
 {id:'roulette',title:'Салон рулетки',icon:'◉',desc:'Три рулетки · классические и расширенные ставки',games:['roulette','roulette-fr','roulette-us','wheel']},
 {id:'cards',title:'Карточный клуб',icon:'♠',desc:'Блэкджек, покер, баккара и дуэли',games:['blackjack','holdem','poker','baccarat','threecard','caribbean','teenpatti','war','dragontiger','andar','reddog','letitride','hilo','cardsuit']},
 {id:'slots',title:'Неоновая галерея',icon:'▦',desc:'Автоматы, Crash, Plinko и быстрые игры',games:['slots','slots5','crash','plinko','mines','tower','treasure','ladder','scratch','limbo']},
 {id:'lucky',title:'Зал удачи',icon:'✦',desc:'Кубики, лотереи, числа и редкие игры',games:['dice','coin','keno','keno80','sicbo','craps','seven','bingo','bingo90','lotto','pick3','dicepoker','fantan','crown','rps','colors']}
];
let hallZone='roulette',hallQuery='';
function hallMatches(query){
 const needle=String(query||'').trim().toLocaleLowerCase('ru');
 if(!needle)return [];
 return sortedGamesForNavigation().filter(g=>[g.name,g.title,g.sub].some(t=>t.toLocaleLowerCase('ru').includes(needle)));
}
function setHallQuery(value){
 hallQuery=String(value||'').slice(0,60);
 const focused=document.activeElement?.id==='hallSearchInput';
 const caret=focused&&Number.isInteger(document.activeElement.selectionStart)?document.activeElement.selectionStart:hallQuery.length;
 applyCasinoView();
 if(focused){const field=document.getElementById('hallSearchInput');field?.focus?.();field?.setSelectionRange?.(caret,caret)}
}
function casinoHallHTML(){
 const known=new Set(GAMES.map(g=>g.id));
 const zones=CASINO_ZONES.map(z=>({...z,games:z.games.filter(id=>known.has(id))}));
 const covered=new Set(zones.flatMap(z=>z.games));
 const leftovers=GAMES.filter(g=>!covered.has(g.id));
 if(leftovers.length)zones.push({id:'more',title:'Другие игры',icon:'✧',desc:'Оставшиеся режимы',games:leftovers.map(g=>g.id)});
 const zone=zones.find(z=>z.id===hallZone)||zones[0];
 const fav=[...favoriteGames].filter(id=>known.has(id));
 const recent=recentGames.filter(id=>known.has(id)&&!fav.includes(id)).slice(0,4);
 const searching=Boolean(hallQuery.trim());
 const ordered=searching?hallMatches(hallQuery).map(g=>g.id):[...zone.games.filter(id=>favoriteGames.has(id)),...zone.games.filter(id=>!favoriteGames.has(id))];
 const headline=searching?'Поиск по всем играм':zone.title;
 const description=searching?'Результаты среди всех 44 режимов, независимо от выбранного зала.':zone.desc;
 const countLabel=searching?`${ordered.length} из ${GAMES.length} игр`:`${ordered.length} игровых мест`;
 const searchBar=`<div class="hall-search"><label for="hallSearchInput">НАЙТИ ИГРОВОЙ СТОЛ</label><div class="hall-search-field"><span aria-hidden="true">⌕</span><input id="hallSearchInput" type="search" autocomplete="off" maxlength="60" placeholder="Название игры: покер, рулетка, кено…" value="${esc(hallQuery)}" aria-label="Поиск по всем 44 играм">${searching?'<button type="button" data-action="hall-search-clear" aria-label="Очистить поиск">✕</button>':''}</div></div>`;
 const quick=(id,kind)=>{const g=info(id);return `<button class="hall-quick" data-action="hall-open" data-game="${g.id}" aria-label="Открыть ${esc(g.name)}"><span>${g.icon}</span>${esc(g.name)}<small>${kind}</small></button>`};
 const quickBar=fav.length||recent.length?`<section class="hall-quick-section" aria-label="Быстрый доступ к играм"><div class="hall-quick-caption">МОИ СТОЛЫ <small>Избранные и недавно открытые</small></div><div class="hall-quick-list">${fav.map(id=>quick(id,'★ Любимая')).join('')}${recent.map(id=>quick(id,'Недавно')).join('')}</div></section>`:'';
 return `<div class="hall-interior" aria-label="Интерактивный игровой зал"><div class="hall-ceiling"><span>✦</span><span>✧</span><span>✦</span></div><div class="hall-perspective"><div class="hall-back"><span class="hall-mark">N</span><small>NEON ROYALE</small></div><div class="hall-floor"></div></div><div class="hall-front"><div class="hall-kicker">✦ ЗАЛ ОТКРЫТ · ${GAMES.length} ИГР · ОФЛАЙН</div><h2>ТВОЁ КАЗИНО</h2><p>Выбери зал, затем стол. Любимые игры закрепляются сверху и доступны из любого зала.</p>${quickBar}${searchBar}<div class="hall-zones">${zones.map(z=>`<button class="hall-zone ${z.id===zone.id?'selected':''}" data-action="hall-zone" data-value="${z.id}" aria-pressed="${z.id===zone.id}"><b>${z.icon}</b><span>${esc(z.title)}</span></button>`).join('')}</div><div class="hall-room-title"><div><strong>${esc(headline)}</strong><small>${esc(description)}</small></div><span role="status">${countLabel}</span></div><div class="hall-tables">${ordered.map(id=>{const g=info(id);const active=favoriteGames.has(id);return `<div class="hall-station"><button class="hall-table ${state.game===id?'playing':''}" data-action="hall-open" data-game="${g.id}" aria-label="Играть: ${esc(g.name)}"><span class="hall-table-icon">${g.icon}</span><span class="hall-table-label">${esc(g.name)}</span><small>ОТКРЫТЬ СТОЛ</small></button><button class="hall-star ${active?'selected':''}" data-action="hall-favorite" data-game="${g.id}" aria-pressed="${active}" aria-label="${active?'Убрать из избранного':'Добавить в избранное'}: ${esc(g.name)}">${active?'★':'☆'}</button></div>`}).join('')}</div>${searching&&!ordered.length?'<p class="hall-search-empty" role="status">Ничего не найдено. Попробуй другое название игры.</p>':''}</div></div>`;
}

function applyCasinoView(){
 const stage=document.getElementById('hallStage'),switcher=document.getElementById('viewSwitch');
 if(stage){stage.hidden=casinoView!=='hall';if(casinoView==='hall')stage.innerHTML=casinoHallHTML()}
 const featured=document.getElementById('featuredSection');if(featured)featured.hidden=casinoView==='hall';
 if(switcher&&typeof switcher.querySelectorAll==='function')switcher.querySelectorAll('[data-action="casino-view"]').forEach(b=>{b.classList.toggle('active',b.dataset.value===casinoView);b.setAttribute('aria-pressed',String(b.dataset.value===casinoView))});
 document.body.classList?.toggle?.('hall-mode',casinoView==='hall');
}
function setCasinoView(view){
 if(!['hall','casual'].includes(view))return;
 casinoView=view;
 try{localStorage.setItem(VIEW_KEY,view)}catch(e){toast('Не удалось сохранить выбор вида на устройстве',true)}
 applyCasinoView();
}

function sortedGamesForNavigation(){
 const favOrder=[...favoriteGames];
 return [...GAMES].sort((a,b)=>{
  const af=favOrder.indexOf(a.id),bf=favOrder.indexOf(b.id);
  if(af!==-1||bf!==-1)return af===-1?1:bf===-1?-1:af-bf;
  return (POPULARITY_RANK.get(a.id)??1000)-(POPULARITY_RANK.get(b.id)??1000)
   ||GAMES.indexOf(a)-GAMES.indexOf(b);
 });
}
function refreshFeaturedGames(){
 const host=document.getElementById('featuredGames');if(!host)return;
 host.innerHTML=sortedGamesForNavigation().slice(0,6).map(g=>
  `<button class="feature-game" data-action="nav" data-game="${g.id}" aria-label="Открыть ${esc(g.name)}"><span class="feature-ico">${g.icon}</span><span class="feature-title">${esc(g.name.toLocaleUpperCase('ru'))}</span><span class="feature-arrow">↗</span></button>`
 ).join('');
 const c=document.getElementById('featuredCaption');if(c)c.textContent=favoriteGames.size?'★ ИЗБРАННОЕ И ПОПУЛЯРНОЕ':'✦ ПОПУЛЯРНЫЕ ИГРЫ';
}
function reorderNavigationRows(){
 const host=document.getElementById('gameNav');if(!host)return;
 const rows=new Map([...host.querySelectorAll('.nav-entry')].map(x=>[x.querySelector('.nav-item')?.dataset.game,x]));
 for(const g of sortedGamesForNavigation()){const row=rows.get(g.id);if(row)host.appendChild(row)}
 refreshFeaturedGames();syncGameSearch();
}
const FAVORITES_STORAGE='neon-casino-favorites-v1';
let favoriteGames=new Set(),favoritesOnly=false;
// UI-only recent games: never touches the wallet or the activity log.
const RECENT_STORAGE='neon-casino-recent-v1';
let recentGames=[];
function restoreRecent(){
 try{const raw=JSON.parse(localStorage.getItem(RECENT_STORAGE)||'[]');
  if(Array.isArray(raw))recentGames=[...new Set(raw.filter(id=>typeof id==='string'&&GAMES.some(g=>g.id===id)))].slice(0,4);
 }catch(e){recentGames=[]}
}
function renderRecent(){
 const host=document.getElementById('recentGames');if(!host)return;
 host.innerHTML=recentGames.map(id=>{const g=GAMES.find(x=>x.id===id);return g?`<button class="recent-game" data-action="nav" data-game="${g.id}" title="${esc(g.name)}">${g.icon} ${esc(g.name)}</button>`:''}).join('');
 host.hidden=!recentGames.length;
}
function rememberRecent(id){
 if(!GAMES.some(g=>g.id===id))return;
 recentGames=[id,...recentGames.filter(v=>v!==id)].slice(0,4);
 try{localStorage.setItem(RECENT_STORAGE,JSON.stringify(recentGames));localStorage.setItem(VIEW_KEY,casinoView)}catch(e){}
 renderRecent();
}
function restoreFavorites(){
 try{const data=JSON.parse(localStorage.getItem(FAVORITES_STORAGE)||'[]');
  if(Array.isArray(data))favoriteGames=new Set(data.filter(id=>typeof id==='string'&&GAMES.some(g=>g.id===id)).slice(0,GAMES.length));
 }catch(e){favoriteGames=new Set()}
}
function toggleFavorite(id){
 if(!GAMES.some(g=>g.id===id))return;
 const wasFavorite=favoriteGames.has(id);
 if(wasFavorite)favoriteGames.delete(id);else favoriteGames.add(id);
 try{localStorage.setItem(FAVORITES_STORAGE,JSON.stringify([...favoriteGames]))}
 catch(e){
  if(wasFavorite)favoriteGames.add(id);else favoriteGames.delete(id);
  toast('Не удалось сохранить избранное — изменение отменено',true);
  return;
 }
 // Don't reconstruct the running game panel just to redraw a star.
 if(typeof document.querySelector==='function'){
  const button=document.querySelector(`[data-action="favorite-toggle"][data-game="${id}"]`);
  if(button){button.classList.toggle('is-favorite',!wasFavorite);button.setAttribute('aria-pressed',String(!wasFavorite));button.setAttribute('aria-label',`${!wasFavorite?'Убрать из избранного: ':'Добавить в избранное: '}${GAMES.find(g=>g.id===id).name}`);button.textContent=!wasFavorite?'★':'☆'}
 }
 reorderNavigationRows();
}
let lastRenderedNavigation=null;
function render(){renderModeBar();let g=info(state.game);document.getElementById('headerGame').textContent=g.name.toUpperCase();document.getElementById('pageTitle').textContent=g.title;document.getElementById('pageSubtitle').textContent=g.sub;if(lastRenderedNavigation===null){document.getElementById('gameNav').innerHTML=sortedGamesForNavigation().map(x=>`<div class="nav-entry"><button class="nav-item ${x.id===state.game?'active':''}" data-action="nav" data-game="${x.id}"><span class="nav-ico">${x.icon}</span><span class="nav-game-name">${esc(x.name)}</span>${POPULARITY_RANK.get(x.id)<6?'<span class="nav-tag">ТОП</span>':''}</button><button class="favorite-toggle ${favoriteGames.has(x.id)?'is-favorite':''}" type="button" data-action="favorite-toggle" data-game="${x.id}" aria-pressed="${favoriteGames.has(x.id)}" aria-label="${favoriteGames.has(x.id)?'Убрать из избранного: ':'Добавить в избранное: '}${esc(x.name)}">${favoriteGames.has(x.id)?'★':'☆'}</button></div>`).join('');lastRenderedNavigation='ready'}if(typeof document.querySelectorAll==='function')document.querySelectorAll('#gameNav .nav-item').forEach(el=>el.classList.toggle('active',el.dataset.game===state.game));document.getElementById('gameArea').innerHTML=gameHTML();document.getElementById('rightPanel').innerHTML=rightHTML();updateBalance();refreshFeaturedGames();applyCasinoView();if(typeof document.querySelectorAll==='function'){document.querySelectorAll('.feature-game').forEach(el=>el.classList.toggle('active',el.dataset.game===state.game));syncGameSearch()}renderModal();if(state.game==='plinko')drawPlinko();if(state.game==='crash'&&rt.crash?.active)updateCrashVisual()}
function gameHTML(){switch(state.game){case'roulette':return rouletteHTML();case'blackjack':return blackjackHTML();case'wheel':return luckyHTML();case'crash':return crashHTML();case'slots':return slotsHTML();case'mines':return minesHTML();case'plinko':return plinkoHTML();case'dice':return diceHTML();case'baccarat':return baccaratHTML();case'coin':return coinHTML();case'keno':return kenoHTML();case'poker':return pokerHTML();case'sicbo':return sicboHTML();case'limbo':return limboHTML();case'hilo':return hiloHTML();case'craps':return crapsHTML();case'roulette-us':return variantRouletteHTML('us');case'roulette-fr':return variantRouletteHTML('fr');case'threecard':return threecardHTML();case'war':return warHTML();case'dragontiger':return dragonHTML();case'tower':return towerHTML();case'bingo':return bingoHTML();case'lotto':return lottoHTML();case'scratch':return scratchHTML();case'seven':return sevenHTML();case'dicepoker':return dicePokerHTML();case'treasure':return treasureHTML();default:return''}}
function amountHTML(){return `<span class="panel-label">РАЗМЕР СТАВКИ (◈)</span><div class="amount-line"><button class="amount-step" data-action="amount-step" data-delta="-1">−</button><input id="stakeInput" class="amount-input" type="number" step="10" min="10" max="1000000" value="${state.stake}" aria-label="Ставка"><button class="amount-step" data-action="amount-step" data-delta="1">+</button></div><div class="quick-amounts">${[10,100,500,1000,5000].map(n=>`<button class="chip-quick ${state.stake===n?'active':''}" data-action="set-stake" data-value="${n}">${fmt(n)}</button>`).join('')}</div>`}
function betPanel(buttonLabel='ИГРАТЬ',action='generic-play',disabled=false,extra=''){return `<div class="panel"><div class="panel-header"><h3>Управление ставкой</h3><span class="subcap">ВИРТУАЛЬНЫЕ ФИШКИ</span></div><div class="panel-body">${amountHTML()}${extra}<button class="btn primary block" style="margin-top:16px" data-action="${action}" ${disabled?'disabled':''}>${buttonLabel}</button></div></div>`}
function gameRules(){const rules={roulette:'<strong>Европейская рулетка:</strong> один зеро (0), 37 ячеек. Число — 35:1; цвет, чёт/нечёт, 1–18/19–36 — 1:1; дюжина и колонка — 2:1. Ставки суммируются. Нажми на число или сектор стола.',blackjack:'<strong>Блэкджек:</strong> приблизься к 21, не перебирая. Туз = 1 или 11. Дилер стоит на любых 17. Натуральный 21 платит 3:2. Двойная ставка — ровно одна карта; разделение доступно для пары одного ранга.',wheel:'<strong>Колесо:</strong> каждый из 24 секторов равновероятен. Выплата = ставка × показанный множитель (включая нулевые сектора).',crash:'<strong>Crash:</strong> множитель растёт, пока раунд внезапно не завершится. Нужно нажать «Забрать» до остановки. Серверов нет, результат генерируется локально; крайнее значение ×100.',slots:'<strong>Слоты:</strong> комбинации учитываются по трём горизонтальным и двум диагональным линиям. Три одинаковых символа дают выплату. Общая ставка делится на пять линий.',mines:'<strong>Mines:</strong> поля 4×4, 5×5, 4×8, 6×6, 7×7, 8×8, 10×10. Чем больше мин и открытых безопасных клеток, тем выше выплата. Можно забрать текущий выигрыш после первого успешного открытия.',plinko:'<strong>Plinko:</strong> шар проходит 8 случайных отклонений и попадает в один из девяти карманов. Множители указаны под полем. Каждый поворот равновероятен.',dice:'<strong>Dice:</strong> выбирай вероятность от 5% до 95% и ставь на число ниже либо выше порога. Выплата при победе = ставка × 0,97 / вероятность.',baccarat:'<strong>Баккара:</strong> ставка на игрока, банкира или ничью. Стандартные правила Punto Banco, третья карта добирается автоматически. Игрок — 1:1; банкир — 0,95:1; ничья — 8:1. При ничьей обычные ставки возвращаются.',coin:'<strong>Монетка:</strong> шансы 50/50, выплата при победе ×1,95. Каждый бросок независим.',keno:'<strong>Кено 5 из 40:</strong> отметь ровно 5 чисел. Система случайно выбирает 10 чисел из 40. Совпадения: 2 → ×2, 3 → ×2,5, 4 → ×12, 5 → ×200; остальные проигрывают.',poker:'<strong>Jacks or Better:</strong> получи пять карт, нажми на карты, которые хочешь оставить, затем замени остальные. Выплата за пару валетов и старше, две пары, тройку, стрит, флеш и старшие комбинации.',sicbo:'<strong>Sic Bo:</strong> три кубика, 35 вариантов ставок. Малое/большое исключают тройки (×2), любая тройка ×25, точная тройка ×181, суммы от 4 до 17, пары и отдельные числа имеют собственные коэффициенты.',limbo:'<strong>Limbo:</strong> сам выбираешь множитель. Вероятность достижения ×M равна 97% / M. Выигрышная выплата = ставка × M. Только виртуальные фишки.',hilo:'<strong>Выше / ниже:</strong> угадай, будет ли следующий ранг выше или ниже открытой карты. Ранги: A (низкий) – K. При равенстве возвращается ставка. Множитель учитывает количество подходящих рангов.',craps:'<strong>Craps:</strong> Pass Line — 7/11 побеждают сразу, 2/3/12 проигрывают; после пойнта нужно выбросить его до семёрки. Don’t Pass — 2/3 побеждают, 12 возвращает ставку, 7/11 проигрывают; после пойнта выигрывает семёрка. Победа ×2.'};Object.assign(rules,EXTRA_RULES,MORE_RULES);return rules}
function rightHTML(){const rules=gameRules();const stats=state.stats,gs=state.gameStats[state.game]||{rounds:0,wins:0,wagered:0,paid:0};const recent=state.activity.slice(0,5).map(a=>`<div class="act"><span>${esc(a.game)} <span class="muted">${esc(a.at)}</span></span><b class="${a.profit<0?'loss':''}">${a.profit>0?'+':''}${fmt(a.profit)}</b></div>`).join('');return `<div class="panel"><div class="panel-header"><h3>Твоя статистика</h3><span class="subcap">ВСЕ ИГРЫ</span></div><div class="panel-body"><div class="stats"><div class="stat"><span>Раундов</span><b>${fmt(stats.rounds)}</b></div><div class="stat"><span>Выигрышей</span><b class="accent">${fmt(stats.wins)}</b></div><div class="stat"><span>Всего ставок</span><b>${fmt(stats.wagered)}</b></div><div class="stat"><span>Чистый результат</span><b class="${stats.paid>=stats.wagered?'accent':'goldtext'}">${stats.paid>=stats.wagered?'+':''}${fmt(stats.paid-stats.wagered)}</b></div></div><div class="stats game-stats"><div class="stat"><span>В этой игре</span><b>${fmt(gs.rounds)} раундов</b></div><div class="stat"><span>Результат игры</span><b class="${gs.paid>=gs.wagered?'accent':'goldtext'}">${gs.paid>=gs.wagered?'+':''}${fmt(gs.paid-gs.wagered)}</b></div></div><button class="btn ghost small block" style="margin-top:13px" data-action="wallet">${state.mode==='daily'?'◷ Правила игрового дня':'＋ Выдать себе фишки'}</button></div></div><div class="panel"><div class="panel-header"><h3>Правила игры</h3><span class="subcap">КАК ИГРАТЬ</span></div><div class="panel-body"><div class="rules">${rules[state.game]||"Правила уточняются."}</div><button type="button" class="btn ghost small block" style="margin-top:12px" data-action="game-guide">ⓘ Пошаговая инструкция</button></div></div><div class="panel"><div class="panel-header"><h3>Последние результаты</h3><button class="link-btn" data-action="reset-stats">Сбросить</button></div><div class="panel-body"><div class="activity">${recent||'<div class="empty-note">Пока нет сыгранных раундов</div>'}</div></div></div>`}
function resultNote(msg,kind=''){return msg?`<div class="result-notice ${kind}">${esc(msg)}</div>`:''}
function outcomeColor(n){return n===0?'green':REDS.has(n)?'red':'black'}
function sectorSVG(labels,colors,size=300){const cnt=labels.length,sector=360/cnt,rad=size/2,outer=rad-6,center=rad;const parts=[];for(let i=0;i<cnt;i++){const a1=(-90+i*sector)*Math.PI/180,a2=(-90+(i+1)*sector)*Math.PI/180;let x1=center+outer*Math.cos(a1),y1=center+outer*Math.sin(a1),x2=center+outer*Math.cos(a2),y2=center+outer*Math.sin(a2);parts.push(`<path d="M ${center} ${center} L ${x1.toFixed(2)} ${y1.toFixed(2)} A ${outer} ${outer} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z" fill="${colors[i]}" stroke="#f6e3ae" stroke-width="${cnt>20?.7:1.5}"/>`);const mid=(-90+(i+.5)*sector)*Math.PI/180;const tr=outer*(cnt>20?.79:.70);const x=center+tr*Math.cos(mid),y=center+tr*Math.sin(mid);parts.push(`<text x="${x.toFixed(2)}" y="${y.toFixed(2)}" font-size="${cnt>20?12:17}" font-weight="900" fill="white" text-anchor="middle" dominant-baseline="middle" transform="rotate(${(-90+(i+.5)*sector+90).toFixed(2)} ${x.toFixed(2)} ${y.toFixed(2)})">${labels[i]}</text>`)}return `<svg viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" aria-label="Игровое колесо"><circle cx="${center}" cy="${center}" r="${rad-1}" fill="#9f8151" stroke="#cbb077" stroke-width="3"/>${parts.join('')}<circle cx="${center}" cy="${center}" r="${cnt>20?29:24}" fill="#163b3c" stroke="#d3ba75" stroke-width="6"/><circle cx="${center}" cy="${center}" r="7" fill="#f0d595"/></svg>`}
function tapeHTML(){const nums=rt.rouletteTape||[...Array(26)].map(()=>RNUM[rnd(37)]);return `<div class="tape-viewport"><div class="tape-cursor"></div><div id="tapeTrack" class="tape-track">${nums.map(n=>`<span class="tape-number ${outcomeColor(n)}">${n}</span>`).join('')}</div></div>`}

function rouletteTicketHTML(ticket){
 if(!ticket)return '';
 const won=ticket.wins;
 const label=b=>({number:'Число',combo:'Комбинация',color:'Цвет',low:'1–18',high:'19–36',odd:'Нечёт',even:'Чёт',dozen:'Дюжина',column:'Колонка'})[b.type]||'Ставка';
 const short=b=>b.type==='color'?(b.value==='red'?'красное':'чёрное'):(['low','high','odd','even'].includes(b.type)?'':String(b.value));
 return `<section class="roulette-ticket ${ticket.payout>ticket.stake?'is-win':'is-loss'}" aria-label="Итог последнего вращения">
 <div class="ticket-heading"><span>◈ ЧЕК ПОСЛЕДНЕГО ВРАЩЕНИЯ</span><b class="ball-mini ${outcomeColor(ticket.number)}">${ticket.number}</b></div>
 <div class="ticket-totals"><span>Поставлено <b>${money(ticket.stake)}</b></span><span>Выплачено <b>${money(ticket.payout)}</b></span><span>Итог <b>${ticket.payout>=ticket.stake?'+':''}${money(ticket.payout-ticket.stake)}</b></span></div>
 <div class="ticket-winning">${won.length?`<strong>Выигравшие ставки: ${won.length}</strong>${won.slice(0,6).map(b=>`<div><span>${label(b)} ${esc(short(b))} · ${money(b.amount)}</span><b>+${money(b.payout)}</b></div>`).join('')}${won.length>6?`<small>И ещё ${won.length-6} выигравших ставок · полный журнал в профиле</small>`:''}`:'Ни одна ставка не сыграла. Это не влияет на вероятность следующего числа.'}</div>
 </section>`;
}
function rouletteHTML(){const last=rt.rouletteResult??state.rouletteHistory[0]?.n??'—';const latest=state.rouletteHistory.slice(0,10);const grouped=new Map();rt.bets.forEach(b=>{const k=b.type+':'+b.value;grouped.set(k,(grouped.get(k)||0)+b.amount)});const badge=(type,value)=>grouped.has(type+':'+value)?`<span class="bet-mark">${fmt(grouped.get(type+':'+value))}</span>`:'';let numCells='';for(let row=2;row>=0;row--)for(let col=0;col<12;col++){const n=col*3+row+1;numCells+=`<button class="bet-cell ${outcomeColor(n)} ${!rt.rouletteSpinning&&last===n?'last-winning-number':''}" data-action="${state.rouletteTableMode==='pro'?'roulette-anchor':'roulette-bet'}" data-type="number" data-value="${n}" ${rt.rouletteSpinning?'disabled':''}>${n}${badge('number',n)}</button>`}const out=(text,type,value,extra='')=>`<button class="outside-bet ${extra}" data-action="roulette-bet" data-type="${type}" data-value="${value}" ${rt.rouletteSpinning?'disabled':''}>${text}${badge(type,value)}</button>`;return `<div class="hero-table"><div class="roulette-top"><div class="roulette-wheel-wrap"><div class="wheel-needle"></div><div class="ball-orbit ${rt.rouletteSpinning?'is-spinning':''}" aria-hidden="true"><i class="roulette-ball"></i></div><div class="roulette-wheel" id="rouletteWheel" style="transform:rotate(${rt.rouletteRotation}deg)">${sectorSVG(RNUM,RNUM.map(n=>n===0?'#11926f':REDS.has(n)?'#c13c4c':'#242938'))}</div></div><div class="roulette-display"><span class="panel-label">${rt.rouletteSpinning?'КОЛЕСО КРУТИТСЯ':'ПОСЛЕДНЕЕ ЧИСЛО'}</span><div class="center-result ${Number.isInteger(last)?outcomeColor(last):''} ${rt.rouletteSpinning?'is-spinning':'result-highlight'}">${last}</div><h2>${rt.rouletteSpinning?'Ожидание результата…':'Ставь на удачу'}</h2><div class="tiny">Европейская рулетка · RTP ≈ 97,3%</div><button class="btn primary" data-action="roulette-spin" ${rt.rouletteSpinning||!rt.bets.length?'disabled':''}>◉ &nbsp; КРУТИТЬ КОЛЕСО</button></div></div>${tapeHTML()}<div class="history-strip"><span class="panel-label">ИСТОРИЯ</span><div class="history-numbers">${latest.map(x=>`<span class="ball-mini ${outcomeColor(x.n)}">${x.n}</span>`).join('')||'<span class="tiny">Нет вращений</span>'}</div><button class="link-btn" data-action="history">Вся история ›</button></div></div><div class="panel betting-panel"><div class="panel-header"><h2>Игровой стол</h2><span class="subcap">ВЫБЕРИ ФИШКУ ИЛИ СУММУ</span></div><div class="betting-content"><div class="roulette-mode-bar" role="group" aria-label="Тип рулеточного стола"><button class="btn small ${state.rouletteTableMode==='classic'?'gold':'ghost'}" data-action="roulette-table" data-value="classic">Классический стол</button><button class="btn small ${state.rouletteTableMode==='pro'?'gold':'ghost'}" data-action="roulette-table" data-value="pro">Комбинации и соседи</button></div>${state.rouletteTableMode==='pro'?rouletteProHTML():''}<div class="roulette-board-scroll"><div class="roulette-grid-wrap"><button class="zero-cell" data-action="${state.rouletteTableMode==='pro'?'roulette-anchor':'roulette-bet'}" data-type="number" data-value="0" ${rt.rouletteSpinning?'disabled':''}>0${badge('number',0)}</button><div class="number-grid">${numCells}</div></div><div class="outside-grid dozen">${out('1–12','dozen','1')}${out('13–24','dozen','2')}${out('25–36','dozen','3')}</div><div class="outside-grid">${out('1–18','low','low')}${out('ЧЁТ','even','even')}${out('🔴 КРАСНОЕ','color','red','red')}${out('⚫ ЧЁРНОЕ','color','black','black')}${out('НЕЧЁТ','odd','odd')}${out('19–36','high','high')}</div><div class="outside-grid dozen">${out('Колонка 1','column','1')}${out('Колонка 2','column','2')}${out('Колонка 3','column','3')}</div></div><p class="main-scroll-hint">↔ На телефоне стол можно прокручивать вбок</p><div class="chip-toolbar"><div class="chip-stack">${[10,50,100,500,1000].map(n=>`<button class="chip-button ${state.chip===n?'active':''}" data-action="chip" data-value="${n}" title="${n} фишек">${n>=1000?'1K':n}</button>`).join('')}</div><label class="roulette-custom-bet ${state.rouletteUseCustom?'active':''}" for="rouletteCustomAmount"><span>СВОЯ СУММА <small>от 1 до 100 млн ◈</small></span><input id="rouletteCustomAmount" type="number" min="1" max="100000000" step="1" inputmode="numeric" value="${esc(state.rouletteCustomStake)}" ${rt.rouletteSpinning?'disabled':''} aria-label="Своя сумма ставки на одну ячейку"><span class="custom-bet-hint">Вводи сумму, затем нажми на поле стола</span></label><div class="button-row roulette-actions"><button class="btn small" data-action="roulette-repeat" ${!lastRouletteBets.length||rt.rouletteSpinning||rt.bets.length?'disabled':''} title="Поставить как в предыдущем вращении">⟳ Повторить</button><button class="btn small gold" data-action="roulette-double" ${!rt.bets.length||rt.rouletteSpinning?'disabled':''} title="Добавить такие же ставки на стол">×2 Ставку</button><button class="btn small" data-action="roulette-undo" ${!rt.bets.length||rt.rouletteSpinning?'disabled':''}>↶ Отменить</button><button class="btn small ghost" data-action="roulette-clear" ${!rt.bets.length||rt.rouletteSpinning?'disabled':''}>Очистить</button></div></div><div class="wager-summary">Ставок: <b>${rt.bets.length}</b> · На столе: <b class="goldtext">${money(rt.bets.reduce((s,b)=>s+b.amount,0))}</b></div>${resultNote(rt.rouletteNotice,rt.rouletteNotice.startsWith('Выигрыш')?'win':'')}${!rt.rouletteSpinning?rouletteTicketHTML(rt.rouletteTicket):''}</div></div>`}
function spinDuration(ms){
 const reduced=typeof window!=='undefined'&&typeof window.matchMedia==='function'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 return (qualityMode==='lite'||reduced)?Math.min(ms,380):ms
}
function wheelRotateTo(id,current,index,count,loops=6){const step=360/count;const target=(360-(index+.5)*step)%360;const extra=(target-((current%360+360)%360)+360)%360;const next=current+loops*360+extra;const el=document.getElementById(id);if(el){requestAnimationFrame(()=>{el.style.transitionDuration=spinDuration(3800)+'ms';el.style.transform=`rotate(${next}deg)`})}return next}
// A professional layout changes placement only, not wheel odds.
function rouletteGroup(kind,anchor){
 if(!Number.isInteger(anchor)||anchor<0||anchor>36)return null;
 const street=1+3*Math.floor((anchor-1)/3);
 if(kind==='single')return [anchor];
 if(kind==='neighbors')return Array.from({length:5},(_,i)=>RNUM[(RNUM.indexOf(anchor)+i-2+37)%37]);
 if(anchor===0)return null;
 if(kind==='split-right')return anchor<=33?[anchor,anchor+3]:null;
 if(kind==='split-up')return anchor%3!==0?[anchor,anchor+1]:null;
 if(kind==='street')return [street,street+1,street+2];
 if(kind==='corner')return anchor<=33&&anchor%3!==0?[anchor,anchor+1,anchor+3,anchor+4]:null;
 if(kind==='sixline')return street<=31?[street,street+1,street+2,street+3,street+4,street+5]:null;
 return null;
}
const ROULETTE_COMBO_ODDS=Object.freeze({2:17,3:11,4:8,6:5});
function rouletteProHTML(){const a=state.rouletteAnchor,items=[['single','Одно число · 35:1'],['split-right','Разделённая → · 17:1'],['split-up','Разделённая ↑ · 17:1'],['street','Улица · 11:1'],['corner','Угол · 8:1'],['sixline','Шесть чисел · 5:1'],['neighbors','5 соседей на колесе · ставки по числам']];return `<section class="roulette-pro-panel"><div class="roulette-pro-head"><b>Выбрано число <span>${a}</span></b><small>Нажми на любое число на поле и выбери комбинацию ниже</small></div><div class="roulette-pro-grid">${items.map(([k,label])=>{const nums=rouletteGroup(k,a);return `<button class="btn small" data-action="roulette-combo" data-value="${k}" ${rt.rouletteSpinning||!nums?'disabled':''}><b>${label}</b><small>${nums?nums.join(' · '):'Недоступно для этого числа'}</small></button>`}).join('')}</div><p class="tiny">Комбинации: одна выбранная сумма на весь набор чисел. «5 соседей»: выбранная сумма ставится на КАЖДОЕ из пяти чисел; до установки списывается общая сумма.</p></section>`}
function roulettePlaceCombo(kind){
 if(rt.rouletteSpinning)return;
 const numbers=rouletteGroup(kind,state.rouletteAnchor);if(!numbers)return;
 const amount=state.rouletteUseCustom?Number(state.rouletteCustomStake):state.chip;
 if(!Number.isSafeInteger(amount)||amount<1||amount>MAX_ROULETTE_BET){toast('Укажи целую сумму от 1 до 100 млн',true);return}
 const additional=kind==='neighbors'?numbers.length:1,stake=amount*additional;
 if(rt.bets.length+additional>300||!Number.isSafeInteger(stake)||stake>MAX_ROULETTE_BET*300){toast('Превышен лимит ставок на столе',true);return}
 if(!spend(stake,MAX_ROULETTE_BET*300))return;
 if(kind==='neighbors')rt.bets.push(...numbers.map(n=>({type:'number',value:String(n),amount})));
 else if(kind==='single')rt.bets.push({type:'number',value:String(numbers[0]),amount});
 else rt.bets.push({type:'combo',value:numbers.join(','),amount});
 rt.rouletteNotice='';render();
}
function rouletteRepeat(){
 if(rt.rouletteSpinning||rt.bets.length||!lastRouletteBets.length)return;
 const total=lastRouletteBets.reduce((n,b)=>n+b.amount,0);
 if(lastRouletteBets.length>300||lastRouletteBets.some(b=>b.amount>MAX_ROULETTE_BET)||total>MAX_ROULETTE_BET*300){toast('Предыдущую ставку повторить нельзя',true);return}
 if(!spend(total,MAX_ROULETTE_BET*300))return;
 rt.bets=lastRouletteBets.map(b=>({...b}));rt.rouletteNotice='';render();
}
function rouletteDouble(){
 if(rt.rouletteSpinning||!rt.bets.length)return;
 if(rt.bets.length*2>300||rt.bets.some(b=>b.amount>MAX_ROULETTE_BET)){toast('Лимит ставок: 300 на столе',true);return}
 const total=rt.bets.reduce((n,b)=>n+b.amount,0);
 if(!spend(total,MAX_ROULETTE_BET*300))return;
 rt.bets.push(...rt.bets.map(b=>({...b})));rt.rouletteNotice='';render();
}
function rouletteBet(type,value){if(rt.rouletteSpinning)return;const allowed={number:Number.isInteger(Number(value))&&Number(value)>=0&&Number(value)<=36,color:['red','black'].includes(value),low:value==='low',high:value==='high',odd:value==='odd',even:value==='even',dozen:['1','2','3'].includes(String(value)),column:['1','2','3'].includes(String(value))};if(!allowed[type])return;
 const amount=state.rouletteUseCustom?Number(state.rouletteCustomStake):state.chip;
 if(!Number.isSafeInteger(amount)||amount<1||amount>MAX_ROULETTE_BET){toast('Сумма ставки: целое число от 1 до 100 000 000 фишек',true);return}
 if(rt.bets.length>=300){toast('На столе максимум 300 отдельных ставок',true);return}
 if(!spend(amount,MAX_ROULETTE_BET))return;
 rt.bets.push({type,value,amount});rt.rouletteNotice='';render()}
function rouletteWin(b,n){switch(b.type){case'combo':{const parts=String(b.value).split(',').map(Number);return parts.includes(n)?(ROULETTE_COMBO_ODDS[parts.length]||0):0;}case'number':return Number(b.value)===n?35:0;case'color':return outcomeColor(n)===b.value?1:0;case'low':return n>=1&&n<=18?1:0;case'high':return n>=19&&n<=36?1:0;case'even':return n!==0&&n%2===0?1:0;case'odd':return n%2===1?1:0;case'dozen':return n!==0&&Math.ceil(n/12)===Number(b.value)?2:0;case'column':return n!==0&&(n-1)%3+1===Number(b.value)?2:0;default:return 0}}
function spinRoulette(){
 if(rt.rouletteSpinning||!rt.bets.length)return;
 const epoch=roundEpoch,n=rnd(37),bets=rt.bets.splice(0);
 lastRouletteBets=bets.map(b=>({...b}));
 const stake=bets.reduce((sum,b)=>sum+b.amount,0);
 rt.rouletteSpinning=true;rt.rouletteNotice='';rt.rouletteTicket=null;
 rt.rouletteTape=Array.from({length:65},()=>RNUM[rnd(37)]);rt.rouletteTape[52]=n;
 render();
 rt.rouletteRotation=wheelRotateTo('rouletteWheel',rt.rouletteRotation,RNUM.indexOf(n),37,7);
 const t=document.getElementById('tapeTrack'),viewport=t?.parentElement;
 if(t&&viewport){const targetX=-(52*64+30-viewport.clientWidth/2);requestAnimationFrame(()=>{t.style.transition='transform '+spinDuration(4000)+'ms cubic-bezier(.08,.75,.09,1)';t.style.transform=`translateX(${targetX}px)`})}
 setTimeout(()=>{
  if(epoch!==roundEpoch)return;
  const wins=bets.flatMap(b=>{const odds=rouletteWin(b,n);return odds>0?[{...b,payout:b.amount*(odds+1)}]:[]});
  const payout=wins.reduce((sum,b)=>sum+b.payout,0);
  rt.rouletteResult=n;rt.rouletteSpinning=false;rt.rouletteTape=null;
  rt.rouletteTicket={number:n,stake,payout,wins};
  state.rouletteHistory.unshift({n,at:Date.now(),stake,payout});state.rouletteHistory=state.rouletteHistory.slice(0,80);
  rt.rouletteNotice=payout>0?`Выигрыш: ${money(payout)} · выпало ${n}`:`Выпало ${n} · попробуй ещё раз`;
  settle('Рулетка',stake,payout,`Число ${n}`,{type:'roulette',number:n,bets:bets.map(b=>({type:b.type,value:b.value,amount:b.amount}))});
  if(state.game==='roulette')render();
 },spinDuration(4200));
}
function newDeck(count=6){let cards=[];for(let k=0;k<count;k++)for(let r of RANKS)for(let suit of SUITS)cards.push({rank:r,suit});for(let i=cards.length-1;i>0;i--){let j=rnd(i+1);[cards[i],cards[j]]=[cards[j],cards[i]]}return cards}
function draw(deck){if(!deck.length)deck.push(...newDeck());return deck.pop()}
function cardVal(card){return card.rank==='A'?11:['J','Q','K'].includes(card.rank)?10:Number(card.rank)}
function handVal(cards){let points=cards.reduce((n,c)=>n+cardVal(c),0);let aces=cards.filter(c=>c.rank==='A').length;while(points>21&&aces>0){points-=10;aces--}return points}
function cardHTML(card,back=false){return `<div class="playing-card ${back?'back':(['♥','♦'].includes(card.suit)?'red':'')}"><span>${back?'?':card.rank}</span><span class="suit">${back?'✦':card.suit}</span></div>`}
function blackjackHTML(){const b=rt.bj;let stage=b?.stage||'idle';const done=stage==='done';let dealer=b?b.dealer:[],hands=b?.hands||[];let playable=stage==='playing';const active=hands[b?.active||0]||null;const canSplit=playable&&hands.length===1&&active.cards.length===2&&active.cards[0].rank===active.cards[1].rank&&state.balance>=active.stake;const canDouble=playable&&active?.cards.length===2&&state.balance>=active.stake;let controls=playable?`<div class="table-buttons"><button class="btn primary" data-action="bj-hit">ЕЩЁ КАРТУ</button><button class="btn gold" data-action="bj-stand">ХВАТИТ</button><button class="btn" data-action="bj-double" ${canDouble?'':'disabled'}>Удвоить</button><button class="btn" data-action="bj-split" ${canSplit?'':'disabled'}>Разделить</button></div>`:!b||done?`<div class="table-buttons"><button class="btn primary" data-action="bj-deal">${done?'НОВАЯ РАЗДАЧА':'РАЗДАТЬ КАРТЫ'}</button></div>`:'';let playerHTML=hands.length?`<div class="split-hands">${hands.map((h,i)=>`<div class="split-hand ${playable&&b.active===i?'active':''}"><div class="hand-info">${hands.length>1?'Рука '+(i+1):'ТВОИ КАРТЫ'} · ${handVal(h.cards)} очков · ${fmt(h.stake)} ◈</div><div class="hand">${h.cards.map(c=>cardHTML(c)).join('')}</div>${h.outcome?`<span class="status-pill ${h.payout>h.stake?'green':h.payout<h.stake?'red':''}">${h.outcome}</span>`:''}</div>`).join('')}</div>`:`<div class="hand"><div class="playing-card back"><span>?</span></div><div class="playing-card back"><span>?</span></div></div>`;return `<div class="card-felt"><div class="table-sign">BLACKJACK PAYS 3 TO 2 • DEALER STANDS ON 17</div><div class="hand-info">ДИЛЕР · ${b?(playable?cardVal(dealer[0]):handVal(dealer)):'—'} ${playable?'(вторая карта скрыта)':'очков'}</div><div class="hand">${dealer.length?dealer.map((c,i)=>cardHTML(c,playable&&i===1)).join(''):`${cardHTML({rank:'A',suit:'♠'},true)}${cardHTML({rank:'K',suit:'♥'},true)}`}</div><div class="table-sign" style="opacity:.7;margin:15px 0">✧ ───────────────── ✧</div>${playerHTML}<div class="center-message">${esc(b?.message||'Добро пожаловать за стол!')}</div>${controls}</div><div class="panel betting-panel"><div class="panel-header"><h3>Настройки раунда</h3><span class="subcap">СТАНДАРТНОЕ КАЗИНО</span></div><div class="panel-body">${amountHTML()}<p class="tiny">Натуральный блэкджек: ×2,5 к ставке · Победа: ×2 · Ничья: возврат. Выплата выполняется после окончания раздачи.</p></div></div>`}
function dealBlackjack(){if(rt.bj?.stage==='playing'){toast('Сначала закончи раздачу',true);return}if(!spend(state.stake))return;const deck=newDeck(),h=[draw(deck),draw(deck)],d=[draw(deck),draw(deck)];rt.bj={stage:'playing',deck,dealer:d,hands:[{cards:h,stake:state.stake,finished:false,fromSplit:false}],active:0,message:'Возьми карту или остановись'};if(handVal(h)===21||handVal(d)===21)finishBlackjack();else render()}
function nextBlackjack(){let b=rt.bj;const next=b.hands.findIndex((h,i)=>i>b.active&&!h.finished);if(next>=0){b.active=next;b.message='Играем следующую руку';render()}else finishBlackjack()}
function finishBlackjack(){const b=rt.bj;if(!b||b.stage!=='playing')return;const anyAlive=b.hands.some(h=>handVal(h.cards)<=21);if(anyAlive){while(handVal(b.dealer)<17)b.dealer.push(draw(b.deck))}const dealerScore=handVal(b.dealer),dealerNatural=b.dealer.length===2&&dealerScore===21;let payout=0,stake=0;b.hands.forEach(h=>{const v=handVal(h.cards),natural=!h.fromSplit&&h.cards.length===2&&v===21;let p=0,label='Проигрыш';if(v>21){label='Перебор'}else if(dealerNatural&&!natural){label='Дилер: блэкджек'}else if(natural&&!dealerNatural){p=Math.round(h.stake*2.5);label='БЛЭКДЖЕК ×2,5'}else if(dealerScore>21||v>dealerScore){p=h.stake*2;label='ПОБЕДА ×2'}else if(v===dealerScore){p=h.stake;label='НИЧЬЯ'}h.outcome=label;h.payout=p;payout+=p;stake+=h.stake});b.stage='done';b.message=payout>stake?`Выигрыш! +${money(payout-stake)}`:payout===stake?'Ничья · ставка возвращена':'Раунд окончен';settle('Блэкджек',stake,payout);if(state.game==='blackjack')render()}
function bjAction(action){const b=rt.bj;if(!b||b.stage!=='playing')return;const h=b.hands[b.active];if(action==='bj-hit'){h.cards.push(draw(b.deck));if(handVal(h.cards)>21){h.finished=true;nextBlackjack()}else if(handVal(h.cards)===21){h.finished=true;nextBlackjack()}else render()}else if(action==='bj-stand'){h.finished=true;nextBlackjack()}else if(action==='bj-double'){if(h.cards.length!==2||!spend(h.stake))return;h.stake*=2;h.cards.push(draw(b.deck));h.finished=true;nextBlackjack()}else if(action==='bj-split'){if(b.hands.length!==1||h.cards.length!==2||h.cards[0].rank!==h.cards[1].rank||!spend(h.stake))return;const c1=h.cards[0],c2=h.cards[1];b.hands=[{cards:[c1,draw(b.deck)],stake:h.stake,finished:false,fromSplit:true},{cards:[c2,draw(b.deck)],stake:h.stake,finished:false,fromSplit:true}];b.active=0;if(c1.rank==='A'){b.hands.forEach(x=>x.finished=true);finishBlackjack()}else render()}}
function luckyHTML(){return `<div class="panel"><div class="panel-header"><h2>Фортуна</h2><span class="status-pill ${rt.wheelSpinning?'':'green'}">${rt.wheelSpinning?'ВРАЩЕНИЕ':'ГОТОВО'}</span></div><div class="panel-body" style="text-align:center"><div class="lucky-wheel-wrap"><div class="lucky-wheel"><div class="wheel-needle"></div><div id="luckyWheelSvg" style="width:100%;height:100%;transform:rotate(${rt.wheelRotation}deg);transition:transform 3.8s cubic-bezier(.1,.7,.05,1)">${sectorSVG(WIN_SECTORS.map(x=>'×'+x),WIN_SECTORS.map((x,i)=>x===0?'#9a3954':x>=5?'#926e23':i%2===0?'#187767':'#6450a3'),340)}</div><div class="lucky-center">✦</div></div></div><div class="wheel-result">${rt.wheelResult==null?'КРУТИ И ВЫИГРЫВАЙ':'×'+rt.wheelResult}</div>${resultNote(rt.wheelNotice,rt.wheelResult>1?'win':'')}</div></div><div style="margin-top:17px">${betPanel(rt.wheelSpinning?'КОЛЕСО ВРАЩАЕТСЯ…':'✺ КРУТИТЬ КОЛЕСО','wheel-spin',rt.wheelSpinning)}</div>`}
function spinWheel(){if(rt.wheelSpinning||!spend(state.stake))return;const epoch=roundEpoch;const stake=state.stake,index=rnd(WIN_SECTORS.length),m=WIN_SECTORS[index];rt.wheelSpinning=true;rt.wheelNotice='';rt.wheelResult=null;render();rt.wheelRotation=wheelRotateTo('luckyWheelSvg',rt.wheelRotation,index,WIN_SECTORS.length,7);setTimeout(()=>{if(epoch!==roundEpoch)return;rt.wheelSpinning=false;rt.wheelResult=m;const payout=Math.round(stake*m);rt.wheelNotice=`Выпал сектор ×${m} · получено ${money(payout)}`;settle('Колесо',stake,payout,`×${m}`);if(state.game==='wheel')render()},spinDuration(4050))}
function crashHTML(){const c=rt.crash||{status:'idle',shown:1};const running=c.active;const val=running?c.shown:(c.last||1);const hist=(c.history||[]).slice(0,14);return `<div class="panel"><div class="panel-header"><h2>Множитель в реальном времени</h2><span class="status-pill ${running?'green':c.status==='crashed'?'red':''}">${running?'В ПОЛЁТЕ':c.status==='crashed'?'КРАШ':'ГОТОВО'}</span></div><div class="panel-body"><div class="crash-chart"><svg id="crashSvg" viewBox="0 0 500 300" preserveAspectRatio="none"><path class="crash-grid" d="M 0 60 H 500 M0 120 H500 M0 180 H500 M0 240 H500 M100 0 V300 M200 0 V300 M300 0 V300 M400 0 V300"/><path id="crashArea" d="" fill="#35d6bf24"/><path id="crashLine" d="" fill="none" stroke="#35d6bf" stroke-width="4" stroke-linecap="round"/></svg><div id="crashValue" class="crash-big ${c.status==='crashed'?'bust':''}">×${Number(val).toFixed(2)}</div><div id="crashHint" class="crash-hint">${running?'Забери фишки до остановки!':c.status==='crashed'?'Самолёт улетел — новый раунд ниже':'Нажми «Старт», чтобы начать'}</div></div><div class="history-strip"><span class="panel-label">ПРОШЛЫЕ РАУНДЫ</span><div class="history-numbers">${hist.map(x=>`<span class="status-pill ${x>=2?'green':x<1.2?'red':''}">×${x.toFixed(2)}</span>`).join('')||'<span class="muted tiny">История пуста</span>'}</div></div></div></div><div class="panel betting-panel"><div class="panel-header"><h3>Crash-ставка</h3><span class="subcap">ЗАБИРАЙ ВОВРЕМЯ</span></div><div class="panel-body">${amountHTML()}<button class="btn ${running?'gold':'primary'} block" data-action="${running?'crash-cash':'crash-start'}" style="margin-top:15px">${running?'✓ ЗАБРАТЬ ×'+c.shown.toFixed(2):'↗ НАЧАТЬ ПОЛЁТ'}</button><p class="tiny">Автоматического вывода нет. При завершении раунда ставка сгорает. Предельный множитель ×100.</p></div></div>`}
function startCrash(){if(rt.crash?.active)return;if(!spend(state.stake))return;let crashAt=unit()<.01?1:(.98/(1-unit()));crashAt=Math.min(100,Math.max(1.01,crashAt));let c=rt.crash||{history:[]};c.active=true;c.status='running';c.stake=state.stake;c.crashAt=crashAt;c.shown=1;c.started=performance.now();c.last=1;rt.crash=c;render();c.interval=setInterval(()=>{if(!c.active){clearInterval(c.interval);return}const elapsed=performance.now()-c.started;c.shown=Math.min(100,Math.exp(elapsed*.00045));if(c.shown>=c.crashAt){c.shown=c.crashAt;c.active=false;c.status='crashed';c.last=c.crashAt;c.history.unshift(c.crashAt);c.history=c.history.slice(0,20);clearInterval(c.interval);settle('Crash',c.stake,0,`Краш ×${c.crashAt.toFixed(2)}`);if(state.game==='crash')render();return}if(state.game==='crash')updateCrashVisual()},55)}
function cashCrash(){const c=rt.crash;if(!c?.active)return;c.shown=Math.min(100,Math.exp((performance.now()-c.started)*.00045));if(c.shown>=c.crashAt){c.active=false;c.status='crashed';c.last=c.crashAt;c.history.unshift(c.crashAt);clearInterval(c.interval);settle('Crash',c.stake,0,`Краш ×${c.crashAt.toFixed(2)}`)}else{c.active=false;c.status='cashed';c.last=c.shown;c.history.unshift(c.crashAt);clearInterval(c.interval);settle('Crash',c.stake,Math.round(c.stake*c.shown),`Вывод ×${c.shown.toFixed(2)}`)}if(state.game==='crash')render()}
function updateCrashVisual(){const c=rt.crash;if(!c)return;const v=document.getElementById('crashValue');if(v)v.textContent='×'+c.shown.toFixed(2);const cashBtn=document.querySelector('[data-action="crash-cash"]');if(cashBtn)cashBtn.textContent='✓ ЗАБРАТЬ ×'+c.shown.toFixed(2);const y0=275, maxY=Math.max(3,c.shown*1.15),points=[];const samples=80;for(let i=0;i<=samples;i++){const p=i/samples;const m=Math.exp(Math.log(Math.max(c.shown,1))*p),x=20+460*p,y=y0-(m-1)/(maxY-1)*245;points.push(`${i===0?'M':'L'} ${x.toFixed(1)} ${y.toFixed(1)}`)}const path=points.join(' '),line=document.getElementById('crashLine'),area=document.getElementById('crashArea');if(line)line.setAttribute('d',path);if(area)area.setAttribute('d',path+' L 480 275 L 20 275 Z')}
function slotsHTML(){const s=rt.slots||{cells:['🍒','🍋','💎','🍀','🔔','🍋','7️⃣','🍒','🍀'],notice:''};const won=new Set(s.wonIndices||[]);return `<div class="panel"><div class="panel-header"><h2>NEON SLOTS <span class="goldtext">777</span></h2><span class="status-pill ${s.spinning?'':'green'}">${s.spinning?'ВРАЩЕНИЕ':'5 ЛИНИЙ'}</span></div><div class="panel-body"><div class="slots-grid">${s.cells.map((icon,i)=>`<div class="slot-tile ${s.spinning&&!s.lockedColumns?.includes(i%3)?'spinning':''} ${won.has(i)?'win':''}" id="slot${i}">${icon}</div>`).join('')}</div><div class="slot-paytable" style="margin-top:16px">🍒 ×10 · 🍋 ×15 · 🔔 ×20 · 🍀 ×30 · 💎 ×45 · 7️⃣ ×85<br>Три одинаковых на линии · Выплата за линию = ставка ÷ 5 × множитель</div>${resultNote(s.notice,s.payout>s.stake?'win':s.payout===0?'lose':'')}</div></div><div style="margin-top:17px">${betPanel(s.spinning?'БАРАБАНЫ КРУТЯТСЯ…':'▦ КРУТИТЬ БАРАБАНЫ','slots-spin',!!s.spinning)}</div>`}
const SLOT_LINES=[[0,1,2],[3,4,5],[6,7,8],[0,4,8],[2,4,6]];
function spinSlots(){
 if(rt.slots?.spinning||!spend(state.stake))return;
 const epoch=roundEpoch,stake=state.stake;
 // Draw the result once; the visual reels are never a second RNG source for payouts.
 const finalCells=Array.from({length:9},()=>SYMS[rnd(6)]);
 const s={spinning:true,cells:Array.from({length:9},()=>SYMS[rnd(6)]),lockedColumns:[],stake,notice:''};
 rt.slots=s;render();let count=0;
 const tick=setInterval(()=>{
  if(epoch!==roundEpoch){clearInterval(tick);return}
  count++;
  for(let col=0;col<3;col++){
   const lockAt=12+col*3;
   if(count>lockAt)continue;
   if(count===lockAt)s.lockedColumns.push(col);
   for(let row=0;row<3;row++){
    const i=row*3+col;
    s.cells[i]=count===lockAt?finalCells[i]:SYMS[rnd(6)];
    const el=state.game==='slots'?document.getElementById('slot'+i):null;
    if(el){el.textContent=s.cells[i];if(count===lockAt){el.classList.remove('spinning');el.classList.add('reel-landed')}}
   }
  }
  if(count<18)return;
  clearInterval(tick);s.spinning=false;s.cells=finalCells;
  let payout=0,won=[];
  SLOT_LINES.forEach(line=>{const [a,b,c]=line;if(s.cells[a]===s.cells[b]&&s.cells[b]===s.cells[c]){payout+=stake/5*SLOT_MULT[s.cells[a]];won.push(...line)}});
  s.payout=Math.round(payout);s.wonIndices=won;
  s.notice=won.length?`Совпадение! Выплата: ${money(s.payout)}`:'Совпадений нет · попробуй снова';
  settle('Слоты',stake,s.payout,`${won.length/3} линий`,{type:'slots',cells:s.cells.slice(),lines:SLOT_LINES.map((line,i)=>line.every(j=>s.cells[j]===s.cells[line[0]])?i:null).filter(i=>i!==null)});
  if(state.game==='slots')render();
 },100);
}
// Exact conditional survival probability of k safe cells among N squares with M bombs.
// Correct for all board sizes; explicitly cap rewards to protect integer wallet accounting.
const MINE_BOARDS=[16,25,32,36,49,64,100];
const mineDims=n=>n===32?[4,8]:[Math.sqrt(n),Math.sqrt(n)];
function mineMultiplier(s){const n=s.size||25,m=s.mineCount,k=s.opened.length;if(!Number.isInteger(n)||!MINE_BOARDS.includes(n)||!Number.isInteger(m)||m<1||m>=n||!Number.isInteger(k)||k<0||k>n-m)return 0;if(k===0)return 1;let product=.97;for(let i=0;i<k;i++)product*=(n-i)/(n-m-i);return product}
function minePayout(s){const m=mineMultiplier(s);return Math.min(BALANCE_CAP,Math.round(s.stake*m))}
function minesHTML(){const m=rt.mines;const active=!!m?.active;const size=m?.size||state.minesSize||25;const [rows,columns]=mineDims(size),opened=new Set(m?.opened||[]),mineSet=new Set(m?.mines||[]),revealed=!!m&&!active;const mult=m?.opened.length?mineMultiplier(m):1;const tiles=Array.from({length:size},(_,i)=>{const isOpen=opened.has(i),isMine=mineSet.has(i);return `<button class="mine-tile ${isOpen?'revealed':''} ${revealed&&isMine?'bomb':''} ${revealed&&!isMine&&isOpen?'safe':''}" data-action="mine-cell" data-index="${i}" ${!active||isOpen?'disabled':''} aria-label="Клетка ${i+1}">${isOpen?'◆':revealed&&isMine?'✹':'?'}</button>`}).join('');const boards=MINE_BOARDS.map(n=>`<button class="btn ${size===n?'active':''}" data-action="mine-size" data-value="${n}" ${active?'disabled':''}>${mineDims(n).join("×")} <b>${n} клеток</b></button>`).join('');const maxMines=Math.min(35,size-1);return `<div class="panel"><div class="panel-header"><h2>Минное поле ${rows} × ${columns}</h2><span class="status-pill ${active?'green':''}">${active?'РАУНД АКТИВЕН':'НОВЫЙ РАУНД'}</span></div><div class="panel-body"><div class="progress-row"><span>Безопасно открыто: <b>${m?.opened.length||0}</b></span><span>Множитель: <b class="accent">×${mult>=1e9?mult.toExponential(2):mult.toFixed(2)}</b></span></div><div class="mines-grid dynamic-mines" style="grid-template-columns:repeat(${columns},minmax(0,1fr))">${tiles}</div>${resultNote(m?.notice||'',m?.status==='cashed'?'win':m?.status==='lost'?'lose':'')}${active?`<button class="btn gold block" data-action="mines-cash" ${(m?.opened.length||0)===0?'disabled':''}>ЗАБРАТЬ ${money(minePayout(m))}</button>`:''}</div></div><div class="panel betting-panel"><div class="panel-header"><h3>Размер поля, мины и ставки</h3><span class="subcap">ВЕРОЯТНОСТЬ РАСТЁТ С РИСКОМ</span></div><div class="panel-body">${amountHTML()}<span class="panel-label">РАЗМЕР ПОЛЯ</span><div class="mines-size-options">${boards}</div><div style="display:flex;justify-content:space-between;margin-top:15px"><span class="panel-label">КОЛИЧЕСТВО МИН</span><b class="goldtext" id="minesCountValue">${m?.mineCount||state.minesCount}</b></div><input id="minesRange" type="range" min="1" max="${maxMines}" step="1" value="${m?.mineCount||state.minesCount}" ${active?'disabled':''}><p class="tiny">Шанс безопасно открыть первую клетку: ${((size-state.minesCount)/size*100).toFixed(2)}%. Максимальная выплата ограничена лимитом виртуального кошелька.</p><button class="btn primary block" style="margin-top:16px" data-action="mines-start" ${active?'disabled':''}>◆ ${active?'РАУНД ИДЁТ':'НАЧАТЬ ИГРУ'}</button></div></div>`}
function startMines(){if(rt.mines?.active)return;const size=state.minesSize||25,count=state.minesCount;if(!MINE_BOARDS.includes(size)||!Number.isInteger(count)||count<1||count>Math.min(35,size-1)||!spend(state.stake))return;const mines=new Set();while(mines.size<count)mines.add(rnd(size));rt.mines={mines:[...mines],size,mineCount:count,opened:[],stake:state.stake,active:true,status:'playing',notice:'Выбирай клетки. Чем больше мин, тем выше множитель!'};render()}
function openMine(index){const m=rt.mines;if(!m?.active||!Number.isInteger(index)||m.opened.includes(index)||index<0||index>=m.size)return;if(m.mines.includes(index)){m.active=false;m.status='lost';m.notice='Бум! Ты попал на мину';settle('Mines',m.stake,0,`${m.opened.length} клеток`)}else{m.opened.push(index);m.notice=`Открыто клеток: ${m.opened.length} · текущая выплата ${money(minePayout(m))}`;if(m.opened.length===m.size-m.mineCount){cashMines(true);return}}if(state.game==='mines')render()}
function cashMines(auto=false){const m=rt.mines;if(!m?.active||!m.opened.length)return;m.active=false;m.status='cashed';const payout=minePayout(m);m.notice=auto?'Все безопасные клетки открыты!':`Успешный вывод: ${money(payout)}`;settle('Mines',m.stake,payout,`${m.opened.length} клеток`);if(state.game==='mines')render()}
function plinkoHTML(){const p=rt.plinko||{};return `<div class="panel"><div class="panel-header"><h2>Доска Plinko</h2><span class="status-pill ${p.active?'green':''}">${p.active?'ШАР В ИГРЕ':'8 РЯДОВ'}</span></div><div class="panel-body"><canvas id="plinkoCanvas" class="plinko-stage" width="540" height="350" aria-label="Поле с штырьками и шарами"></canvas><div class="wheel-result" style="margin-top:13px">${p.result==null?'Шарик выбирает случайный путь':'×'+p.result}</div>${resultNote(p.notice||'',p.result>1?'win':'')}</div></div><div style="margin-top:17px">${betPanel(p.active?'ШАРИК ПАДАЕТ…':'∴ БРОСИТЬ ШАР','plinko-drop',!!p.active)}</div>`}
function drawPlinko(){const canvas=document.getElementById('plinkoCanvas');if(!canvas)return;const ctx=canvas.getContext('2d');if(!ctx)return;const w=540;ctx.clearRect(0,0,540,350);for(let r=0;r<8;r++){for(let i=0;i<=r;i++){const x=270+(i-r/2)*48,y=40+r*31;ctx.beginPath();ctx.arc(x,y,5.5,0,Math.PI*2);ctx.fillStyle='#7299af';ctx.shadowColor='#5bcddd';ctx.shadowBlur=9;ctx.fill();ctx.shadowBlur=0}}for(let i=0;i<9;i++){const x=270+(i-4)*48;ctx.fillStyle=PLINKO_PAY[i]>=3?'#bf6b3d':PLINKO_PAY[i]>=1?'#3d9291':'#5c657e';ctx.fillRect(x-22,288,44,48);ctx.fillStyle='white';ctx.font='bold 15px sans-serif';ctx.textAlign='center';ctx.fillText('×'+PLINKO_PAY[i],x,317)}if(rt.plinko?.active&&rt.plinko.path){const p=rt.plinko,t=Math.min(1,p.progress||0),seg=Math.min(7,Math.floor(t*8)),alpha=(t*8-seg);let x0=270,y0=8;let right=0;for(let k=0;k<seg;k++)right+=p.path[k];x0=270+(right-seg/2)*48;y0=8+seg*34;const nextX=270+(right+p.path[seg]-(seg+1)/2)*48,x=x0+(nextX-x0)*alpha,y=y0+alpha*34;ctx.beginPath();ctx.arc(x,y,11,0,Math.PI*2);ctx.fillStyle='#f3d47d';ctx.shadowColor='#f3d47d';ctx.shadowBlur=20;ctx.fill();ctx.shadowBlur=0}}
function dropPlinko(){if(rt.plinko?.active||!spend(state.stake))return;const epoch=roundEpoch;let p=rt.plinko||{};p.active=true;p.result=null;p.notice='';p.stake=state.stake;p.path=Array.from({length:8},()=>rnd(2));p.progress=0;rt.plinko=p;render();let start=performance.now();p.timer=setInterval(()=>{if(epoch!==roundEpoch){clearInterval(p.timer);return}p.progress=Math.min(1,(performance.now()-start)/2100);if(state.game==='plinko')drawPlinko();if(p.progress>=1){clearInterval(p.timer);p.active=false;const bucket=p.path.reduce((a,b)=>a+b,0);p.result=PLINKO_PAY[bucket];const payout=Math.round(p.stake*p.result);p.notice=`Карман ${bucket+1} · выплата ${money(payout)}`;settle('Plinko',p.stake,payout,`×${p.result}`);if(state.game==='plinko')render()}},33)}
function diceHTML(){const threshold=state.diceChance;const m=(97/threshold).toFixed(2);return `<div class="panel"><div class="panel-header"><h2>Dice 0–99</h2><span class="status-pill green">ТОЧНОЕ ЧИСЛО</span></div><div class="panel-body" style="text-align:center"><span class="panel-label">ПОСЛЕДНИЙ БРОСОК</span><div class="dice-number">${rt.diceRoll==null?'?':rt.diceRoll}</div><div class="dice-options"><button class="btn ${state.diceSide==='under'?'active':''}" data-action="dice-side" data-value="under">НИЖЕ ${threshold}</button><button class="btn ${state.diceSide==='over'?'active':''}" data-action="dice-side" data-value="over">ОТ ${100-threshold} И ВЫШЕ</button></div><input id="diceRange" type="range" min="5" max="95" step="1" value="${threshold}"><div class="dice-details"><div>Шанс выигрыша<b id="diceChanceValue">${threshold}%</b></div><div>Множитель<b class="accent" id="diceMultiplierValue">×${m}</b></div></div>${resultNote(rt.diceNotice,rt.diceNotice.startsWith('Выиграл')?'win':'')}</div></div><div style="margin-top:17px">${betPanel('⚄ БРОСИТЬ КОСТЬ','dice-roll')}</div>`}
function rollDice(){if(!spend(state.stake))return;const num=rnd(100),chance=state.diceChance,won=state.diceSide==='under'?num<chance:num>=100-chance,payout=won?Math.round(state.stake*(.97*100/chance)):0;rt.diceRoll=num;rt.diceNotice=won?`Выиграл! Выплата ${money(payout)}`:`Выпало ${num} · ставка проиграла`;settle('Dice',state.stake,payout,`Бросок ${num}`);render()}
function bacValue(cards){return cards.reduce((a,c)=>a+(cardVal(c)%10),0)%10}
function baccaratDraw(){const deck=newDeck(8),player=[draw(deck),draw(deck)],banker=[draw(deck),draw(deck)];let p=bacValue(player),b=bacValue(banker);if(p<8&&b<8){let p3=null;if(p<=5){p3=draw(deck);player.push(p3)}if(p3===null){if(b<=5)banker.push(draw(deck))}else{const v=cardVal(p3)%10;let take=b<=2||(b===3&&v!==8)||(b===4&&v>=2&&v<=7)||(b===5&&v>=4&&v<=7)||(b===6&&(v===6||v===7));if(take)banker.push(draw(deck))}}p=bacValue(player);b=bacValue(banker);return {player,banker,p,b,winner:p>b?'player':p<b?'banker':'tie'}}
function baccaratHTML(){const b=rt.baccarat||{};let opts=[['player','ИГРОК ×2'],['banker','БАНКИР ×1,95'],['tie','НИЧЬЯ ×9']];let dealerHand=b.banker||[{rank:'A',suit:'♠'},{rank:'K',suit:'♣'}],playerHand=b.player||[{rank:'Q',suit:'♥'},{rank:'7',suit:'♦'}];return `<div class="card-felt"><div class="table-sign">PUNTO BANCO • BACCARAT</div><div class="baccarat-set"><div class="baccarat-position"><h3>ИГРОК ${b.player? '· '+b.p+' очков':''}</h3><div class="hand">${playerHand.map(c=>cardHTML(c,!b.player)).join('')}</div></div><div class="baccarat-position"><h3>БАНКИР ${b.banker?'· '+b.b+' очков':''}</h3><div class="hand">${dealerHand.map(c=>cardHTML(c,!b.banker)).join('')}</div></div></div><div class="center-message">${esc(b.notice||'Выбери исход и сдавай карты')}</div><div class="baccarat-options">${opts.map(([val,label])=>`<button class="btn small ${state.baccaratBet===val?'active':''}" data-action="baccarat-pick" data-value="${val}">${label}</button>`).join('')}</div><div class="table-buttons"><button class="btn primary" data-action="baccarat-play">♣ СДАТЬ КАРТЫ</button></div></div><div class="panel betting-panel"><div class="panel-header"><h3>Ставка на исход</h3></div><div class="panel-body">${amountHTML()}<p class="tiny">Банкир: комиссия 5% с выигрыша. Ставка на игрока или банкира при ничьей возвращается.</p></div></div>`}
function playBaccarat(){if(!spend(state.stake))return;const stake=state.stake,result=baccaratDraw(),pick=state.baccaratBet,won=pick===result.winner;let payout=won?Math.round(stake*(pick==='tie'?9:pick==='banker'?1.95:2)):result.winner==='tie'&&pick!=='tie'?stake:0;result.notice=won?`УГАДАЛ! +${money(payout-stake)}`:payout===stake?'Ничья · ставка возвращена':`Победил ${result.winner==='player'?'игрок':result.winner==='banker'?'банкир':'ничейный исход'}`;rt.baccarat=result;settle('Баккара',stake,payout,result.winner);render()}
function coinHTML(){const c=rt.coin||{side:null};return `<div class="panel"><div class="panel-header"><h2>Один бросок · один исход</h2><span class="status-pill green">50 / 50</span></div><div class="panel-body"><div class="coin-stage"><div id="coinDisk" class="coin ${c.flipping?'flipping':''}">${c.side==null?'✦':c.side==='heads'?'★':'❖'}</div></div><div class="center-message" style="text-align:center">${c.flipping?'Подбрасываем…':c.side==null?'Орел или решка?':c.side==='heads'?'ОРЁЛ':'РЕШКА'}</div><div class="coin-options"><button class="btn ${state.coinBet==='heads'?'active':''}" data-action="coin-pick" data-value="heads">★ ОРЁЛ</button><button class="btn ${state.coinBet==='tails'?'active':''}" data-action="coin-pick" data-value="tails">❖ РЕШКА</button></div>${resultNote(c.notice||'',c.payout>c.stake?'win':'')}</div></div><div style="margin-top:17px">${betPanel(c.flipping?'ПОДБРАСЫВАЕМ…':'◐ ПОДБРОСИТЬ','coin-flip',!!c.flipping)}</div>`}
function flipCoin(){if(rt.coin?.flipping||!spend(state.stake))return;const epoch=roundEpoch,pick=state.coinBet;const stake=state.stake,side=rnd(2)?'heads':'tails',c={flipping:true,side:null,notice:'',stake};rt.coin=c;render();setTimeout(()=>{if(epoch!==roundEpoch)return;c.flipping=false;c.side=side;c.payout=side===pick?Math.round(stake*1.95):0;c.notice=c.payout?'Угадал! Выигрыш '+money(c.payout):'Не угадал · ещё попытка?';settle('Монетка',stake,c.payout,side==='heads'?'Орёл':'Решка');if(state.game==='coin')render()},spinDuration(1200))}

// Keno: choose 5 distinct numbers; draw 10 from 40 without replacement.
const KENO_PAY=[0,0,2,2.5,12,200];
function kenoHTML(){const selected=new Set(state.kenoPicks);const drawn=rt.keno?.drawn||[];const results=new Set(drawn);const cells=Array.from({length:40},(_,i)=>{const n=i+1;return `<button class="keno-num ${selected.has(n)?'selected':''} ${results.has(n)?'drawn':''} ${selected.has(n)&&results.has(n)?'matched':''}" data-action="keno-pick" data-value="${n}" aria-pressed="${selected.has(n)}">${n}</button>`}).join('');return `<div class="panel"><div class="panel-header"><h2>Кено · 5 из 40</h2><span class="status-pill green">10 ШАРОВ</span></div><div class="panel-body"><p class="tiny">Отметь 5 чисел. Выигрыш зависит от совпадений.</p><div class="keno-board">${cells}</div><div class="keno-count">Выбрано: <b>${selected.size} / 5</b> ${rt.keno?`· Совпало: <b>${rt.keno.hits}</b>`:''}</div><div class="keno-paytable">${KENO_PAY.map((v,i)=>`<span>${i} совп. <b>×${v}</b></span>`).join('')}</div>${resultNote(rt.keno?.notice||'',rt.keno?.payout>rt.keno?.stake?'win':'')}</div></div><div style="margin-top:17px">${betPanel('✳ РАЗЫГРАТЬ 10 ЧИСЕЛ','keno-play',selected.size!==5)}</div>`}
function kenoPick(n){if(!Number.isInteger(n)||n<1||n>40)return;let items=state.kenoPicks;const i=items.indexOf(n);if(i>=0)items.splice(i,1);else if(items.length<5)items.push(n);else return;rt.keno=null;render()}
function playKeno(){if(state.kenoPicks.length!==5||new Set(state.kenoPicks).size!==5||!spend(state.stake))return;const available=Array.from({length:40},(_,i)=>i+1),drawn=[];for(let i=0;i<10;i++){const j=i+rnd(40-i);[available[i],available[j]]=[available[j],available[i]];drawn.push(available[i])}const hits=drawn.filter(n=>state.kenoPicks.includes(n)).length,stake=state.stake,payout=Math.round(stake*KENO_PAY[hits]);rt.keno={drawn,hits,stake,payout,notice:`Выпало: ${drawn.join(', ')}. Совпадений: ${hits}. Выплата: ${money(payout)}`};settle('Кено',stake,payout,`${hits}/5`);render()}
// Video poker: a single standard 52-card deck, one redraw, no jokers.
const POKER_PAY={royal:250,straightFlush:50,quads:25,fullHouse:9,flush:6,straight:4,trips:3,twoPair:2,jacks:1,none:0};
function evaluatePoker(cards){if(!Array.isArray(cards)||cards.length!==5)return {kind:'none',name:'Нет комбинации',mult:0};const ranks=cards.map(c=>RANKS.indexOf(c.rank)+1);if(ranks.some(x=>x<1))return {kind:'none',name:'Нет комбинации',mult:0};const values=ranks.map(x=>x===1?14:x).sort((a,b)=>a-b),unique=[...new Set(values)],flush=cards.every(c=>c.suit===cards[0].suit);const straight=(unique.length===5&&(values[4]-values[0]===4||unique.join(',')==='2,3,4,5,14'));const freq={};values.forEach(v=>freq[v]=(freq[v]||0)+1);const counts=Object.values(freq).sort((a,b)=>b-a);let kind='none',name='Нет комбинации';if(straight&&flush&&values.join(',')==='10,11,12,13,14'){kind='royal';name='РОЯЛ-ФЛЕШ'}else if(straight&&flush){kind='straightFlush';name='Стрит-флеш'}else if(counts[0]===4){kind='quads';name='Каре'}else if(counts[0]===3&&counts[1]===2){kind='fullHouse';name='Фулл-хаус'}else if(flush){kind='flush';name='Флеш'}else if(straight){kind='straight';name='Стрит'}else if(counts[0]===3){kind='trips';name='Тройка'}else if(counts[0]===2&&counts[1]===2){kind='twoPair';name='Две пары'}else if(counts[0]===2&&Object.entries(freq).some(([rank,n])=>n===2&&Number(rank)>=11)){kind='jacks';name='Пара валетов или старше'}return {kind,name,mult:POKER_PAY[kind]}}
function pokerHTML(){const p=rt.poker||{phase:'idle',cards:[]};const playing=p.phase==='hold';const cards=p.cards.length?p.cards:Array.from({length:5},(_,i)=>({rank:'?',suit:'♠'}));return `<div class="panel"><div class="panel-header"><h2>Jacks or Better</h2><span class="status-pill ${playing?'green':''}">${playing?'ВЫБЕРИ КАРТЫ':'ВИДЕОПОКЕР'}</span></div><div class="panel-body"><div class="poker-table"><div class="poker-cards">${cards.map((c,i)=>`<button class="poker-card ${playing&&p.held.includes(i)?'held':''}" data-action="poker-hold" data-index="${i}" ${!playing?'disabled':''} aria-pressed="${playing&&p.held.includes(i)}">${cardHTML(c,!p.cards.length)}<span class="hold-tag">${playing?(p.held.includes(i)?'ОСТАВИТЬ':'МЕНЯТЬ'):'♠'}</span></button>`).join('')}</div><div class="center-message">${esc(p.notice||'Раздай 5 карт и собери выигрышную комбинацию')}</div></div><div class="poker-pays">${[['Пара J+',1],['Две пары',2],['Тройка',3],['Стрит',4],['Флеш',6],['Фулл-хаус',9],['Каре',25],['Стрит-флеш',50],['Роял-флеш',250]].map(([name,x])=>`<span>${name} <b>×${x}</b></span>`).join('')}</div></div></div><div style="margin-top:17px">${betPanel(playing?'⇄ ЗАМЕНИТЬ КАРТЫ':'♥ РАЗДАТЬ 5 КАРТ',playing?'poker-draw':'poker-deal')}</div>`}
function pokerDeal(){if(rt.poker?.phase==='hold'||!spend(state.stake))return;const deck=newDeck(1),cards=Array.from({length:5},()=>draw(deck));rt.poker={phase:'hold',deck,cards,held:[],stake:state.stake,notice:'Нажми на карты, которые хочешь оставить, затем замени остальные'};render()}
function pokerHold(i){const p=rt.poker;if(p?.phase!=='hold'||!Number.isInteger(i)||i<0||i>4)return;const j=p.held.indexOf(i);if(j>=0)p.held.splice(j,1);else p.held.push(i);render()}
function pokerDraw(){const p=rt.poker;if(p?.phase!=='hold')return;for(let i=0;i<5;i++)if(!p.held.includes(i))p.cards[i]=draw(p.deck);const result=evaluatePoker(p.cards);p.phase='done';p.result=result;p.payout=p.stake*result.mult;p.notice=`${result.name} · выплата ${money(p.payout)}`;settle('Видеопокер',p.stake,p.payout,result.name);render()}
// SIC BO — three honest independent dice, no reroll tricks.
const SICBO_SUM_PAY={4:51,5:19,6:15,7:13,8:9,9:7,10:7,11:7,12:7,13:9,14:13,15:15,16:19,17:51};
const SICBO_OPTIONS=[
 [['small','МАЛОЕ 4–10','×2'],['big','БОЛЬШОЕ 11–17','×2'],['triple','ЛЮБАЯ ТРОЙКА','×25']],
 Array.from({length:14},(_,i)=>['sum-'+(i+4),'СУММА '+(i+4),'×'+SICBO_SUM_PAY[i+4]]),
 Array.from({length:6},(_,i)=>['exact-'+(i+1),'ТОЧНАЯ ТРОЙКА '+(i+1),'×181']),
 Array.from({length:6},(_,i)=>['pair-'+(i+1),'ПАРА '+(i+1),'×12']),
 Array.from({length:6},(_,i)=>['single-'+(i+1),'ЧИСЛО '+(i+1),'×2–×4'])
];
const SICBO_IDS=new Set(SICBO_OPTIONS.flat().map(x=>x[0]));
function sicboHTML(){const r=rt.sicbo;const categories=['КРУПНЫЕ СТАВКИ','ТОЧНАЯ СУММА','ТОЧНЫЕ ТРОЙКИ','ДВА ОДИНАКОВЫХ','ОДНО ЧИСЛО'];const sections=SICBO_OPTIONS.map((arr,i)=>`<div class="panel-label" style="margin-top:19px">${categories[i]}</div><div class="option-grid">${arr.map(([id,title,m])=>`<button class="btn ${state.sicboBet===id?'active':''}" data-action="sicbo-pick" data-value="${id}">${title}<br><b>${m}</b></button>`).join('')}</div>`).join('');return `<div class="panel"><div class="panel-header"><h2>⚂ SIC BO</h2><span class="status-pill green">35 ВАРИАНТОВ СТАВОК</span></div><div class="panel-body"><div class="dice-three">${(r?.dice||[1,3,6]).map(v=>`<span class="die-face" aria-label="На кубике ${v}">${['','⚀','⚁','⚂','⚃','⚄','⚅'][v]}</span>`).join('')}</div><div class="wheel-result">${r?'Сумма: '+r.sum:'СДЕЛАЙ СТАВКУ'}</div>${sections}${resultNote(r?.notice||'',r?.payout>r?.stake?'win':r?'lose':'')}</div></div><div style="margin-top:17px">${betPanel('⚂ БРОСИТЬ ТРИ КУБИКА','sicbo-roll')}</div>`}
function sicboOutcome(dice,pick){if(!Array.isArray(dice)||dice.length!==3||dice.some(v=>!Number.isInteger(v)||v<1||v>6))throw Error('Некорректные кубики');const sum=dice.reduce((a,b)=>a+b,0),triple=dice.every(x=>x===dice[0]);return pick==='triple'?triple:!triple&&(pick==='small'?sum>=4&&sum<=10:pick==='big'&&sum>=11&&sum<=17)}
function sicboMultiplier(dice,pick){if(!Array.isArray(dice)||dice.length!==3||dice.some(v=>!Number.isInteger(v)||v<1||v>6)||!SICBO_IDS.has(pick))throw Error('Некорректная ставка');if(['small','big','triple'].includes(pick))return sicboOutcome(dice,pick)?(pick==='triple'?25:2):0;const [category,nText]=pick.split('-'),n=Number(nText),sum=dice.reduce((a,b)=>a+b,0),same=dice.filter(v=>v===n).length;if(category==='sum')return sum===n?SICBO_SUM_PAY[n]:0;if(category==='exact')return same===3?181:0;if(category==='pair')return same>=2?12:0;if(category==='single')return [0,2,3,4][same]||0;return 0}
function playSicbo(){const stake=state.stake,pick=state.sicboBet;if(!SICBO_IDS.has(pick)||!spend(stake))return;const dice=Array.from({length:3},()=>rnd(6)+1),sum=dice.reduce((a,b)=>a+b,0),m=sicboMultiplier(dice,pick),payout=extraPayout(stake,m);rt.sicbo={dice,sum,stake,payout,notice:m?`Победа! Выплата ${money(payout)}`:'Ставка не сыграла'};settle('Sic Bo',stake,payout,dice.join('-'));render()}
// LIMBO — P(reach target M) = 0.97 / M for every selected target.
function limboHTML(){const x=state.limboTarget,r=rt.limbo;return `<div class="panel"><div class="panel-header"><h2>⇡ LIMBO</h2><span class="status-pill green">97% RTP</span></div><div class="panel-body" style="text-align:center"><div class="center-message">Цель — попасть не ниже выбранного коэффициента</div><div class="limbo-number">${r?'×'+r.actual.toFixed(2):'×—'}</div><div class="dice-details"><div>ТВОЯ ЦЕЛЬ<b>×${x}</b></div><div>ВЕРОЯТНОСТЬ<b class="accent">${(97/x).toFixed(2)}%</b></div></div><div class="option-grid">${[1.5,2,3,5,10,20,50,100].map(m=>`<button class="btn ${x===m?'active':''}" data-action="limbo-target" data-value="${m}">×${m}</button>`).join('')}</div>${resultNote(r?.notice||'',r?.won?'win':r?'lose':'')}</div></div><div style="margin-top:17px">${betPanel('⇡ ИСПЫТАТЬ УДАЧУ','limbo-play')}</div>`}
function limboOutcome(target,u){if(!(target>1)||!(u>=0&&u<1))throw Error('Некорректная цель');return .97/(1-u)>=target}
function playLimbo(){const stake=state.stake,target=state.limboTarget;if(!spend(stake))return;const u=unit(),actual=Math.min(100000,.97/(1-u)),won=limboOutcome(target,u),payout=won?Math.round(stake*target):0;rt.limbo={actual,stake,target,won,payout,notice:won?`Выплата: ${money(payout)}`:`Не удалось достичь ×${target}`};settle('Limbo',stake,payout,`Цель ×${target}`);render()}
// HI-LO — independent, uniform next rank; ties return the stake. A is low.
function hiloCard(){return {rank:RANKS[rnd(13)],suit:SUITS[rnd(4)]}}
function hiloOdds(rank,side){const n=RANKS.indexOf(rank)+1;if(n<1)return 0;const winning=side==='higher'?13-n:side==='lower'?n-1:0;return winning>0?(.97*12/winning):0}
function hiloHTML(){if(!rt.hilo)rt.hilo={current:hiloCard(),previous:null};const r=rt.hilo,rank=RANKS.indexOf(r.current.rank)+1;const options=[['higher','ВЫШЕ',rank<13],['lower','НИЖЕ',rank>1]];return `<div class="panel"><div class="panel-header"><h2>⇵ Выше / ниже</h2><span class="status-pill green">ТУЗ = 1</span></div><div class="panel-body"><div class="hilo-cards"><div><span class="panel-label">ТЕКУЩАЯ КАРТА</span>${cardHTML(r.current)}</div><div class="hilo-arrow">→</div><div><span class="panel-label">ПРОШЛЫЙ РЕЗУЛЬТАТ</span>${r.previous?cardHTML(r.previous):cardHTML({rank:'?',suit:'♠'},true)}</div></div><div class="option-grid">${options.map(([id,title,enabled])=>`<button class="btn ${state.hiloBet===id?'active':''}" data-action="hilo-side" data-value="${id}" ${!enabled?'disabled':''}>${title} <b>×${hiloOdds(r.current.rank,id).toFixed(2)}</b></button>`).join('')}</div><p class="tiny">Равный ранг: возврат ставки. Следующая карта становится текущей.</p>${resultNote(r.notice||'',r.payout>r.stake?'win':r.notice&&r.payout===0?'lose':'')}</div></div><div style="margin-top:17px">${betPanel('⇵ ОТКРЫТЬ КАРТУ','hilo-play',hiloOdds(r.current.rank,state.hiloBet)===0)}</div>`}
function playHilo(){if(!rt.hilo)rt.hilo={current:hiloCard()};const r=rt.hilo,mult=hiloOdds(r.current.rank,state.hiloBet);if(!mult)return;const stake=state.stake;if(!spend(stake))return;const next=hiloCard(),a=RANKS.indexOf(r.current.rank),b=RANKS.indexOf(next.rank),tie=a===b,won=!tie&&(state.hiloBet==='higher'?b>a:b<a),payout=tie?stake:won?Math.round(stake*mult):0;r.previous=r.current;r.current=next;r.stake=stake;r.payout=payout;r.notice=tie?'Одинаковый ранг — ставка возвращена':won?`Угадал! Выплата ${money(payout)}`:'Не угадал';if(hiloOdds(r.current.rank,state.hiloBet)===0)state.hiloBet=state.hiloBet==='higher'?'lower':'higher';settle('Выше / ниже',stake,payout,r.notice);render()}
// CRAPS — standard Pass Line: single wager held through multiple throws.
function crapsStep(point,sum){if(!Number.isInteger(sum)||sum<2||sum>12)throw Error('Некорректная сумма');if(point===null){if(sum===7||sum===11)return {status:'won',point:null};if([2,3,12].includes(sum))return {status:'lost',point:null};return {status:'point',point:sum}}if(sum===point)return {status:'won',point};if(sum===7)return {status:'lost',point};return {status:'point',point}}
function crapsDontStep(point,sum){if(point===null){if(sum===2||sum===3)return {status:'won',point:null};if(sum===12)return {status:'push',point:null};if(sum===7||sum===11)return {status:'lost',point:null};return {status:'point',point:sum}}if(sum===7)return {status:'won',point};if(sum===point)return {status:'lost',point};return {status:'point',point}}
function crapsHTML(){const c=rt.craps||{},active=!!c.active;const dont=(c.bet||state.crapsBet)==='dont';return `<div class="panel"><div class="panel-header"><h2>⚅ CRAPS · ${dont?"DON’T PASS":"PASS LINE"}</h2><span class="status-pill ${active?'green':''}">${active?'ПОЙНТ АКТИВЕН':'ПЕРВЫЙ БРОСОК'}</span></div><div class="panel-body" style="text-align:center"><div class="dice-three">${(c.dice||[3,4]).map(v=>`<span class="die-face">${['','⚀','⚁','⚂','⚃','⚄','⚅'][v]}</span>`).join('')}</div><div class="wheel-result">${c.point?'ПОЙНТ '+c.point:c.sum?'ВЫПАЛО '+c.sum:(dont?'СТАВКА DON’T PASS':'СТАВКА PASS LINE')}</div><div class="center-message">${esc(c.notice||(dont?'Don’t Pass: 2/3 — победа, 7/11 — проигрыш, 12 — возврат. После пойнта победа на 7.':'Pass Line: 7/11 — победа, 2/3/12 — проигрыш. После пойнта победа на выбранное число.'))}</div><div class="craps-hint">${active?(dont?'Семёрка раньше '+c.point+' = победа ×2. Ставка удерживается до исхода.':'Сумма '+c.point+' раньше 7 = победа ×2. Ставка удерживается до исхода.'):'Новый раунд: ставка ×2 при победе'}</div></div></div><div style="margin-top:17px">${active?`<div class="panel"><div class="panel-body"><b>На кону: ${money(c.stake)}</b><button class="btn primary block" style="margin-top:16px" data-action="craps-roll">⚅ БРОСИТЬ ЕЩЁ РАЗ</button></div></div>`:betPanel('⚅ СДЕЛАТЬ СТАВКУ И БРОСИТЬ','craps-roll',false,extraOptions([['pass','PASS LINE','7/11 — выигрыш'],['dont','DON’T PASS','2/3 — выигрыш']],'craps-pick',state.crapsBet||'pass'))}</div>`}
function rollCraps(){let c=rt.craps;if(!c?.active){const stake=state.stake;if(!spend(stake))return;c={active:true,point:null,stake,bet:state.crapsBet||'pass',dice:[],notice:''};rt.craps=c}const dice=[rnd(6)+1,rnd(6)+1],sum=dice[0]+dice[1],out=(c.bet==='dont'?crapsDontStep(c.point,sum):crapsStep(c.point,sum));c.dice=dice;c.sum=sum;c.point=out.point;if(out.status==='point'){c.notice=`Пойнт ${c.point}: ${c.bet==='dont'?'победа при 7, проигрыш при пойнте':'победа при пойнте, проигрыш при 7'}`}else{c.active=false;c.notice=out.status==='won'?`Победа! Выплата ${money(c.stake*2)}`:out.status==='push'?'Ничья на 12 — ставка возвращена':'Раунд проигран';settle('Craps',c.stake,out.status==='won'?c.stake*2:out.status==='push'?c.stake:0,`Кости ${sum}`)}render()}
// v1.4: independent games with explicit demo paytables, no remote services.
state.minesSize=25;state.towerMines=1;state.lottoPicks=[];
const EXTRA_RULES={
 'roulette-us':'Американская рулетка: 38 исходов (0, 00, 1–36). Число 35:1, цвет/чётность/диапазон 1:1, дюжины 2:1. Нули проигрывают внешние ставки.',
 'roulette-fr':'Французская рулетка La Partage: 37 исходов (0–36). На внешних ставках 1:1 при выпадении нуля возвращается половина ставки. На число выплата 35:1.',
 'threecard':'Трёхкарточный покер (Ante/Play): получи три карты, выбери Fold или Play (дополнительная равная ставка). Дилер играет с дамой или выше. При победе — возврат и 1:1 на Ante и Play. При отсутствии квалификации дилера Ante выигрывает, Play возвращается. Бонус Ante за стрит/сет/стрит-флеш.',
 'war':'Casino War: карты из 6 колод, туз старший. Карта игрока выше — ×2. При ничьей выбери сдачу (вернутся полставки) либо войну (дополнительная ставка), победа при равной или большей новой карте.',
 'dragontiger':'Dragon Tiger: по одной карте Дракону и Тигру. Старшая выигрывает, туз младший. Дракон или Тигр — ×2, при равенстве ранга возвращается половина такой ставки; ничья — ×12.',
 'tower':'Tower — онлайн-мини-игра. Выбирай 1 или 2 ловушки среди трёх ячеек каждого из пяти этажей. Выплата после каждого успешного выбора растёт как ×0,97 × (3 / число безопасных) ^ число этажей.',
 'bingo':'Быстрое Bingo 75 (аркадная версия): карта 5×5 с центральной свободной клеткой, 40 случайных шаров из 75. За одну готовую линию выплата ×1,5, две — ×3, от трёх — ×7. Пользовательская таблица выплат.',
 'lotto':'Лотерея 6 из 49: выбери шесть разных чисел. За 3/4/5/6 совпадений демо-выплаты ×15 / ×150 / ×2500 / ×1000000. Таблица не соответствует государственной лотерее.',
 'scratch':'Скретч-карта: открой 9 ячеек. Если три или больше одинаковых символов, получи выплату по таблице. Все символы назначаются до открытия, исход не меняется от порядка нажатий.',
 'seven':'Lucky Seven: две независимые кости. Ставки на меньше семи (2–6), больше семи (8–12), точно семь, дубль или чётную сумму. Коэффициенты заранее показаны.',
 'dicepoker':'Покер на костях: пять костей и одна раздача, без обмена. Выплаты за две пары, тройку, полный дом, малый стрит, каре и покер (пять одинаковых). Авторская таблица.',
 'treasure':'Сундуки — онлайн-мини-игра: девять закрытых сундуков, призы ×0, ×1, ×2, ×3, ×5, ×10. Позиции перемешиваются до выбора; один сундук на раунд.'
};
const EXTRA_GAMES=[
 {id:'roulette-us',icon:'◎',name:'Рулетка США',title:'Американская рулетка · 00',sub:'38 исходов · 0 и 00 · 35:1'},
 {id:'roulette-fr',icon:'◍',name:'Французская рулетка',title:'Рулетка La Partage',sub:'Один зеро · половина внешней ставки при нуле'},
 {id:'threecard',icon:'♦',name:'3 Card Poker',title:'Трёхкарточный покер',sub:'Ante · Play · Дилер квалифицируется с Q+'},
 {id:'war',icon:'⚔',name:'Casino War',title:'Карточная война',sub:'Сдавайся или иди на войну'},
 {id:'dragontiger',icon:'🐉',name:'Dragon Tiger',title:'Дракон против тигра',sub:'Две карты · три типа ставок'},
 {id:'tower',icon:'▤',name:'Tower',title:'Башня удачи',sub:'5 этажей · 1 или 2 ловушки · нарастающий риск'},
 {id:'bingo',icon:'▩',name:'Bingo 75',title:'Быстрое Bingo',sub:'75 шаров · 5×5 · готовые линии'},
 {id:'lotto',icon:'✷',name:'Лотерея 6/49',title:'Лотерея 6 из 49',sub:'Выбирай 6 чисел · до ×1 000 000'},
 {id:'scratch',icon:'▧',name:'Скретч-карты',title:'Скретч-карта · 9 ячеек',sub:'Открывай карту и ищи 3 одинаковых'},
 {id:'seven',icon:'⚇',name:'Lucky Seven',title:'Семёрка на костях',sub:'Больше · меньше · равно · дубль · чёт'},
 {id:'dicepoker',icon:'⚄',name:'Покер на костях',title:'Пять кубиков · покер',sub:'Каре · фулл-хаус · стрит · пять равных'},
 {id:'treasure',icon:'♢',name:'Сундуки',title:'Сундуки сокровищ',sub:'9 сундуков · выбор одного множителя'}
];
GAMES.push(...EXTRA_GAMES);
const EXTRA_RT={us:null,fr:null,threecard:null,war:null,dragontiger:null,tower:null,bingo:null,lotto:null,scratch:null,seven:null,dicepoker:null,treasure:null};
Object.assign(rt,EXTRA_RT);
const extraResetRuntime=resetRuntime;
resetRuntime=function(){extraResetRuntime();Object.assign(rt,EXTRA_RT)};
const R_US=['0','00',...Array.from({length:36},(_,i)=>String(i+1))];
const R_FR=Array.from({length:37},(_,i)=>String(i));
function extraPayout(stake,m){return Math.min(BALANCE_CAP,Math.round(stake*m))}
function extraOptions(options,action,selected){return `<div class="option-grid">${options.map(([id,label,detail])=>`<button class="btn ${id===selected?'active':''}" data-action="${action}" data-value="${esc(id)}">${esc(label)}${detail?`<b>${esc(detail)}</b>`:''}</button>`).join('')}</div>`}
function extraPanel(title,contents,button,action,disabled=false){return `<div class="panel"><div class="panel-header"><h2>${title}</h2><span class="status-pill green">DEMO · OFFLINE</span></div><div class="panel-body">${contents}</div></div><div style="margin-top:17px">${betPanel(button,action,disabled)}</div>`}
const SIMPLE_ROULETTE_BETS=[['red','🔴 Красное','×2'],['black','⚫ Чёрное','×2'],['even','Чёт','×2'],['odd','Нечёт','×2'],['low','1–18','×2'],['high','19–36','×2'],['d1','1-я дюжина','×3'],['d2','2-я дюжина','×3'],['d3','3-я дюжина','×3']];
function rouletteVariantWin(kind,n,variant,stake){const isZero=n==='0'||n==='00';if(kind.startsWith('n:'))return kind.slice(2)===n?stake*36:0;
 if(isZero)return variant==='fr'&&['red','black','even','odd','low','high'].includes(kind)?Math.floor(stake/2):0;
 const v=Number(n);const yes={red:REDS.has(v),black:!REDS.has(v),even:v%2===0,odd:v%2===1,low:v<=18,high:v>=19,d1:v<=12,d2:v>=13&&v<=24,d3:v>=25}[kind];return yes?stake*(kind.startsWith('d')?3:2):0}
function variantRouletteHTML(variant){const isUS=variant==='us',r=rt[variant]||{},nums=isUS?R_US:R_FR;const color=n=>n==='0'||n==='00'?'green':REDS.has(Number(n))?'red':'black';const selected=r.bets||[];const picks=nums.map(n=>`<button class="number-pick ${color(n)}" data-action="vr-bet" data-kind="${'n:'+n}" ${r.spinning?'disabled':''}>${n}</button>`).join('');const out=SIMPLE_ROULETTE_BETS.map(([id,label,x])=>`<button class="btn" data-action="vr-bet" data-kind="${id}" ${r.spinning?'disabled':''}>${label} <b class="goldtext">${x}</b></button>`).join('');const history=(r.history||[]).slice(0,20).map(n=>`<span class="ball-mini ${color(n)}">${n}</span>`).join('');return `<div class="panel"><div class="panel-header"><h2>${isUS?'Американский стол 0/00':'Французский стол · La Partage'}</h2><span class="status-pill">${nums.length} исходов</span></div><div class="panel-body"><div class="roulette-extra-result"><div class="large-number ${color(r.last||'0')}">${r.last??'?'}</div><div>${r.spinning?'Колесо крутится…':r.notice||'Добавь ставки на стол'}<div class="history-mini">${history}</div></div></div><div class="panel-label">Числа (×36 с возвратом ставки)</div><div class="numbers-board">${picks}</div><div class="panel-label">Внешние ставки</div><div class="option-grid">${out}</div><p class="tiny">Фишка: ${money(state.chip)} · На столе ${selected.length} ставок, ${money(selected.reduce((v,x)=>v+x.stake,0))}</p><div class="button-row"><button class="btn gold" data-action="vr-spin" ${!selected.length||r.spinning?'disabled':''}>◉ КРУТИТЬ</button><button class="btn" data-action="vr-undo" ${!selected.length||r.spinning?'disabled':''}>↶ Отменить</button><button class="btn" data-action="vr-clear" ${!selected.length||r.spinning?'disabled':''}>Очистить</button></div></div></div><div class="panel" style="margin-top:17px"><div class="panel-body">${amountHTML()}<div class="chip-toolbar"><div class="chip-stack">${[10,50,100,500,1000].map(n=>`<button class="chip-button ${state.chip===n?'active':''}" data-action="chip" data-value="${n}">${n}</button>`).join('')}</div></div><p class="tiny">Размер ставки для рулетки задаётся выбранной фишкой.</p></div></div>`}
function vrBet(kind){const key=state.game==='roulette-us'?'us':state.game==='roulette-fr'?'fr':null;if(!key)return;const r=rt[key]||(rt[key]={bets:[],history:[],spinning:false});const valid=(kind.startsWith('n:')&&(key==='us'?R_US:R_FR).includes(kind.slice(2)))||SIMPLE_ROULETTE_BETS.some(x=>x[0]===kind);if(!valid||r.spinning||!spend(state.chip))return;r.bets.push({kind,stake:state.chip});render()}
function vrClear(last=false){const r=rt[state.game==='roulette-us'?'us':'fr'];if(!r||r.spinning||!r.bets.length)return;if(last){if(refund(r.bets[r.bets.length-1].stake))r.bets.pop()}else if(refund(r.bets.reduce((a,b)=>a+b.stake,0)))r.bets=[];render()}
function vrSpin(){const key=state.game==='roulette-us'?'us':'fr',r=rt[key];if(!r||r.spinning||!r.bets?.length)return;const bets=r.bets.splice(0),stake=bets.reduce((a,b)=>a+b.stake,0),numbers=key==='us'?R_US:R_FR,n=numbers[rnd(numbers.length)],epoch=roundEpoch;r.spinning=true;r.notice='Колесо вращается';render();setTimeout(()=>{if(epoch!==roundEpoch)return;const payout=bets.reduce((s,b)=>s+rouletteVariantWin(b.kind,n,key,b.stake),0);r.spinning=false;r.last=n;r.history=[n,...(r.history||[])].slice(0,60);r.notice=`Выпало ${n}. Выплата ${money(payout)}`;settle(key==='us'?'Рулетка США':'Рулетка Франции',stake,payout,`Выпало ${n}`);if(state.game===(key==='us'?'roulette-us':'roulette-fr'))render()},spinDuration(1350))}

// Three Card Poker: standard Ante/Play with straight > flush for three-card ranks.
function threeScore(cards){if(cards.length!==3||cards.some(c=>!RANKS.includes(c.rank)))throw Error('Карты');const vals=cards.map(c=>RANKS.indexOf(c.rank)===0?14:RANKS.indexOf(c.rank)+1).sort((a,b)=>b-a),asc=[...vals].sort((a,b)=>a-b),flush=cards.every(c=>c.suit===cards[0].suit),straight=(asc[2]-asc[0]===2&&new Set(asc).size===3)||asc.join(',')==='2,3,14';const tri=vals[0]===vals[1]&&vals[1]===vals[2],pair=vals[0]===vals[1]||vals[1]===vals[2];let cls=flush&&straight?5:tri?4:straight?3:flush?2:pair?1:0;let tie=vals;if(pair&&!tri){const p=vals.find(v=>vals.filter(x=>x===v).length===2),k=vals.find(v=>v!==p);tie=[p,k]}if(straight&&asc.join(',')==='2,3,14')tie=[3];return {cls,tie,qualifies:cls>0||vals[0]>=12}}
function compareThree(a,b){const A=threeScore(a),B=threeScore(b);if(A.cls!==B.cls)return Math.sign(A.cls-B.cls);for(let i=0;i<Math.max(A.tie.length,B.tie.length);i++){const x=(A.tie[i]||0)-(B.tie[i]||0);if(x)return Math.sign(x)}return 0}
function threecardHTML(){const r=rt.threecard,playing=r?.active;const cards=r?`<div class="poker-cards">${r.player.map(c=>cardHTML(c)).join('')}</div>`:'';const dealer=r&&!playing?`<div class="poker-cards">${r.dealer.map(c=>cardHTML(c)).join('')}</div>`:playing?'Дилерские карты закрыты':'—';return extraPanel('♦ 3 CARD POKER',`<div class="panel-label">Твои карты</div>${cards||'Ставка Ante'}<div class="panel-label">Дилер</div>${dealer}<div class="center-message">${esc(r?.notice||'Сделай Ante и реши — играть или сбросить')}</div>${playing?`<div class="button-row"><button class="btn primary" data-action="three-play" ${state.balance<r.stake?'disabled':''}>PLAY: ЕЩЁ ${money(r.stake)}</button><button class="btn danger" data-action="three-fold">FOLD · сброс</button></div>`:''}<p class="tiny">Бонус Ante (прибыль): стрит ×1, тройка ×4, стрит-флеш ×5. Выплачивается только при Play.</p>`,'Раздать три карты','three-deal',playing)}
function threeDeal(){if(rt.threecard?.active||!spend(state.stake))return;const deck=newDeck(1);rt.threecard={active:true,player:[draw(deck),draw(deck),draw(deck)],dealer:[draw(deck),draw(deck),draw(deck)],stake:state.stake,notice:'Выбери Play или Fold'};render()}
function threeFinish(play){const r=rt.threecard;if(!r?.active)return;if(play&&!spend(r.stake))return;r.active=false;const base=r.stake,stake=play?base*2:base,cmp=compareThree(r.player,r.dealer),dq=threeScore(r.dealer).qualifies,ps=threeScore(r.player),bonus=play?base*({3:1,4:4,5:5}[ps.cls]||0):0;let payout=0;if(play){if(!dq)payout=base*2+base;else if(cmp>0)payout=base*4;else if(cmp===0)payout=base*2;payout+=bonus}r.notice=!play?'Карты сброшены':`Игрок ${['старшая карта','пара','флеш','стрит','тройка','стрит-флеш'][ps.cls]}; ${dq?'дилер играет':'дилер не квалифицировался'}. Выплата ${money(payout)}`;settle('3 Card Poker',stake,payout,play?'Play':'Fold');render()}

// Casino War: 6-deck shoe; tie -> surrender or extra War bet.
function warValue(c){return c.rank==='A'?14:RANKS.indexOf(c.rank)+1}
function warHTML(){const r=rt.war,tie=!!r?.tied;return extraPanel('⚔ CASINO WAR',`<div class="hilo-cards"><div><span class="panel-label">ИГРОК</span>${r?cardHTML(r.player):'?'}</div><div class="hilo-arrow">⚔</div><div><span class="panel-label">ДИЛЕР</span>${r?cardHTML(r.dealer):'?'}</div></div><div class="center-message">${esc(r?.notice||'Самая старшая карта выигрывает')}</div>${tie?`<div class="button-row"><button class="btn danger" data-action="war-fold">Сдаться (вернуть ½)</button><button class="btn primary" data-action="war-fight" ${state.balance<r.stake?'disabled':''}>ВОЙНА: +${money(r.stake)}</button></div>`:''}`,'⚔ РАЗДАТЬ КАРТЫ','war-deal',tie)}
function warDeal(){if(rt.war?.tied||!spend(state.stake))return;const deck=newDeck(6),player=draw(deck),dealer=draw(deck),a=warValue(player),b=warValue(dealer),r={player,dealer,stake:state.stake,deck,tied:a===b,notice:''};rt.war=r;if(r.tied)r.notice='Ничья! Сдаться или удвоить ставку для войны?';else{const payout=a>b?state.stake*2:0;r.notice=a>b?'Игрок победил':'Дилер победил';settle('Casino War',r.stake,payout)}render()}
function warResolve(war){const r=rt.war;if(!r?.tied)return;const stake=r.stake;if(war&&!spend(stake))return;r.tied=false;let payout=0,total=stake;if(war){for(let i=0;i<3;i++)draw(r.deck);r.player=draw(r.deck);r.dealer=draw(r.deck);total=stake*2;payout=warValue(r.player)>=warValue(r.dealer)?stake*3:0;r.notice=payout?'Война выиграна (доп. ставка возвращена)':'Война проиграна'}else{payout=Math.floor(stake/2);r.notice='Сдача: возвращена половина ставки'}settle('Casino War',total,payout);render()}
// Dragon Tiger: sampled without replacement from 8 decks.
function dragonHTML(){const r=rt.dragontiger;const opts=[['dragon','🐉 Дракон','×2'],['tiger','🐅 Тигр','×2'],['tie','НИЧЬЯ','×12']];return extraPanel('🐉 DRAGON / TIGER',`<div class="hilo-cards"><div>${r?cardHTML(r.dragon):'🐉'}</div><div class="hilo-arrow">VS</div><div>${r?cardHTML(r.tiger):'🐅'}</div></div>${extraOptions(opts,'dragon-pick',state.dragonPick||'dragon')}${resultNote(r?.notice||'',r?.payout>r?.stake?'win':'')}`,'РАЗДАТЬ','dragon-deal')}
function dragonDeal(){const stake=state.stake;if(!spend(stake))return;const deck=newDeck(8),dragon=draw(deck),tiger=draw(deck),a=RANKS.indexOf(dragon.rank),b=RANKS.indexOf(tiger.rank),pick=state.dragonPick||'dragon',tie=a===b,won=pick==='dragon'?a>b:pick==='tiger'?b>a:tie,payout=won?stake*(pick==='tie'?12:2):tie&&pick!=='tie'?Math.floor(stake/2):0;rt.dragontiger={dragon,tiger,stake,payout,notice:tie?'Равные ранги':a>b?'Дракон победил':'Тигр победил'};settle('Dragon Tiger',stake,payout);render()}

// Tower: each row has 3 positions and independently hidden traps.
function towerMultiplier(level,mines){return level?Math.min(BALANCE_CAP,.97*Math.pow(3/(3-mines),level)):1}
function towerHTML(){const r=rt.tower,active=!!r?.active,levels=5,opened=r?.opened||[],traps=r?.traps||[];const cells=Array.from({length:levels},(_,row)=>`<div class="tower-row">${Array.from({length:3},(_,col)=>{const isOpen=opened[row]===col,reveal=!active&&r&&traps[row]?.includes(col);return `<button class="mine-tile ${isOpen?'safe':''} ${reveal?'bomb':''}" data-action="tower-pick" data-row="${row}" data-index="${col}" ${!active||row!==opened.length?'disabled':''}>${isOpen?'◆':reveal?'✹':'?'}</button>`}).join('')}</div>`).reverse().join('');return `<div class="panel"><div class="panel-header"><h2>▤ БАШНЯ · 5 ЭТАЖЕЙ</h2><span class="status-pill">${active?'ИГРА ИДЁТ':'ГОТОВО'}</span></div><div class="panel-body"><div class="tower-board">${cells}</div><div class="dice-details"><div>ЭТАЖ<b>${opened.length} / 5</b></div><div>МНОЖИТЕЛЬ<b>×${towerMultiplier(opened.length,r?.mineCount||state.towerMines||1).toFixed(2)}</b></div></div>${resultNote(r?.notice||'',r?.status==='cashed'?'win':'')}${active?`<button class="btn gold block" data-action="tower-cash" ${!opened.length?'disabled':''}>ЗАБРАТЬ ${money(extraPayout(r.stake,towerMultiplier(opened.length,r.mineCount)))}</button>`:''}</div></div><div class="panel betting-panel" style="margin-top:16px"><div class="panel-body">${amountHTML()}${extraOptions([['1','1 ловушка в каждом ряду','2 безопасные'],['2','2 ловушки в каждом ряду','1 безопасная']],'tower-mines',String(state.towerMines||1))}<button class="btn primary block" data-action="tower-start" ${active?'disabled':''}>НАЧАТЬ ПОДЪЁМ</button></div></div>`}
function towerStart(){if(rt.tower?.active||!spend(state.stake))return;const mineCount=state.towerMines||1,traps=Array.from({length:5},()=>{const available=[0,1,2],chosen=[];for(let i=0;i<mineCount;i++)chosen.push(available.splice(rnd(available.length),1)[0]);return chosen});rt.tower={active:true,opened:[],traps,mineCount,stake:state.stake,notice:'Выбери одну ячейку на первом этаже'};render()}
function towerPick(row,col){const r=rt.tower;if(!r?.active||!Number.isInteger(col)||col<0||col>2||row!==r.opened.length)return;if(r.traps[row].includes(col)){r.active=false;r.status='lost';r.notice='Ловушка! Ставка проиграла';settle('Tower',r.stake,0)}else{r.opened.push(col);r.notice=`Пройден этаж ${r.opened.length}`;if(r.opened.length===5){towerCash(true);return}}render()}
function towerCash(auto=false){const r=rt.tower;if(!r?.active||!r.opened.length)return;r.active=false;r.status='cashed';const payout=extraPayout(r.stake,towerMultiplier(r.opened.length,r.mineCount));r.notice=auto?'Башня пройдена!':`Получено ${money(payout)}`;settle('Tower',r.stake,payout);render()}

function uniqueDraw(max,count){const a=Array.from({length:max},(_,i)=>i+1);for(let i=0;i<count;i++){const j=i+rnd(max-i);[a[i],a[j]]=[a[j],a[i]]}return a.slice(0,count)}
function bingoLines(card,drawn){const seen=new Set(drawn);let lines=0;for(let r=0;r<5;r++)if(Array.from({length:5},(_,c)=>card[r*5+c]).every(v=>v===0||seen.has(v)))lines++;for(let c=0;c<5;c++)if(Array.from({length:5},(_,r)=>card[r*5+c]).every(v=>v===0||seen.has(v)))lines++;for(const diag of [[0,6,12,18,24],[4,8,12,16,20]])if(diag.every(i=>card[i]===0||seen.has(card[i])))lines++;return lines}
function bingoHTML(){const r=rt.bingo;return extraPanel('▩ BINGO 75',`<div class="bingo-grid">${Array.from({length:25},(_,i)=>{const n=r?.card[i]||0;return `<div class="bingo-cell ${i===12||r?.drawn.includes(n)?'marked':''}">${n||'★'}</div>`}).join('')}</div><p class="tiny">Случайная карточка; 40 шаров из 75. Центр свободный.</p><div class="history-mini">${(r?.drawn||[]).map(n=>`<span class="ball-mini">${n}</span>`).join('')}</div>${resultNote(r?.notice||'','win')}`,'▩ РАЗЫГРАТЬ BINGO','bingo-play')}
function bingoPlay(){if(!spend(state.stake))return;const cols=Array.from({length:5},(_,c)=>uniqueDraw(15,5).map(x=>x+15*c));const card=Array.from({length:25},(_,i)=>i===12?0:cols[i%5][Math.floor(i/5)]),drawn=uniqueDraw(75,40),lines=bingoLines(card,drawn),stake=state.stake,m=lines===0?0:lines===1?2.5:lines===2?5:12,payout=extraPayout(stake,m);rt.bingo={card,drawn,lines,stake,payout,notice:`Готово линий: ${lines}. Выплата ${money(payout)}`};settle('Bingo 75',stake,payout);render()}
const LOTTO_PAY={3:15,4:150,5:2500,6:1000000};
function lottoHTML(){const r=rt.lotto,picks=state.lottoPicks||[],drawn=r?.drawn||[];const cells=Array.from({length:49},(_,i)=>{const v=i+1,chosen=picks.includes(v),hit=drawn.includes(v);return `<button class="keno-num ${chosen?'selected':''} ${hit?'drawn':''} ${chosen&&hit?'matched':''}" data-action="lotto-pick" data-value="${v}" aria-pressed="${chosen}">${v}</button>`}).join('');return extraPanel('✷ ЛОТЕРЕЯ 6 / 49',`<div class="lotto-grid">${cells}</div><div class="keno-count">Выбрано ${picks.length} / 6 ${r?`· Совпало ${r.hits}`:''}</div><p class="tiny">3: ×15 · 4: ×150 · 5: ×2500 · 6: ×1 000 000. Числа 1–49 равновероятны.</p>${resultNote(r?.notice||'',r?.payout>0?'win':'')}`,'✷ РАЗЫГРАТЬ 6 ЧИСЕЛ','lotto-play',picks.length!==6)}
function lottoPick(n){if(!Number.isInteger(n)||n<1||n>49)return;const picks=state.lottoPicks||(state.lottoPicks=[]),i=picks.indexOf(n);if(i>=0)picks.splice(i,1);else if(picks.length<6)picks.push(n);rt.lotto=null;render()}
function lottoPlay(){const picks=state.lottoPicks||[];if(picks.length!==6||new Set(picks).size!==6||!spend(state.stake))return;const drawn=uniqueDraw(49,6),hits=drawn.filter(n=>picks.includes(n)).length,stake=state.stake,payout=extraPayout(stake,LOTTO_PAY[hits]||0);rt.lotto={drawn,hits,stake,payout,notice:`Розыгрыш: ${drawn.join(', ')}. Совпадений: ${hits}. Выплата ${money(payout)}`};settle('Лотерея',stake,payout);render()}
const SCRATCH_SYMBOLS=['★','♠','♣','♥','♦'];
function scratchMult(symbols){const counts={};symbols.forEach(x=>counts[x]=(counts[x]||0)+1);const n=Math.max(...Object.values(counts));return ({3:.6,4:1.2,5:2,6:5,7:10,8:30,9:100}[n]||0)}
function scratchHTML(){const r=rt.scratch,opened=r?.opened||[];const tiles=Array.from({length:9},(_,i)=>`<button class="scratch-cell" data-action="scratch-open" data-index="${i}" ${!r?.active||opened.includes(i)?'disabled':''}>${opened.includes(i)||r&&!r.active?r.symbols[i]:'❔'}</button>`).join('');return `<div class="panel"><div class="panel-header"><h2>▧ СКРЕТЧ-КАРТА</h2><span class="status-pill">${r?.active?'ОТКРЫВАЙ':'НОВАЯ КАРТА'}</span></div><div class="panel-body"><div class="scratch-board">${tiles}</div><p class="tiny">Открой все девять клеток. Множители за наибольшую группу одинаковых символов: 3×0,6, 4×1,2, 5×2, 6×5, 7×10, 8×30, 9×100.</p>${resultNote(r?.notice||'',r&&!r.active&&r.payout>r.stake?'win':'')}</div></div><div style="margin-top:17px">${betPanel('▧ КУПИТЬ ВИРТУАЛЬНУЮ КАРТУ','scratch-start',!!r?.active)}</div>`}
function scratchStart(){if(rt.scratch?.active||!spend(state.stake))return;const symbols=Array.from({length:9},()=>SCRATCH_SYMBOLS[rnd(SCRATCH_SYMBOLS.length)]);rt.scratch={active:true,symbols,opened:[],stake:state.stake,notice:'Открой девять ячеек'};render()}
function scratchOpen(i){const r=rt.scratch;if(!r?.active||!Number.isInteger(i)||i<0||i>=9||r.opened.includes(i))return;r.opened.push(i);if(r.opened.length===9){r.active=false;const mult=scratchMult(r.symbols);r.payout=extraPayout(r.stake,mult);r.notice=`Готово. Выплата ${money(r.payout)}`;settle('Скретч',r.stake,r.payout)}render()}
const SEVEN_BETS=[['under','МЕНЬШЕ 7','×2.20'],['over','БОЛЬШЕ 7','×2.20'],['seven','РОВНО 7','×5.70'],['double','ДУБЛЬ','×5.60'],['even','ЧЁТНАЯ СУММА','×1.90']];
function sevenOutcome(dice,pick){const s=dice[0]+dice[1];return pick==='under'?s<7:pick==='over'?s>7:pick==='seven'?s===7:pick==='double'?dice[0]===dice[1]:pick==='even'&&s%2===0}
function sevenHTML(){const r=rt.seven;return extraPanel('⚇ LUCKY SEVEN',`<div class="dice-three">${(r?.dice||[2,5]).map(v=>`<span class="die-face">${['','⚀','⚁','⚂','⚃','⚄','⚅'][v]}</span>`).join('')}</div><div class="center-message">${esc(r?.notice||'Выбери исход двух кубиков')}</div>${extraOptions(SEVEN_BETS,'seven-bet',state.sevenBet||'seven')}`,'⚇ БРОСИТЬ КОСТИ','seven-roll')}
function sevenRoll(){const stake=state.stake;if(!spend(stake))return;const dice=[rnd(6)+1,rnd(6)+1],pick=state.sevenBet||'seven',mult={under:2.2,over:2.2,seven:5.7,double:5.6,even:1.9}[pick],won=sevenOutcome(dice,pick),payout=won?extraPayout(stake,mult):0;rt.seven={dice,stake,payout,notice:`Сумма ${dice[0]+dice[1]} · ${won?'победа':'проигрыш'} · выплата ${money(payout)}`};settle('Lucky Seven',stake,payout);render()}
function dicePokerKind(d){if(d.length!==5)return'none';const freq=Object.values(d.reduce((o,x)=>(o[x]=(o[x]||0)+1,o),{})).sort((a,b)=>b-a),un=[...new Set(d)].sort((a,b)=>a-b);if(freq[0]===5)return'five';if(freq[0]===4)return'four';if(freq[0]===3&&freq[1]===2)return'full';if(un.length===5&&un[4]-un[0]===4)return'straight';if(freq[0]===3)return'three';if(freq[0]===2&&freq[1]===2)return'two';return'none'}
const DICE_POKER_PAY={none:0,two:1,three:1.5,straight:5,full:4,four:7,five:50};
function dicePokerHTML(){const r=rt.dicepoker;return extraPanel('⚄ DICE POKER',`<div class="dice-three">${(r?.dice||[1,3,4,5,6]).map(v=>`<span class="die-face">${['','⚀','⚁','⚂','⚃','⚄','⚅'][v]}</span>`).join('')}</div><div class="center-message">${esc(r?.notice||'Брось 5 костей за одну ставку')}</div><p class="tiny">Две пары ×1 · тройка ×1,5 · фулл-хаус ×4 · стрит ×5 · каре ×7 · пять одинаковых ×50</p>`,'⚄ БРОСИТЬ ПЯТЬ КОСТЕЙ','dicepoker-roll')}
function dicePokerRoll(){if(!spend(state.stake))return;const stake=state.stake,dice=Array.from({length:5},()=>rnd(6)+1),kind=dicePokerKind(dice),payout=extraPayout(stake,DICE_POKER_PAY[kind]);rt.dicepoker={dice,stake,payout,kind,notice:`Комбинация: ${kind}. Выплата ${money(payout)}`};settle('Покер на костях',stake,payout);render()}
function treasureHTML(){const r=rt.treasure;const cells=Array.from({length:9},(_,i)=>`<button class="treasure-cell" data-action="treasure-open" data-index="${i}" ${!r?.active?'disabled':''}>${r&&!r.active?'×'+r.values[i]:r?.chosen===i?'×'+r.values[i]:'🎁'}</button>`).join('');return `<div class="panel"><div class="panel-header"><h2>♢ СУНДУКИ</h2><span class="status-pill">${r?.active?'ВЫБИРАЙ':'ГОТОВО'}</span></div><div class="panel-body"><div class="treasure-board">${cells}</div><p class="tiny">9 сундуков: шесть пустых, по одному с ×1, ×2 и ×5. Выбери один и забери его содержимое.</p>${resultNote(r?.notice||'',r?.payout>r?.stake?'win':'')}</div></div><div style="margin-top:17px">${betPanel('♢ НАЧАТЬ РАУНД','treasure-start',!!r?.active)}</div>`}
function treasureStart(){if(rt.treasure?.active||!spend(state.stake))return;const values=[0,0,0,0,0,0,1,2,5];for(let i=values.length-1;i>0;i--){const j=rnd(i+1);[values[i],values[j]]=[values[j],values[i]]}rt.treasure={active:true,values,stake:state.stake,notice:'Выбери любой закрытый сундук'};render()}
function treasureOpen(i){const r=rt.treasure;if(!r?.active||!Number.isInteger(i)||i<0||i>=9)return;r.active=false;r.chosen=i;r.payout=extraPayout(r.stake,r.values[i]);r.notice=`Сундук ${i+1}: ×${r.values[i]}, получено ${money(r.payout)}`;settle('Сундуки',r.stake,r.payout);render()}

// Backups contain virtual-chip progress only and never include active wagers.
function snapshot(){
 save();const exportProfiles={};for(const name of ['free','daily']){
  const p=profileSnapshots[name];exportProfiles[name]={...p,balance:Math.min(BALANCE_CAP,p.balance+p.reserved),reserved:0};
 }
 const current=exportProfiles[state.mode];
 return {format:'NEON_CASINO_SAVE',version:5,created:new Date().toISOString(),mode:state.mode,preferences:{favorites:[...favoriteGames],recent:recentGames.slice(0,4),view:casinoView},
 ...current,profiles:exportProfiles,dailyProgress:JSON.parse(JSON.stringify(dailyProgress))}
}
// Android returns this only after the document has actually been written.
// The desktop/browser exporter continues to work independently.
if(typeof window!=='undefined') window.neonNativeBackupComplete=function(success){
 toast(success?'Резервная копия сохранена в выбранный файл':'Резервная копия не сохранена',!success);
};
function exportBackup(){if(!canModify()){leaseBlock();return}try{const data=JSON.stringify(snapshot(),null,2);if(typeof window!=='undefined'&&window.NeonBridge&&typeof window.NeonBridge.saveBackup==='function'){window.NeonBridge.saveBackup(data);return;}const blob=new Blob([data],{type:'application/json'}),url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download='neon-casino-save.json';document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Скачивание копии сохранения запущено')}catch(e){toast('Экспорт не поддерживается этим браузером',true)}}
function resetRuntime(){lastRouletteBets=[];roundEpoch++;if(rt.crash?.interval)clearInterval(rt.crash.interval);if(rt.plinko?.timer)clearInterval(rt.plinko.timer);Object.assign(rt,{bets:[],rouletteSpinning:false,rouletteRotation:0,rouletteResult:null,rouletteNotice:'',rouletteTape:null,rouletteTicket:null,wheelSpinning:false,wheelRotation:0,wheelResult:null,wheelNotice:'',bj:null,crash:null,slots:null,mines:null,plinko:null,diceRoll:null,diceNotice:'',baccarat:null,coin:null,keno:null,poker:null,sicbo:null,limbo:null,hilo:null,craps:null})}
const PREIMPORT_KEY='neon-casino-preimport-v1';
function preImportBackup(){
 try{const raw=localStorage.getItem(PREIMPORT_KEY);return typeof raw==='string'&&raw.length<=1000000?raw:null}catch(e){return null}
}
function walletUndoHTML(){return preImportBackup()?'<p class="tiny">Страховочная копия перед последним импортом сохранена на этом устройстве.</p><button class="btn small gold" data-action="backup-undo">↶ Вернуть состояние до импорта</button>':''}
function restorePreImportBackup(){
 const previous=preImportBackup();if(!previous){toast('Страховочная копия недоступна',true);return false}
 const ok=loadBackup(previous,{skipCheckpoint:true,undo:true});
 if(ok){try{localStorage.removeItem(PREIMPORT_KEY)}catch(e){toast('Прогресс восстановлен, но страховочную копию не удалось удалить',true)}}
 return ok;
}
function loadBackup(raw,options={}){
 if(!canModify())throw Error('Другое окно редактирует сохранение. Обнови страницу после его закрытия.');
 if(typeof raw!=='string'||raw.length>1000000)throw Error('Файл слишком большой или некорректный');
 const obj=JSON.parse(raw);
 const validProfile=p=>p&&Number.isSafeInteger(p.balance)&&p.balance>=0&&p.balance<=9000000000000000&&p.reserved===0&&p.stats&&typeof p.stats==='object'&&!Array.isArray(p.stats)&&Array.isArray(p.rouletteHistory)&&Array.isArray(p.activity);
 if(!obj||obj.format!=='NEON_CASINO_SAVE'||![2,3,4,5].includes(obj.version)||!validProfile(obj))throw Error('Некорректный формат сохранения');
 if(obj.version>=3&&(!obj.profiles||!validProfile(obj.profiles.free)||!validProfile(obj.profiles.daily)||!obj.dailyProgress||!Number.isSafeInteger(obj.dailyProgress.day)||obj.dailyProgress.day<1||obj.dailyProgress.day>100000000||!Array.isArray(obj.dailyProgress.history)))throw Error('Некорректные игровые дни в сохранении');
 if(obj.version===5&&(
  !obj.preferences||!Array.isArray(obj.preferences.favorites)||!Array.isArray(obj.preferences.recent)||
  obj.preferences.favorites.length>GAMES.length||obj.preferences.recent.length>4||
  [...obj.preferences.favorites,...obj.preferences.recent].some(id=>typeof id!=='string'||!GAMES.some(g=>g.id===id))
 ))throw Error('Некорректное избранное в сохранении');
 if(!confirm(options.undo?'Вернуть оба кошелька, историю и избранное к состоянию перед предыдущим импортом?':'Заменить оба виртуальных кошелька, историю и избранное данными из файла? Перед импортом сохранится локальная страховочная копия.'))return false;
 if(!options.skipCheckpoint){
  if(volatileMode||!instanceStorageAvailable)throw Error('Локальное сохранение недоступно. Сначала экспортируй прогресс в JSON.');
  try{const checkpoint=JSON.stringify(snapshot());if(checkpoint.length>1000000)throw Error('checkpoint too large');localStorage.setItem(PREIMPORT_KEY,checkpoint)}
  catch(e){throw Error('Не удалось создать страховочную копию перед импортом. Экспортируй прогресс вручную и освободи место на устройстве.');}
 }
 const previous=walletCheckpoint();
 profileSnapshots.free=safeProfile(obj.version>=3?obj.profiles.free:obj,50000);
 profileSnapshots.daily=safeProfile(obj.version>=3?obj.profiles.daily:{},DAILY_CREDIT);
 if(obj.version>=3){const d=obj.dailyProgress;dailyProgress={day:d.day,rounds:safeAmount(d.rounds),wagered:safeAmount(d.wagered),paid:safeAmount(d.paid),startedAt:Number.isFinite(d.startedAt)?d.startedAt:Date.now(),history:safeDayHistory(d.history)}}
 else dailyProgress={day:1,rounds:0,wagered:0,paid:0,startedAt:Date.now(),history:[]};
 state.mode=obj.version>=3?validMode(obj.mode):'free';
 Object.assign(state,profileSnapshots[state.mode]);if(!commitWallet(previous))throw Error('Не удалось записать импорт. Старый прогресс сохранён.');
 if(obj.version===5){
  favoriteGames=new Set(obj.preferences.favorites);recentGames=[...new Set(obj.preferences.recent)];if(['hall','casual'].includes(obj.preferences.view))casinoView=obj.preferences.view;
  try{localStorage.setItem(FAVORITES_STORAGE,JSON.stringify([...favoriteGames]));localStorage.setItem(RECENT_STORAGE,JSON.stringify(recentGames));localStorage.setItem(VIEW_KEY,casinoView)}
  catch(e){toast('Кошельки восстановлены, но избранное не удалось сохранить на устройстве',true)}
  lastRenderedNavigation=null;renderRecent();
 }
 resetRuntime();state.modal=null;render();toast('Сохранение восстановлено');return true
}

// Statistics from all saved rounds across both modes, independent of manual credits.
function allTimeTotals(){
 const f=state.mode==='free'?currentProfile():profileSnapshots.free;
 const d=state.mode==='daily'?currentProfile():profileSnapshots.daily;
 const total={rounds:0,wins:0,wagered:0,paid:0,positiveNet:0,negativeNet:0,manualGranted:0};
 for(const p of [f,d])for(const key of Object.keys(total).filter(x=>x!=='manualGranted'))total[key]=Math.min(BALANCE_CAP,total[key]+safeAmount(p.lifetime?.[key]));
 // manualGranted belongs to the wallet, not the nested lifetime counter.
 total.manualGranted=Math.min(BALANCE_CAP,safeAmount(f.manualGranted)+safeAmount(d.manualGranted));
 return total;
}
function signedMoney(n){return (n>0?'+':n<0?'−':'')+money(Math.abs(n))}
function gameName(id){return GAMES.find(g=>g.id===id)?.name||id}
function profileTrendHTML(days){
 const series=days.slice(0,21).reverse();
 if(!series.length)return '<p class="empty-note">График появится после первых сыгранных раундов.</p>';
 const max=Math.max(1,...series.map(d=>Math.abs(d.paid-d.wagered)));
 return `<div class="trend-card"><div class="trend-title"><b>ДИНАМИКА ПО ДНЯМ</b><small>Игровой итог, без пополнений · последние ${series.length} дней с игрой</small></div><div class="trend-grid" role="img" aria-label="Прибыль и убытки по ${series.length} дням">${series.map(d=>{
  const net=d.paid-d.wagered,h=Math.max(net===0?2:5,Math.round(Math.abs(net)/max*45));
  return `<div class="trend-column" title="${esc(d.day)}: ${signedMoney(net)}" aria-label="${esc(d.day)}: ${signedMoney(net)}"><span class="trend-pos">${net>0?`<i style="height:${h}%"></i>`:''}</span><span class="trend-neg">${net<0?`<i style="height:${h}%"></i>`:''}</span></div>`
 }).join('')}</div><div class="trend-key"><span>● Прибыль</span><span>● Убыток</span><span>● Нулевая линия</span></div></div>`;
}
const ACHIEVEMENTS=[
 {id:'first',icon:'✦',title:'Первый раунд',desc:'Сыграть любую игру',done:(t,g,p)=>t.rounds>=1},
 {id:'ten',icon:'♛',title:'Первые 10',desc:'Завершить 10 раундов',done:t=>t.rounds>=10},
 {id:'hundred',icon:'🏆',title:'Сотня раундов',desc:'Завершить 100 раундов',done:t=>t.rounds>=100},
 {id:'thousand',icon:'💎',title:'Тысяча раундов',desc:'Завершить 1000 раундов',done:t=>t.rounds>=1000},
 {id:'explorer',icon:'🧭',title:'Исследователь',desc:'Сыграть в 5 разных игр',done:(t,g)=>g>=5},
 {id:'collector',icon:'🎴',title:'Коллекционер игр',desc:'Сыграть во все 44 игры',done:(t,g)=>g>=GAMES.length},
 {id:'win',icon:'★',title:'Первая победа',desc:'Выиграть хотя бы один раунд',done:t=>t.wins>=1},
 {id:'hot',icon:'♠',title:'Десять побед',desc:'Выиграть 10 раундов',done:t=>t.wins>=10},
 {id:'roulette',icon:'◉',title:'Знакомство с рулеткой',desc:'Сыграть раунд в европейскую рулетку',done:(t,g,p)=>p.some(x=>safeAmount(x.lifetimeGames.roulette?.rounds)>0)},
 {id:'record',icon:'🥇',title:'Большой результат',desc:'Чистый выигрыш в одном раунде от 10 000 фишек',done:(t,g,p)=>p.some(x=>x.recordWin>=10000)},
];
function achievementStatus(){
 const f=state.mode==='free'?currentProfile():profileSnapshots.free,d=state.mode==='daily'?currentProfile():profileSnapshots.daily;
 const totals=allTimeTotals(),profiles=[f,d];
 const seen=new Set(profiles.flatMap(p=>Object.entries(p.lifetimeGames).filter(([,v])=>safeAmount(v.rounds)>0).map(([id])=>id)));
 return ACHIEVEMENTS.map(a=>({...a,unlocked:Boolean(a.done(totals,seen.size,profiles))}));
}
function achievementsHTML(){const list=achievementStatus(),count=list.filter(a=>a.unlocked).length;return `<div class="achievement-summary"><b>${count} / ${list.length}</b><span>Награды открываются за реальные игровые раунды, не за ручные пополнения.</span></div><div class="achievement-grid">${list.map(a=>`<div class="achievement-card ${a.unlocked?'unlocked':'locked'}"><span class="achievement-icon" aria-hidden="true">${a.icon}</span><div><b>${a.title}</b><small>${a.desc}</small></div><strong>${a.unlocked?'✓':'🔒'}</strong></div>`).join('')}</div><p class="profile-footnote">Награды восстанавливаются из накопительной статистики обоих режимов. Достижения до версии 1.8.2 могут быть неполными, если соответствующие данные ранее не сохранялись.</p>`}
function guideHTML(id){
 const rules=gameRules();const g=info(id);
 return `<div class="guide-steps"><div><span>01</span><p><b>Выбери размер ставки</b><small>Укажи количество виртуальных фишек. Сумма резервируется до результата раунда.</small></p></div><div><span>02</span><p><b>Выбери исход или действие</b><small>В играх с числами нажми на нужное поле; в карточных — выбери действия по ходу раздачи.</small></p></div><div><span>03</span><p><b>Запусти раунд</b><small>Нажми игровую кнопку. Результат рассчитывается локально, затем отображается выплата.</small></p></div><div><span>04</span><p><b>Проверь результат</b><small>В профиле доступны ставки, выплаты, выигрыш и проигрыш без учёта ручных пополнений.</small></p></div></div><h3>Правила и выплаты: ${esc(g.name)}</h3><div class="rules guide-rules">${rules[id]||'Подробные правила этого режима ещё не описаны.'}</div><button class="btn small ghost" data-action="fairness">⚖ Как проверяется случайность</button>`;
}
// A local, read-only diagnostic: never touches the wallet or determines a game result.
let fairnessSample=null;
function fairnessSampleRun(){
 if(!globalThis.crypto?.getRandomValues){fairnessSample={error:'Web Crypto недоступен: случайные ставки должны быть заблокированы.'};return fairnessSample}
 const bins=Array(37).fill(0),draws=3700;
 try{for(let i=0;i<draws;i++)bins[rnd(37)]++}catch(e){fairnessSample={error:'Проверка прервана: '+String(e.message||e)};return fairnessSample}
 const expected=draws/37,chi2=bins.reduce((v,n)=>v+(n-expected)**2/expected,0);
 fairnessSample={draws,minimum:Math.min(...bins),maximum:Math.max(...bins),chi2:Math.round(chi2*100)/100};
 return fairnessSample
}
function fairnessHTML(){
 const available=Boolean(globalThis.crypto?.getRandomValues);
 const result=fairnessSample?.error?`<p class="profile-footnote">${esc(fairnessSample.error)}</p>`:fairnessSample?`<p class="profile-footnote">Результат последней локальной выборки: ${fmt(fairnessSample.draws)} чисел, частота каждого исхода от ${fmt(fairnessSample.minimum)} до ${fmt(fairnessSample.maximum)}, χ² = ${fairnessSample.chi2}. Это случайная выборка, а не доказательство честности генератора.</p>`:'<p class="profile-footnote">Проверка не запускалась. Она не меняет баланс или результаты будущих игр.</p>';
 return `<p><b>NEON CASINO — автономный симулятор с виртуальными фишками.</b> Ставки не связаны с реальными деньгами. Исход рассчитывается локально: в рулетке — до анимации, в слотах — в конце прокрутки. Визуальные эффекты сами по себе не меняют таблицы выплат.</p>
 <div class="guide-steps"><div><span>01</span><p><b>Источник случайности</b><small>Web Crypto: crypto.getRandomValues, отбрасывание несбалансированного остатка. Сейчас: <b>${available?'доступен':'НЕДОСТУПЕН'}</b>. Если он недоступен, ставки блокируются.</small></p></div>
 <div><span>02</span><p><b>Реальные вероятности</b><small>Европейская рулетка: 37 исходов, прямое число 1/37, RTP 36/37 = 97,30%. Американская: 38 исходов, RTP 36/38 = 94,74% для прямого числа. Французская La Partage: на внешних ставках RTP 98,65% при возврате половины на зеро (для чётной суммы).</small></p></div>
 <div><span>03</span><p><b>Разные коэффициенты = разные RTP</b><small>В Sic Bo ставка на сумму 5 или 16 имеет расчётный RTP 52,78% с текущим коэффициентом ×19; он значительно хуже рулетки. Коэффициенты являются авторскими демо-правилами. Они не приведены к одному проценту возврата.</small></p></div>
 <div><span>04</span><p><b>Проверяемая история</b><small>Ставки и выплаты фиксируются отдельно от выданных вручную фишек. В профиле можно сравнить сумму ставок, выплат и чистый результат. В пределах одной установки эти данные редактируемы владельцем устройства и не являются независимым доказательством.</small></p></div></div>
 <div class="panel" style="margin:14px 0"><div class="panel-body"><b>Локальная выборочная проверка рулетки</b><p class="tiny">3700 независимых обращений к тому же алгоритму случайного числа 0–36. Проверка не расходует фишки и не влияет на дальнейшие исходы.</p><button class="btn small gold" data-action="fairness-test">Проверить 3700 случайных чисел</button>${result}</div></div>
 <p class="profile-footnote">В комплекте исходников — сквозной автоматизированный аудит 44 игровых сценариев и отдельные математические проверки таблиц выплат. Это инженерные тесты, <b>не являются независимой сертификацией</b>, не криптографическое доказательство результата отдельного раунда и не гарантия выигрыша.</p>`;
}
let profileTab='overview';
let replayRecord=null;
function combinedJournal(){
 const free=state.mode==='free'?currentProfile():profileSnapshots.free;
 const daily=state.mode==='daily'?currentProfile():profileSnapshots.daily;
 return [...free.journal.map(x=>({...x,mode:'Свободный'})),...daily.journal.map(x=>({...x,mode:'Игровые дни'}))].sort((a,b)=>b.at-a.at).slice(0,JOURNAL_LIMIT);
}
function roundReplayHTML(r){
 if(!r)return '<p class="empty-note">Данные раунда недоступны.</p>';
 const net=r.payout-r.stake;
 const roulette=r.replay?.type==='slots'?`<div class="replay-slots" aria-label="Архив барабанов">${r.replay.cells.map((symbol,i)=>`<span class="replay-slot ${r.replay.lines.some(k=>[[0,1,2],[3,4,5],[6,7,8],[0,4,8],[2,4,6]][k].includes(i))?'won':''}">${esc(symbol)}</span>`).join('')}</div><p class="tiny">Выигрышные линии: ${r.replay.lines.length?r.replay.lines.map(i=>i+1).join(', '):'нет'}. Это сохранённые символы, не новый розыгрыш.</p>`:r.replay?.type==='roulette'?`<div class="replay-outcome"><span class="ball-mini ${outcomeColor(r.replay.number)}">${r.replay.number}</span><div><b>Выпавшее число</b><small>Европейская рулетка · сохранённый результат</small></div></div><div class="replay-bets">${r.replay.bets.map(b=>`<div><span>${esc(b.type==='number'?'Число '+b.value:b.type==='combo'?'Комбинация '+b.value:b.type+' '+b.value)}</span><b>${money(b.amount)}</b></div>`).join('')}</div>`:`<div class="replay-outcome"><span class="replay-symbol">${esc(GAMES.find(g=>g.name===r.game)?.icon||'✦')}</span><div><b>${esc(r.detail||'Результат раунда')}</b><small>Для этого режима отдельные ходы и раскладка не сохранялись</small></div></div>`;
 return `<div class="replay-card"><div class="replay-mark">АРХИВНЫЙ РАУНД · БЕЗ ПОВТОРНОЙ СТАВКИ</div><h3>${esc(r.game)}</h3><p class="tiny">${new Date(r.at).toLocaleString('ru-RU')} · ${esc(r.mode||'')}</p>${roulette}<div class="replay-totals"><div>Ставка<b>${money(r.stake)}</b></div><div>Выплата<b>${money(r.payout)}</b></div><div>Итог<b class="${net>=0?'profit-positive':'profit-negative'}">${signedMoney(net)}</b></div></div><p class="tiny">Просмотр не изменяет историю, баланс или случайные результаты.</p></div>`;
}
function profileHTML(){
 const free=state.mode==='free'?currentProfile():profileSnapshots.free;
 const daily=state.mode==='daily'?currentProfile():profileSnapshots.daily;
 const t=allTimeTotals();
 const net=t.paid-t.wagered;
 const modes=[['Свободный',free],['Игровые дни',daily]];
 const panels=`<div class="profile-modes">${modes.map(([name,p])=>`<div class="profile-mode"><span>${name}</span><b class="${p.lifetime.paid>=p.lifetime.wagered?'profit-positive':'profit-negative'}">${signedMoney(p.lifetime.paid-p.lifetime.wagered)}</b><small>${fmt(p.lifetime.rounds)} раундов · ставки ${money(p.lifetime.wagered)}</small></div>`).join('')}</div>`;
 const tabs=`<div class="profile-tabs" role="group" aria-label="Раздел статистики"><button data-action="profile-tab" data-value="overview" class="${profileTab==='overview'?'selected':''}" aria-pressed="${profileTab==='overview'}">Обзор</button><button data-action="profile-tab" data-value="days" class="${profileTab==='days'?'selected':''}" aria-pressed="${profileTab==='days'}">По дням</button><button data-action="profile-tab" data-value="games" class="${profileTab==='games'?'selected':''}" aria-pressed="${profileTab==='games'}">По играм</button><button data-action="profile-tab" data-value="journal" class="${profileTab==='journal'?'selected':''}" aria-pressed="${profileTab==='journal'}">Раунды</button><button data-action="profile-tab" data-value="awards" class="${profileTab==='awards'?'selected':''}" aria-pressed="${profileTab==='awards'}">Награды</button></div>`;
 const buckets=new Map();for(const [mode,p] of [['Свободный',free],['Игровые дни',daily]])for(const b of p.dayBuckets){const v=buckets.get(b.day)||{day:b.day,wagered:0,paid:0,rounds:0};v.wagered+=b.wagered;v.paid+=b.paid;v.rounds+=b.rounds;buckets.set(b.day,v)}
 const days=[...buckets.values()].sort((a,b)=>b.day.localeCompare(a.day));
 const byGame=new Map();for(const p of [free,daily])for(const [id,stat] of Object.entries(p.lifetimeGames)){const old=byGame.get(id)||{id,rounds:0,wagered:0,paid:0};old.rounds+=stat.rounds;old.wagered+=stat.wagered;old.paid+=stat.paid;byGame.set(id,old)}
 const games=[...byGame.values()].sort((a,b)=>b.wagered-a.wagered);
 const journal=combinedJournal();
 let content='';
 if(profileTab==='awards')content=achievementsHTML();
 else if(profileTab==='overview')content=`<div class="profile-hero"><div class="profile-overline">♛ NEON ROYALE · ЗА ВСЁ ВРЕМЯ</div><div class="profile-net ${net>=0?'profit-positive':'profit-negative'}">${signedMoney(net)}</div><div class="profile-caption">Чистый игровой итог = все выплаты − все ставки. Выданные вручную фишки сюда не входят.</div></div><div class="profile-metrics"><div><span>ПОСТАВЛЕНО</span><b>${money(t.wagered)}</b></div><div><span>ПОЛУЧЕНО СО СТАВОК</span><b>${money(t.paid)}</b></div><div><span>РАУНДОВ</span><b>${fmt(t.rounds)}</b></div><div><span>ВЫИГРЫШНЫХ РАУНДОВ</span><b>${fmt(t.wins)}</b></div><div><span>РУЧНЫЕ ПОПОЛНЕНИЯ</span><b>${money(t.manualGranted)}</b></div><div><span>ИГРОВЫХ ДНЕЙ ЗАВЕРШЕНО</span><b>${fmt(Math.max(0,dailyProgress.day-1))}</b></div><div><span>ЛУЧШИЙ ЗАФИКСИРОВАННЫЙ РАУНД</span><b class="profit-positive">+${money(Math.max(free.recordWin,daily.recordWin))}</b></div><div><span>КРУПНЕЙШИЙ ПРОИГРЫШ РАУНДА</span><b class="profit-negative">−${money(Math.max(free.recordLoss,daily.recordLoss))}</b></div><div><span>ПРИБЫЛЬ ПО ПОБЕДАМ · С 1.8.2</span><b class="profit-positive">+${money(t.positiveNet)}</b></div><div><span>ПОТЕРИ ПО РАУНДАМ · С 1.8.2</span><b class="profit-negative">−${money(t.negativeNet)}</b></div></div>${profileTrendHTML(days)}${panels}<p class="profile-footnote">Статистика учитывает все сохранённые раунды и переживает обычный сброс результатов. Суммы по каждому раунду и календарному дню доступны начиная с v1.8.2; ранее существовавшие итоги ставок и выплат перенесены. Ручные пополнения до v1.8.2 восстановить невозможно. Рекорды — по сохранившимся раундам начиная с v1.8.2, позднее они учитываются бессрочно.</p>`;
 else if(profileTab==='days')content=`<p class="profile-footnote">Календарные дни · последние ${DAY_BUCKET_LIMIT} записей каждого режима. Общие итоги выше не ограничены.</p>${profileTrendHTML(days)}<div class="profile-ledger">${days.map(x=>`<div class="profile-ledger-row"><div><b>${esc(x.day)}</b><small>${fmt(x.rounds)} раундов · ставки ${money(x.wagered)}</small></div><strong class="${x.paid>=x.wagered?'profit-positive':'profit-negative'}">${signedMoney(x.paid-x.wagered)}</strong></div>`).join('')||'<p class="empty-note">Первые записи появятся после игры.</p>'}</div><button class="btn small" data-action="daily-history">История завершённых игровых дней</button>`;
 else if(profileTab==='games')content=`<div class="profile-ledger">${games.map(x=>`<div class="profile-ledger-row"><div><b>${esc(gameName(x.id))}</b><small>${fmt(x.rounds)} раундов · ставки ${money(x.wagered)}</small></div><strong class="${x.paid>=x.wagered?'profit-positive':'profit-negative'}">${signedMoney(x.paid-x.wagered)}</strong></div>`).join('')||'<p class="empty-note">Пока нет сыгранных раундов</p>'}</div>`;
 else content=`<p class="profile-footnote">Последние ${JOURNAL_LIMIT} раундов двух режимов. Подробный журнал появился в v1.8.2; общие счётчики бессрочны.</p><div class="profile-ledger">${journal.map(x=>`<div class="profile-ledger-row"><div><b>${esc(x.game)}</b><small>${esc(x.mode)} · ${new Date(x.at).toLocaleString('ru-RU')} · ставка ${money(x.stake)} · выплата ${money(x.payout)}</small></div><strong class="${x.payout>=x.stake?'profit-positive':'profit-negative'}">${signedMoney(x.payout-x.stake)}</strong><button class="btn small replay-open" data-action="replay-round" data-index="${journal.indexOf(x)}">Просмотр</button></div>`).join('')||'<p class="empty-note">Журнал пока пуст</p>'}</div>`;
 return `${tabs}<div class="profile-pane" id="profile-lifetime">${content}</div><div class="profile-export"><button class="btn small" data-action="backup-export">↓ Сохранить профиль и прогресс</button></div>`;
}
function renderModal(){const host=document.getElementById('modalHost');if(!state.modal){host.innerHTML='';return}const close='<button class="icon-btn" data-action="close-modal">✕</button>';let inside='',title='';if(state.modal==='replay'){title='Повтор раунда · архив';inside=roundReplayHTML(replayRecord)}else if(state.modal==='day-summary'){title='Итог игрового дня';const d=dailyProgress.history[0];inside=d?`<div class="day-summary"><div class="day-summary-kicker">ДЕНЬ ${d.day} ЗАВЕРШЁН</div><div class="day-summary-score ${d.paid>=d.wagered?'profit-positive':'profit-negative'}">${signedMoney(d.paid-d.wagered)}</div><p>Чистый игровой результат по ставкам, без ручных пополнений</p><div class="replay-totals"><div>Раундов<b>${fmt(d.rounds)}</b></div><div>Ставок<b>${money(d.wagered)}</b></div><div>Выплат<b>${money(d.paid)}</b></div><div>Осталось<b>${money(d.leftover)}</b></div></div><p class="tiny">Новый день ${dailyProgress.day} начался с ${money(DAILY_CREDIT)}. Этот итог сохранён в истории дней.</p><button class="btn gold" data-action="close-modal">Продолжить</button></div>`:'<p class="empty-note">Нет завершённых игровых дней.</p>'}else if(state.modal==='profile'){title='Мой профиль · история';inside=profileHTML()}else if(state.modal==='guide'){title='Как играть · '+esc(info(state.game).name);inside=guideHTML(state.game)}else if(state.modal==='fairness'){title='Как устроена честность игры';inside=fairnessHTML()}else if(state.modal==='wallet'){
 title=state.mode==='daily'?'Лимит игрового дня':'Виртуальный кошелёк';
 inside=state.mode==='daily'?`<div class="wallet-total"><span>ДЕНЬ ${dailyProgress.day} · ДОСТУПНО</span><b>${money(state.balance)}</b></div><p class="tiny">Каждый игровой день начинается с ${money(DAILY_CREDIT)}. Выдавать дополнительные фишки нельзя. Когда баланс становится меньше минимальной ставки (10 фишек) и раунды завершены, новый день начинается автоматически. Ты также можешь завершить день вручную.</p><div class="button-row"><button class="btn gold" data-action="daily-next" ${state.reserved?'disabled':''}>Завершить день</button><button class="btn" data-action="daily-history">История дней</button></div>`:
 `<div class="wallet-total"><span>ТВОЙ БАЛАНС</span><b>${money(state.balance)}</b></div><p class="tiny">Можно выдавать себе любые фишки. Это не деньги, их нельзя купить или вывести.</p><div class="modal-buttons">${[1000,10000,50000,100000].map(v=>`<button class="btn gold" data-action="add-chips" data-value="${v}">＋ ${fmt(v)}</button>`).join('')}</div><span class="panel-label" style="display:block;margin:20px 0 7px">ПРОИЗВОЛЬНАЯ СУММА</span><div class="button-row"><input id="customChips" class="amount-input" type="number" inputmode="numeric" min="1" max="1000000000" value="100000" aria-label="Сколько фишек выдать"><button class="btn primary" data-action="custom-add">Выдать</button></div>`;
 inside+=`<p class="tiny" style="margin-top:15px">Два режима сохраняются отдельно на устройстве. Экспорт включает оба режима, их историю и виртуальные балансы.</p><div class="button-row"><button class="btn small" data-action="backup-export">↓ Сохранить прогресс</button><button class="btn small" data-action="backup-import">↑ Восстановить</button></div>${walletUndoHTML()}<input id="backupFile" type="file" accept=".json,application/json" hidden><button class="btn danger small" data-action="reset-all">Сбросить оба режима и начать заново</button>`;
}else if(state.modal==='history'){title='История рулетки';inside=`<p class="tiny">Последние ${state.rouletteHistory.length} вращений. Новые — в начале списка.</p><div class="history-list">${state.rouletteHistory.map(x=>`<div class="history-entry"><span class="ball-mini ${outcomeColor(x.n)}">${x.n}</span><span>${new Date(x.at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}</span></div>`).join('')||'<div class="empty-note">История пока пуста</div>'}</div>`}else if(state.modal==='daily-history'){title='История игровых дней';inside=`<p class="tiny">Завершено дней: ${dailyProgress.history.length} · каждый новый день выдаёт ${money(DAILY_CREDIT)}.</p><div class="daily-list">${dailyProgress.history.map(d=>`<div class="daily-item"><b>День ${d.day}</b><span>${d.reason==='empty'?'Фишки закончились':'Завершён вручную'}</span><span>Раундов: ${d.rounds}</span><span>Ставки: ${money(d.wagered)}</span><span>Выплаты: ${money(d.paid)}</span><span>Остаток: ${money(d.leftover)}</span></div>`).join('')||'<div class="empty-note">Дни ещё не завершались</div>'}</div>`}host.innerHTML=`<div class="modal-overlay" data-action="modal-overlay"><div class="modal ${state.modal==='profile'?'profile-modal':''}"><div class="modal-top"><h2>${title}</h2>${close}</div><div class="modal-main">${inside}</div></div></div>`}
function setStake(n){let value=Number(n);if(!Number.isFinite(value))return;state.stake=Math.min(1000000,Math.max(10,Math.round(value)));render()}
function addChips(amount){if(!canModify()){leaseBlock();return}if(state.mode==='daily'){toast('В игровых днях пополнение отключено',true);return}const n=Number(amount);if(!Number.isSafeInteger(n)||n<=0||n>1000000000){toast('Укажи целое число фишек от 1 до 1 000 000 000',true);return}const previous=walletCheckpoint();const before=state.balance;state.balance=Math.min(BALANCE_CAP,state.balance+n);
 const granted=state.balance-before;state.manualGranted=Math.min(BALANCE_CAP,state.manualGranted+granted);
 if(!commitWallet(previous))return;render();toast(`Добавлено ${money(granted)}`)}
function resetAll(){if(!canModify()){leaseBlock();return}if(!confirm('Сбросить ОБА режима, балансы, игровые дни и всю статистику? Активные ставки будут отменены.'))return;
 const previous=walletCheckpoint();profileSnapshots.free=safeProfile({},50000);profileSnapshots.daily=safeProfile({},DAILY_CREDIT);
 dailyProgress={day:1,rounds:0,wagered:0,paid:0,startedAt:Date.now(),history:[]};
 Object.assign(state,safeProfile(profileSnapshots[state.mode],state.mode==='daily'?DAILY_CREDIT:50000));state.modal=null;
 if(!commitWallet(previous))return;resetRuntime();render();toast('Оба режима сброшены')
}
function handleAction(button){const a=button.dataset.action,v=button.dataset.value;switch(a){case'casino-view':setCasinoView(v);break;case'hall-zone':if(CASINO_ZONES.some(z=>z.id===v)){hallZone=v;hallQuery='';applyCasinoView()}break;case'hall-search-clear':setHallQuery('');break;case'hall-open':openHallTable(button.dataset.game);break;case'hall-favorite':toggleFavorite(button.dataset.game);applyCasinoView();break;case'replay-round':{const index=Number(button.dataset.index);const records=combinedJournal();if(Number.isInteger(index)&&index>=0&&index<records.length){replayRecord=records[index];state.modal='replay';renderModal()}break;}case'mode-free':switchMode('free');break;case'mode-daily':switchMode('daily');break;case'daily-next':finishDailyDay('manual');break;case'daily-history':state.modal='daily-history';renderModal();break;case'day-summary':state.modal='day-summary';renderModal();break;case'nav':navigate(button.dataset.game);break;case'wallet':state.modal='wallet';renderModal();break;case'profile':state.modal='profile';profileTab='overview';renderModal();break;case'profile-tab':if(['overview','days','games','journal','awards'].includes(v)){profileTab=v;renderModal()}break;case'game-guide':state.modal='guide';renderModal();break;case'fairness':state.modal='fairness';renderModal();break;case'fairness-test':fairnessSampleRun();state.modal='fairness';renderModal();break;case'backup-export':exportBackup();break;case'backup-import':document.getElementById('backupFile')?.click();break;case'backup-undo':try{restorePreImportBackup()}catch(e){toast('Не удалось вернуть копию: '+e.message,true)}break;case'close-modal':state.modal=null;renderModal();break;case'modal-overlay':if(button.classList.contains('modal-overlay')){state.modal=null;renderModal()}break;case'add-chips':addChips(Number(v));break;case'custom-add':addChips(Number(document.getElementById('customChips')?.value));break;case'reset-all':resetAll();break;case'reset-stats':if(confirm('Сбросить только статистику и последние результаты?')){const previous=walletCheckpoint();state.stats={rounds:0,wins:0,wagered:0,paid:0};state.gameStats={};state.activity=[];if(commitWallet(previous))render()}break;case'amount-step':setStake(state.stake+(Number(button.dataset.delta)*Math.max(10,Math.round(state.stake/2))));break;case'set-stake':setStake(Number(v));break;case'chip':if([10,50,100,500,1000].includes(Number(v))){state.chip=Number(v);state.rouletteUseCustom=false;render()}break;case'roulette-table':if(['classic','pro'].includes(v)&&!rt.rouletteSpinning){state.rouletteTableMode=v;render()}break;case'roulette-anchor':if(!rt.rouletteSpinning&&Number.isInteger(Number(v))&&Number(v)>=0&&Number(v)<=36){state.rouletteAnchor=Number(v);render()}break;case'roulette-combo':roulettePlaceCombo(v);break;case'roulette-bet':rouletteBet(button.dataset.type,v);break;case'roulette-undo':if(!rt.rouletteSpinning&&rt.bets.length){if(refund(rt.bets[rt.bets.length-1].amount))rt.bets.pop();render()}break;case'roulette-clear':if(!rt.rouletteSpinning&&rt.bets.length){if(refund(rt.bets.reduce((s,b)=>s+b.amount,0)))rt.bets=[];render()}break;case'roulette-spin':spinRoulette();break;case'roulette-repeat':rouletteRepeat();break;case'roulette-double':rouletteDouble();break;case'history':state.modal='history';renderModal();break;case'bj-deal':dealBlackjack();break;case'bj-hit':case'bj-stand':case'bj-double':case'bj-split':bjAction(a);break;case'wheel-spin':spinWheel();break;case'crash-start':startCrash();break;case'crash-cash':cashCrash();break;case'slots-spin':spinSlots();break;case'mines-start':startMines();break;case'mine-size':{const size=Number(v);if(!rt.mines?.active&&MINE_BOARDS.includes(size)){state.minesSize=size;state.minesCount=Math.min(state.minesCount,Math.min(35,size-1));render()}break}case'mine-cell':openMine(Number(button.dataset.index));break;case'mines-cash':cashMines();break;case'plinko-drop':dropPlinko();break;case'dice-side':state.diceSide=v;render();break;case'dice-roll':rollDice();break;case'baccarat-pick':state.baccaratBet=v;render();break;case'baccarat-play':playBaccarat();break;case'coin-pick':if(!rt.coin?.flipping){state.coinBet=v;render()}break;case'coin-flip':flipCoin();break;case'keno-pick':kenoPick(Number(v));break;case'keno-play':playKeno();break;case'poker-deal':pokerDeal();break;case'poker-hold':pokerHold(Number(button.dataset.index));break;case'poker-draw':pokerDraw();break;case'sicbo-pick':if(SICBO_IDS.has(v)){state.sicboBet=v;render()}break;case'sicbo-roll':playSicbo();break;case'limbo-target':{const n=Number(v);if([1.5,2,3,5,10,20,50,100].includes(n)){state.limboTarget=n;render()}break}case'limbo-play':playLimbo();break;case'hilo-side':if(['higher','lower'].includes(v)){state.hiloBet=v;render()}break;case'hilo-play':playHilo();break;case'craps-roll':rollCraps();break;case'craps-pick':if(['pass','dont'].includes(v)&&!rt.craps?.active){state.crapsBet=v;render()}break;
 case'vr-bet':vrBet(button.dataset.kind);break;case'vr-spin':vrSpin();break;case'vr-undo':vrClear(true);break;case'vr-clear':vrClear();break;
 case'three-deal':threeDeal();break;case'three-play':threeFinish(true);break;case'three-fold':threeFinish(false);break;
 case'war-deal':warDeal();break;case'war-fold':warResolve(false);break;case'war-fight':warResolve(true);break;
 case'dragon-pick':if(['dragon','tiger','tie'].includes(v)){state.dragonPick=v;render()}break;case'dragon-deal':dragonDeal();break;
 case'tower-mines':if(['1','2'].includes(v)&&!rt.tower?.active){state.towerMines=Number(v);render()}break;
 case'tower-start':towerStart();break;case'tower-pick':towerPick(Number(button.dataset.row),Number(button.dataset.index));break;case'tower-cash':towerCash();break;
 case'bingo-play':bingoPlay();break;case'lotto-pick':lottoPick(Number(v));break;case'lotto-play':lottoPlay();break;
 case'scratch-start':scratchStart();break;case'scratch-open':scratchOpen(Number(button.dataset.index));break;
 case'seven-bet':if(SEVEN_BETS.some(x=>x[0]===v)){state.sevenBet=v;render()}break;case'seven-roll':sevenRoll();break;
 case'dicepoker-roll':dicePokerRoll();break;case'treasure-start':treasureStart();break;case'treasure-open':treasureOpen(Number(button.dataset.index));break;default:break}}
document.body.addEventListener('click',e=>{const button=e.target.closest('[data-action]');if(button&&!button.disabled&&(button.dataset.action!=='modal-overlay'||e.target===button))handleAction(button)});
document.body.addEventListener('change',e=>{if(e.target.id==='backupFile'&&e.target.files?.[0]){const file=e.target.files[0];file.text().then(text=>{try{loadBackup(text)}catch(error){toast('Не удалось восстановить: '+error.message,true)}}).catch(()=>toast('Не удалось прочитать файл',true));return}if(e.target.id==='stakeInput')setStake(e.target.value);if(e.target.id==='minesRange'&&!rt.mines?.active){state.minesCount=Math.max(1,Math.min(Math.min(35,state.minesSize-1),Number(e.target.value)));render()}if(e.target.id==='diceRange'){state.diceChance=Number(e.target.value);render()}});
document.body.addEventListener('input',e=>{if(e.target.id==='hallSearchInput'){setHallQuery(e.target.value);return}if(e.target.id==='rouletteCustomAmount'){state.rouletteCustomStake=String(e.target.value).slice(0,12);state.rouletteUseCustom=true;document.querySelectorAll('[data-action="chip"]').forEach(x=>x.classList.remove('active'));e.target.closest('.roulette-custom-bet')?.classList.add('active')}if(e.target.id==='diceRange'){const p=e.target.value;document.getElementById('diceChanceValue')&&(document.getElementById('diceChanceValue').textContent=p+'%');document.getElementById('diceMultiplierValue')&&(document.getElementById('diceMultiplierValue').textContent='×'+(97/Number(p)).toFixed(2))}if(e.target.id==='minesRange'){document.getElementById('minesCountValue')&&(document.getElementById('minesCountValue').textContent=e.target.value)}});
const backdrop=document.createElement('div');
backdrop.className='mobile-nav-backdrop';
backdrop.setAttribute('aria-hidden','true');
document.body.appendChild(backdrop);
function setMobileNav(visible){
 const aside=document.querySelector('.sidebar');
 const button=document.getElementById('menuButton');
 if(!aside||!button)return;
 const mobile=window.matchMedia('(max-width:960px)').matches;
 const open=Boolean(visible&&mobile);
 aside.classList.toggle('open',open);
 backdrop.classList.toggle('show',open);
 document.body.classList.toggle('nav-visible',open);
 button.setAttribute('aria-expanded',String(open));
 aside.setAttribute('aria-hidden',String(mobile&&!open));
}
document.getElementById('menuButton').addEventListener('click',()=>setMobileNav(!document.querySelector('.sidebar').classList.contains('open')));
document.getElementById('closeSidebar').addEventListener('click',()=>setMobileNav(false));
backdrop.addEventListener('click',()=>setMobileNav(false));
window.addEventListener('resize',()=>{if(window.innerWidth>960)setMobileNav(false)});
window.addEventListener('keydown',e=>{
 if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)&&!document.activeElement?.isContentEditable){
  e.preventDefault();if(window.matchMedia('(max-width:960px)').matches)setMobileNav(true);
  document.getElementById('gameSearch')?.focus();return;
 }
 if(e.key==='Escape'){
  if(document.querySelector('.sidebar').classList.contains('open'))setMobileNav(false);
  else{state.modal=null;renderModal()}
 }
});
setMobileNav(false);
// NEON CASINO v1.5 — independent offline demo games, no real-money features.
// Payouts include returned stake, not just net profit. A simulation, not certified gambling software.
const MORE_GAMES=[
 {id:'andar',icon:'🂱',name:'Andar Bahar',title:'Andar Bahar',sub:'Индийская карточная игра · угадай сторону первой пары'},
 {id:'reddog',icon:'🂡',name:'Red Dog',title:'Red Dog Poker',sub:'Две открытые карты и ставка на ранг третьей'},
 {id:'pick3',icon:'③',name:'Pick 3',title:'Лотерея Pick 3',sub:'Три цифры · точный порядок или любой порядок'},
 {id:'bingo90',icon:'▥',name:'Bingo 90',title:'Бинго · 90 шаров',sub:'Билет 3×9 · линия / две / полный билет'},
 {id:'keno80',icon:'✥',name:'Кено 80',title:'Кено 6 из 80',sub:'Выбери 6 чисел · 20 шаров · таблица выплат'},
 {id:'cardsuit',icon:'♢',name:'Карта судьбы',title:'Цвет, масть и ранг',sub:'Предскажи красную/чёрную, масть, туза или картинку'},
 {id:'ladder',icon:'↑',name:'Double Ladder',title:'Лестница удвоений',sub:'Угадывай цвет карты, увеличивай коэффициент, забирай вовремя'},
 {id:'slots5',icon:'▤',name:'Слоты 5×3',title:'Видеоcлоты · 10 линий',sub:'Пять барабанов · от трёх символов подряд слева'},
 {id:'holdem',icon:'♠',name:'Texas Hold’em Duel',title:'Техасский холдем · дуэль',sub:'Две карманные и пять общих карт · оценка семи карт'},
 {id:'letitride',icon:'♥',name:'Let It Ride',title:'Let It Ride Poker',sub:'Три ставки · убирай две из них до раскрытия общих карт'},
 {id:'rps',icon:'✊',name:'Камень-ножницы',title:'Камень · ножницы · бумага',sub:'Классический дуэльный мини-режим · равенство возвращает ставку'},
 {id:'colors',icon:'◉',name:'Color Dice',title:'Цветные кубики',sub:'Три цветных кубика · хотя бы один / ровно два / все три'}
];
GAMES.push(...MORE_GAMES);
const MORE_RULES={
 andar:'Andar Bahar: центральная карта задаёт ранг. Оставшаяся колода раскрывается поочерёдно слева (Andar) и справа (Bahar). Ставка побеждает, если первая карта такого ранга выйдет на выбранной стороне. Демо-множители: Andar ×1,90, Bahar ×2,00.',
 reddog:'Red Dog: две карты определяют промежуток рангов. Третья выигрывает, если её ранг строго между ними. При нулевом промежутке или одинаковом ранге ставка возвращается. Разрыв 1/2/3/4+ карт: выплаты ×6 / ×5 / ×3 / ×2.',
 pick3:'Pick 3: три независимые равновероятные цифры (000–999). Exact — только правильный порядок, выплата ×900. Any order — любой порядок выбранных цифр; множитель зависит от числа различных перестановок (×900, ×300 или ×150). Демо-таблица выплат.',
 bingo90:'Бинго 90: билет 3×9, по 5 чисел в строке, диапазоны по столбцам. В демо-раунде извлекаются 45 разных шаров. Один/два/три полностью закрытых ряда дают ×11/×50/×600 соответственно. Упрощённая ускоренная версия.',
 keno80:'Кено 6/80: выбираешь ровно шесть разных чисел; система вытаскивает 20 из 80 без повторов. Демо-множители при 3/4/5/6 совпадениях: ×3/×11/×45/×650.',
 cardsuit:'Карта судьбы: случайная карта стандартной колоды. Ставка на цвет ×1,94 (26/52), конкретную масть ×3,88 (13/52), туза ×12,60 (4/52), картинку J/Q/K ×4,20 (12/52).',
 ladder:'Double Ladder: на каждом шаге угадываешь красный или чёрный цвет новой независимой карты из полной колоды с возвращением. После правильного ответа можно забрать фишки. Множитель ×(2×0,97)^N, где N — число побед подряд (до восьми). При ошибке вся ставка проигрывается.',
 slots5:'Видеослоты: пять барабанов и три ряда, десять фиксированных линий. Считаются последовательные одинаковые символы с первого барабана. Точно 3/4/5 одинаковых дают соответственно ×15 / ×40 / ×500 от доли ставки на одну линию. Символы равновероятны; выплаты демонстрационные.',
 holdem:'Техасский холдем, упрощённый шоудаун: игрок и дилер получают по две закрытые карты и пять общих. Лучшие пять карт из семи определяются по стандартным покерным комбинациям. Победа игрока ×1,95, ничья — возврат ставки. Без раундов ставок и блефа.',
 letitride:'Let It Ride: сразу резервируются три равные ставки. После трёх своих карт можно снять ставку №1. После четвёртой карты можно снять №2. Последняя ставка остаётся до конца. Результат по пятикарточной покерной таблице: от пары десяток до роял-флеша. Снятые ставки возвращаются.',
 rps:'Камень–ножницы–бумага: игрок выбирает жест, компьютер выбирает равновероятно. Победа ×1,94, ничья — возврат ставки, поражение — проигрыш. Только виртуальные фишки.',
 colors:'Три независимых цветных кубика с равными вероятностями красного, синего и зелёного. Ставь на присутствие выбранного цвета хотя бы один раз ×1,38, ровно два раза ×4,35 или все три ×26. Выплаты демонстрационные.'
};
const MORE_RUNTIME={andar:null,reddog:null,pick3:null,bingo90:null,keno80:null,cardsuit:null,ladder:null,slots5:null,holdem:null,letitride:null,rps:null,colors:null};
Object.assign(rt,MORE_RUNTIME);
const beforeMoreReset=resetRuntime;
resetRuntime=function(){beforeMoreReset();Object.assign(rt,MORE_RUNTIME)};
Object.assign(state,{andarSide:'andar',pick3Digits:[1,2,3],pick3Style:'exact',keno80Picks:[],cardsuitBet:'red',ladderChoice:'red',rpsChoice:'rock',colorsChoice:'red',colorsCount:'any'});
function moreResult(r){return resultNote(r?.notice||'',r?.payout>r?.stake?'win':r?.payout===0?'lose':'')}
const choose=(items,action,selected)=>extraOptions(items.map(x=>[x[0],x[1],x[2]||'']),action,selected);
function morePlay(id,fn){const stake=state.stake;if(!spend(stake))return;let r;try{r=fn(stake)}catch(e){refund(stake);throw e}rt[id]=r;settle(MORE_GAMES.find(g=>g.id===id).name,stake,r.payout,r.detail||r.notice||'');render()}
// ANDAR BAHAR: the central card is removed, all subsequent cards drawn without replacement.
function andarRound(side){const deck=newDeck(1),middle=draw(deck),rank=middle.rank;let winner='',reveal=[],position=0;while(deck.length){const card=draw(deck),s=position++%2===0?'andar':'bahar';reveal.push({card,side:s});if(card.rank===rank){winner=s;break}}return{middle,winner,reveal,payoutSide:side}}
function andarHTML(){const r=rt.andar;return extraPanel('🂱 ANDAR BAHAR',`<div class="center-message">Центральная карта</div><div class="poker-cards">${r?cardHTML(r.middle):'<b>?</b>'}</div><div class="dice-details"><div>ANDAR<b>${r?.reveal.filter(x=>x.side==='andar').length||0}</b></div><div>BAHAR<b>${r?.reveal.filter(x=>x.side==='bahar').length||0}</b></div></div>${choose([['andar','ANDAR','×1,90'],['bahar','BAHAR','×2,00']],'andar-side',state.andarSide)}${moreResult(r)}`,'РАЗДАТЬ КАРТЫ','andar-play')}
function playAndar(){const side=state.andarSide;morePlay('andar',stake=>{const r=andarRound(side),payout=r.winner===side?extraPayout(stake,side==='andar'?1.9:2):0;return{...r,stake,payout,notice:`Победила сторона ${r.winner.toUpperCase()} · выплата ${money(payout)}`}})}
// RED DOG: A low, K high. No middle ranks -> push.
function redDogMultiplier(a,b,third){const v=c=>RANKS.indexOf(c.rank)+1,x=v(a),y=v(b),n=v(third),between=Math.abs(x-y)-1;if(between<1)return 1;if(n<=Math.min(x,y)||n>=Math.max(x,y))return 0;return between===1?6:between===2?5:between===3?3:2}
function reddogHTML(){const r=rt.reddog;return extraPanel('🂡 RED DOG',`<div class="poker-cards">${r?r.cards.map(c=>cardHTML(c)).join(''):'<div class="center-message">Угадай третью карту между двумя другими</div>'}</div><p class="tiny">Разрыв между картами определяет выплату; при отсутствии промежутка ставка возвращается.</p>${moreResult(r)}`,'РАЗДАТЬ ТРИ КАРТЫ','reddog-play')}
function playRedDog(){morePlay('reddog',stake=>{const deck=newDeck(1),cards=[draw(deck),draw(deck),draw(deck)],mult=redDogMultiplier(...cards),payout=extraPayout(stake,mult);return{cards,stake,payout,notice:mult===1?'Нет промежутка — возврат ставки':mult?`Попадание! ×${mult}`:'Третья карта вне диапазона'}})}
// PICK 3, with independent replacement of digits.
function permutationCount(ds){const freq=new Map();ds.forEach(d=>freq.set(d,(freq.get(d)||0)+1));return 6/[...freq.values()].reduce((a,c)=>a*(c===3?6:c===2?2:1),1)}
function pick3Payout(picks,actual,style,stake){const won=style==='exact'?picks.every((x,i)=>x===actual[i]):[...picks].sort().join('')===[...actual].sort().join('');return won?extraPayout(stake,style==='exact'?900:900/permutationCount(picks)):0}
function pick3HTML(){const r=rt.pick3,digits=state.pick3Digits;return extraPanel('③ PICK 3',`<div class="dice-three">${r?r.digits.map(d=>`<span class="die-face">${d}</span>`).join(''):'<span class="center-message">Выбери три цифры от 0 до 9</span>'}</div><div class="pick3-inputs">${digits.map((n,i)=>`<div><span class="panel-label">ЦИФРА ${i+1}</span><div class="pick3-step"><button class="btn" data-action="pick3-step" data-index="${i}" data-delta="-1">−</button><b>${n}</b><button class="btn" data-action="pick3-step" data-index="${i}" data-delta="1">+</button></div></div>`).join('')}</div>${choose([['exact','Точный порядок','×900'],['box','Любой порядок',`×${900/permutationCount(digits)}`]],'pick3-style',state.pick3Style)}${moreResult(r)}`,'РОЗЫГРЫШ','pick3-play')}
function playPick3(){const picks=state.pick3Digits.slice(),style=state.pick3Style;morePlay('pick3',stake=>{const digits=Array.from({length:3},()=>rnd(10)),payout=pick3Payout(picks,digits,style,stake);return{digits,stake,payout,notice:`Выпало ${digits.join('')} · твой выбор ${picks.join('')} · ${payout?'ПОБЕДА':'проигрыш'}`}})}
// BINGO 90 proper column ranges, 3x9 grid, exactly five cells per row, no duplicates.
function bingo90Ticket(){for(let trial=0;trial<100;trial++){const occupancy=Array.from({length:3},()=>Array(9).fill(false)),remain=[5,5,5];for(let col=0;col<9;col++){const row=rnd(3);occupancy[row][col]=true;remain[row]--}let valid=true;while(remain.some(x=>x>0)){const opts=[];for(let r=0;r<3;r++)if(remain[r]>0)for(let c=0;c<9;c++)if(!occupancy[r][c])opts.push([r,c]);if(!opts.length){valid=false;break}const [r,c]=opts[rnd(opts.length)];occupancy[r][c]=true;remain[r]--}if(!valid||remain.some(x=>x!==0))continue;const board=occupancy.map(x=>x.map(y=>y?0:null));for(let col=0;col<9;col++){const start=col===0?1:col*10,end=col===8?90:col*10+9,used=[],rows=[];for(let row=0;row<3;row++)if(occupancy[row][col])rows.push(row);const pool=Array.from({length:end-start+1},(_,i)=>start+i);for(const row of rows)used.push(pool.splice(rnd(pool.length),1)[0]);used.sort((a,b)=>a-b).forEach((num,i)=>board[rows[i]][col]=num)}return board}throw Error('Не удалось создать билет')}
function bingo90Lines(board,drawn){const s=new Set(drawn);return board.filter(row=>row.filter(x=>x!==null).every(x=>s.has(x))).length}
function bingo90HTML(){const r=rt.bingo90,board=r?.board;const cells=board?board.flat().map(n=>`<span class="b90-cell ${r.drawn.includes(n)?'matched':''}">${n===null?'·':n}</span>`).join(''):Array.from({length:27},()=>'<span class="b90-cell">·</span>').join('');return extraPanel('▥ BINGO 90',`<div class="b90-grid">${cells}</div><div class="center-message">${r?`Выполнено линий: ${r.lines}/3 (вынуто ${r.drawn.length} шаров)`: '3 ряда × 9 столбцов · 15 чисел на билете'}</div><div class="tiny">Демо-розыгрыш: 45 из 90 · 1 / 2 / 3 линии ×11 / ×50 / ×600.</div>${moreResult(r)}`,'ИГРАТЬ В БИНГО','bingo90-play')}
function playBingo90(){morePlay('bingo90',stake=>{const board=bingo90Ticket(),drawn=uniqueDraw(90,45),lines=bingo90Lines(board,drawn),payout=extraPayout(stake,[0,11,50,600][lines]);return{board,drawn,lines,stake,payout,notice:lines?`Линий: ${lines} · выплата ${money(payout)}`:'Готовых линий нет'}})}
// KENO 6/80: independent without replacement.
const KENO80_PAY=[0,0,0,3,11,45,650];
function keno80HTML(){const r=rt.keno80,picks=state.keno80Picks,drawn=new Set(r?.drawn||[]);return extraPanel('✥ KENO 80',`<div class="keno-count">Выбрано <b>${picks.length}/6</b> · нарисуй 20 из 80</div><div class="k80-grid">${Array.from({length:80},(_,i)=>`<button class="keno-num ${picks.includes(i+1)?'selected':''} ${drawn.has(i+1)?'drawn':''} ${picks.includes(i+1)&&drawn.has(i+1)?'matched':''}" data-action="keno80-pick" data-value="${i+1}">${i+1}</button>`).join('')}</div><div class="keno-paytable">${[3,4,5,6].map(i=>`<span>${i} совпадения <b>×${KENO80_PAY[i]}</b></span>`).join('')}</div>${moreResult(r)}`,'РОЗЫГРЫШ КЕНО','keno80-play',picks.length!==6)}
function keno80Pick(num){if(!Number.isInteger(num)||num<1||num>80)return;const picks=state.keno80Picks,index=picks.indexOf(num);if(index!==-1)picks.splice(index,1);else if(picks.length<6)picks.push(num);render()}
function playKeno80(){const picks=state.keno80Picks;if(picks.length!==6||new Set(picks).size!==6)return;morePlay('keno80',stake=>{const drawn=uniqueDraw(80,20),hits=picks.filter(x=>drawn.includes(x)).length,payout=extraPayout(stake,KENO80_PAY[hits]);return{drawn,hits,stake,payout,notice:`Совпадений: ${hits} · выплата ${money(payout)}`}})}
// SINGLE CARD side bets.
const CARD_PICKS=[['red','Красная','×1,94'],['black','Чёрная','×1,94'],['spades','♠ Пики','×3,88'],['hearts','♥ Червы','×3,88'],['diamonds','♦ Бубны','×3,88'],['clubs','♣ Трефы','×3,88'],['ace','Туз','×12,60'],['face','Картинка J/Q/K','×4,20']];
function cardsuitWin(card,pick){return {red:['♥','♦'].includes(card.suit),black:['♠','♣'].includes(card.suit),spades:card.suit==='♠',hearts:card.suit==='♥',diamonds:card.suit==='♦',clubs:card.suit==='♣',ace:card.rank==='A',face:['J','Q','K'].includes(card.rank)}[pick]||false}
function cardsuitMult(pick){return ['red','black'].includes(pick)?1.94:['spades','hearts','diamonds','clubs'].includes(pick)?3.88:pick==='ace'?12.6:pick==='face'?4.2:0}
function cardsuitHTML(){const r=rt.cardsuit;return extraPanel('♢ КАРТА СУДЬБЫ',`<div class="poker-cards">${r?cardHTML(r.card):'<span class="center-message">Одна колода · 52 карты</span>'}</div>${choose(CARD_PICKS,'cardsuit-pick',state.cardsuitBet)}${moreResult(r)}`,'ВЫТЯНУТЬ КАРТУ','cardsuit-play')}
function playCardsuit(){const pick=state.cardsuitBet;if(!cardsuitMult(pick))return;morePlay('cardsuit',stake=>{const card=draw(newDeck(1)),win=cardsuitWin(card,pick),payout=win?extraPayout(stake,cardsuitMult(pick)):0;return{card,stake,payout,notice:win?'Верное предсказание!':'Ставка не сыграла'}})}
// DOUBLE LADDER: stand-alone continuous draw and optional cashout.
function ladderMultiplier(steps){return Math.pow(1.94,steps)}
function ladderHTML(){const r=rt.ladder,active=!!r?.active;return extraPanel('↑ DOUBLE LADDER',`<div class="center-message">Ступень: ${r?.steps||0} / 8</div><div class="poker-cards">${r?.last?cardHTML(r.last):'<span>Угадай цвет следующей карты</span>'}</div><div class="dice-details"><div>МНОЖИТЕЛЬ<b>×${ladderMultiplier(r?.steps||0).toFixed(2)}</b></div><div>ПОТЕНЦИАЛЬНАЯ ВЫПЛАТА<b>${money(active?extraPayout(r.stake,ladderMultiplier(r.steps)):0)}</b></div></div>${choose([['red','КРАСНАЯ','♥ ♦'],['black','ЧЁРНАЯ','♠ ♣']],'ladder-pick',state.ladderChoice)}${moreResult(r)}${active?`<button class="btn gold block" data-action="ladder-cash" ${!r.steps?'disabled':''}>ЗАБРАТЬ ${money(extraPayout(r.stake,ladderMultiplier(r.steps)))}</button>`:''}`,active?'ОТКРЫТЬ СЛЕДУЮЩУЮ КАРТУ':'НАЧАТЬ ЛЕСТНИЦУ',active?'ladder-next':'ladder-start')}
function ladderStart(){if(rt.ladder?.active||!spend(state.stake))return;rt.ladder={active:true,steps:0,stake:state.stake,last:null,notice:'Угадай красный или чёрный'};render()}
function ladderNext(){const r=rt.ladder;if(!r?.active||r.steps>=8)return;const card=hiloCard(),isRed=['♥','♦'].includes(card.suit),correct=(isRed?'red':'black')===state.ladderChoice;r.last=card;if(correct){r.steps++;r.notice=`Угадал! Ступень ${r.steps}`;if(r.steps===8){ladderCash(true);return}}else{r.active=false;r.notice='Ошибка · ставка проиграна';r.payout=0;settle('Double Ladder',r.stake,0,r.notice)}render()}
function ladderCash(auto=false){const r=rt.ladder;if(!r?.active||r.steps<1)return;r.active=false;r.payout=extraPayout(r.stake,ladderMultiplier(r.steps));r.notice=auto?'Пройдено 8 ступеней!':'Выплата получена';settle('Double Ladder',r.stake,r.payout,`Ступеней ${r.steps}`);render()}
// 5-reel, 3-row slots, ten distinct fixed paylines and left-to-right matches.
const SLOT5_LINES=[[0,0,0,0,0],[1,1,1,1,1],[2,2,2,2,2],[0,1,2,1,0],[2,1,0,1,2],[0,0,1,2,2],[2,2,1,0,0],[1,0,0,0,1],[1,2,2,2,1],[0,1,1,1,0]];
function slots5Evaluate(reels){let total=0,wins=[];for(let line=0;line<SLOT5_LINES.length;line++){const pat=SLOT5_LINES[line],first=reels[0][pat[0]];let count=1;for(let col=1;col<5;col++){if(reels[col][pat[col]]!==first)break;count++}const mult=count===3?15:count===4?40:count===5?500:0;if(mult){total+=mult;wins.push({line,count,symbol:first,mult})}}return{total,wins}}
function slots5HTML(){const r=rt.slots5,reels=r?.reels||Array.from({length:5},()=>['🍒','🍋','💎']);return extraPanel('▤ СЛОТЫ · 5×3',`<div class="slots5-board">${reels.map(reel=>`<div class="slots5-reel">${reel.map(s=>`<span>${s}</span>`).join('')}</div>`).join('')}</div><div class="center-message">10 линий · 3 совпадения ×15 · 4 ×40 · 5 ×500</div>${r?`<div class="tiny">Выигрышных линий: ${r.wins.length} · ${r.wins.map(x=>'№'+(x.line+1)).join(', ')||'нет'}</div>`:''}${moreResult(r)}`,'КРУТИТЬ 5 БАРАБАНОВ','slots5-spin')}
function playSlots5(){morePlay('slots5',stake=>{const reels=Array.from({length:5},()=>Array.from({length:3},()=>SYMS[rnd(SYMS.length)])),{total,wins}=slots5Evaluate(reels),payout=extraPayout(stake,total/10);return{reels,wins,stake,payout,notice:wins.length?`Выигрышных линий: ${wins.length}`:'Без совпадений'}})}
// HOLDEM: evaluate all 21 five-card groups from seven cards, compare ranked vectors lexicographically.
function pokerFiveScore(hand){if(hand.length!==5)throw Error('Five cards required');const values=hand.map(c=>c.rank==='A'?14:RANKS.indexOf(c.rank)+1).sort((a,b)=>b-a),freq={};for(const v of values)freq[v]=(freq[v]||0)+1;const groups=Object.entries(freq).map(([k,v])=>[Number(k),v]).sort((a,b)=>b[1]-a[1]||b[0]-a[0]);const unique=[...new Set(values)],straightTop=unique.includes(14)&&[5,4,3,2].every(x=>unique.includes(x))?5:unique.length===5&&unique[0]-unique[4]===4?unique[0]:0,flush=hand.every(c=>c.suit===hand[0].suit);if(flush&&straightTop)return [8,straightTop];if(groups[0][1]===4)return [7,groups[0][0],groups[1][0]];if(groups[0][1]===3&&groups[1][1]===2)return[6,groups[0][0],groups[1][0]];if(flush)return[5,...values];if(straightTop)return[4,straightTop];if(groups[0][1]===3)return[3,groups[0][0],...groups.slice(1).map(g=>g[0]).sort((a,b)=>b-a)];if(groups[0][1]===2&&groups[1][1]===2)return[2,Math.max(groups[0][0],groups[1][0]),Math.min(groups[0][0],groups[1][0]),groups[2][0]];if(groups[0][1]===2)return[1,groups[0][0],...groups.slice(1).map(g=>g[0]).sort((a,b)=>b-a)];return[0,...values]}
function comparePokerScores(a,b){for(let i=0;i<Math.max(a.length,b.length);i++){if((a[i]||0)!==(b[i]||0))return Math.sign((a[i]||0)-(b[i]||0))}return 0}
function bestSeven(cards){if(cards.length!==7)throw Error('Seven cards required');let score=null;for(let a=0;a<3;a++)for(let b=a+1;b<4;b++)for(let c=b+1;c<5;c++)for(let d=c+1;d<6;d++)for(let e=d+1;e<7;e++){const s=pokerFiveScore([cards[a],cards[b],cards[c],cards[d],cards[e]]);if(score===null||comparePokerScores(s,score)>0)score=s}return score}
const POKER_NAMES=['Старшая карта','Пара','Две пары','Тройка','Стрит','Флеш','Фулл-хаус','Каре','Стрит-флеш'];
function holdemHTML(){const r=rt.holdem;return extraPanel('♠ TEXAS HOLD’EM · ДУЭЛЬ',`<div class="panel-label">ОБЩИЙ СТОЛ</div><div class="poker-cards">${r?r.board.map(c=>cardHTML(c)).join(''):'5 общих карт'}</div><div class="panel-label">ТВОЯ РУКА</div><div class="poker-cards">${r?r.player.map(c=>cardHTML(c)).join(''):'2 карты'}</div><div class="panel-label"><span class="npc-dealer">♛</span> ВИРТУАЛЬНЫЙ СОПЕРНИК · ДИЛЕР</div><div class="poker-cards">${r?r.dealer.map(c=>cardHTML(c)).join(''):'2 карты'}</div>${r?`<div class="dice-details"><div>ТВОЯ КОМБИНАЦИЯ<b>${POKER_NAMES[r.playerScore[0]]}</b></div><div>ДИЛЕР<b>${POKER_NAMES[r.dealerScore[0]]}</b></div></div>`:''}${moreResult(r)}`,'РАЗДАТЬ ХОЛДЕМ','holdem-play')}
function playHoldem(){morePlay('holdem',stake=>{const deck=newDeck(1),player=[draw(deck),draw(deck)],dealer=[draw(deck),draw(deck)],board=Array.from({length:5},()=>draw(deck)),playerScore=bestSeven([...player,...board]),dealerScore=bestSeven([...dealer,...board]),cmp=comparePokerScores(playerScore,dealerScore),payout=cmp>0?extraPayout(stake,1.95):cmp===0?stake:0;return{player,dealer,board,playerScore,dealerScore,stake,payout,notice:cmp>0?'Твоя рука сильнее!':cmp===0?'Ничья · ставка возвращена':'Дилер победил'}})}
// LET IT RIDE with independently refundable 1st and 2nd stakes, one mandatory stake.
function letItRideMult(cards){const score=pokerFiveScore(cards),c=score[0];return c===8?score[1]===14?1001:201:c===7?51:c===6?12:c===5?9:c===4?6:c===3?4:c===2?3:c===1&&score[1]>=10?2:0}
function letItRideHTML(){const r=rt.letitride;let cards=r?[...r.player,...r.board.slice(0,r.phase===1?0:r.phase===2?1:2)]:[];return extraPanel('♥ LET IT RIDE',`<div class="poker-cards">${cards.length?cards.map(c=>cardHTML(c)).join(''):'Три ставки одинакового размера, три карты игрока'}</div><div class="center-message">${r?.notice||'Сначала три карты, потом две общие по одной'}</div>${r?.active?`<div class="dice-details"><div>СТАВОК В ИГРЕ<b>${r.bets} / 3</b></div><div>РАСКРЫТИЕ<b>${r.phase} / 3</b></div></div><div class="button-row"><button class="btn" data-action="letitride-pull">${r.phase===1?'ЗАБРАТЬ СТАВКУ №1':'ЗАБРАТЬ СТАВКУ №2'}</button><button class="btn gold" data-action="letitride-ride">ОСТАВИТЬ СТАВКУ</button></div>`:''}${moreResult(r)}`,r?.active?'РАУНД В ПРОЦЕССЕ':'НОВАЯ РАЗДАЧА',r?.active?'no-action':'letitride-start',!!r?.active)}
function letItRideStart(){if(rt.letitride?.active)return;const s=state.stake;if(!Number.isSafeInteger(s)||s*3>state.balance){toast('Для Let It Ride нужны три одинаковые ставки. Уменьши сумму.',true);return}if(!spendGrouped(s,3))return;const deck=newDeck(1);rt.letitride={active:true,stake:s,bets:3,phase:1,player:Array.from({length:3},()=>draw(deck)),board:[draw(deck),draw(deck)],notice:'Забрать первую ставку или оставить?'};render()}
function letItRideNext(pull){const r=rt.letitride;if(!r?.active)return;if(pull){if(!refund(r.stake))return;r.bets--}if(r.phase===1){r.phase=2;r.notice='Открыта четвёртая карта. Забрать вторую ставку или оставить?';render();return}r.phase=3;r.active=false;const mult=letItRideMult([...r.player,...r.board]);const stake=r.stake*r.bets,payout=extraPayout(stake,mult);r.payout=payout;r.notice=mult?`Комбинация: ${POKER_NAMES[pokerFiveScore([...r.player,...r.board])[0]]}, ×${mult}`:'Нет оплачиваемой комбинации';settle('Let It Ride',stake,payout,`${r.bets} ставки остались`);render()}
// ROCK-PAPER-SCISSORS with push for same gesture.
const RPS_CHOICES=[['rock','✊ Камень',''],['paper','✋ Бумага',''],['scissors','✌ Ножницы','']];
function rpsWinner(a,b){if(a===b)return 0;return (a==='rock'&&b==='scissors')||(a==='paper'&&b==='rock')||(a==='scissors'&&b==='paper')?1:-1}
function rpsHTML(){const r=rt.rps;return extraPanel('✊ КАМЕНЬ · НОЖНИЦЫ · БУМАГА',`<div class="center-message">${r?`Компьютер: ${RPS_CHOICES.find(x=>x[0]===r.opponent)[1]}`:'Победа ×1,94 · ничья возвращает ставку'}</div>${choose(RPS_CHOICES,'rps-pick',state.rpsChoice)}${moreResult(r)}`,'СЫГРАТЬ ДУЭЛЬ','rps-play')}
function playRps(){const pick=state.rpsChoice;if(!RPS_CHOICES.some(x=>x[0]===pick))return;morePlay('rps',stake=>{const opponent=RPS_CHOICES[rnd(3)][0],out=rpsWinner(pick,opponent),payout=out===1?extraPayout(stake,1.94):out===0?stake:0;return{opponent,stake,payout,notice:out===1?'Ты победил!':out===0?'Ничья · возврат ставки':'Победил компьютер'}})}
// COLOUR DICE, exact binomial probabilities 19/27, 6/27, 1/27.
const COLORS=['red','blue','green'],COLOR_ICONS={red:'🔴',blue:'🔵',green:'🟢'},COLOR_MULT={any:1.38,two:4.35,three:26};
function colorDiceWin(dice,color,kind){const hits=dice.filter(x=>x===color).length;return kind==='any'?hits>=1:kind==='two'?hits===2:kind==='three'?hits===3:false}
function colorDiceHTML(){const r=rt.colors;return extraPanel('◉ COLOR DICE',`<div class="dice-three">${(r?.dice||['red','blue','green']).map(c=>`<span class="die-face">${COLOR_ICONS[c]}</span>`).join('')}</div>${choose(COLORS.map(c=>[c,COLOR_ICONS[c]+' '+({red:'КРАСНЫЙ',blue:'СИНИЙ',green:'ЗЕЛЁНЫЙ'}[c]),'']),'colors-choice',state.colorsChoice)}${choose([['any','Хотя бы один','×1,38'],['two','Ровно два','×4,35'],['three','Все три','×26']],'colors-count',state.colorsCount)}${moreResult(r)}`,'БРОСИТЬ ЦВЕТНЫЕ КУБИКИ','colors-play')}
function playColorDice(){const color=state.colorsChoice,kind=state.colorsCount;if(!COLORS.includes(color)||!COLOR_MULT[kind])return;morePlay('colors',stake=>{const dice=Array.from({length:3},()=>COLORS[rnd(3)]),won=colorDiceWin(dice,color,kind),payout=won?extraPayout(stake,COLOR_MULT[kind]):0;return{dice,stake,payout,notice:won?'Цветная ставка выиграла!':'Цветная ставка проиграла'}})}
const MORE_HTML={andar:andarHTML,reddog:reddogHTML,pick3:pick3HTML,bingo90:bingo90HTML,keno80:keno80HTML,cardsuit:cardsuitHTML,ladder:ladderHTML,slots5:slots5HTML,holdem:holdemHTML,letitride:letItRideHTML,rps:rpsHTML,colors:colorDiceHTML};
const oldGameHTML=gameHTML;
gameHTML=function(){return MORE_HTML[state.game]?MORE_HTML[state.game]():oldGameHTML()};
function moreHandleAction(button){const a=button.dataset.action,v=button.dataset.value;
 switch(a){
 case'andar-side':if(['andar','bahar'].includes(v))state.andarSide=v;break;case'andar-play':playAndar();return true;
 case'reddog-play':playRedDog();return true;
 case'pick3-step':{const i=Number(button.dataset.index),d=Number(button.dataset.delta);if(Number.isInteger(i)&&i>=0&&i<3&&[-1,1].includes(d))state.pick3Digits[i]=(state.pick3Digits[i]+d+10)%10;break}case'pick3-style':if(['exact','box'].includes(v))state.pick3Style=v;break;case'pick3-play':playPick3();return true;
 case'bingo90-play':playBingo90();return true;
 case'keno80-pick':keno80Pick(Number(v));return true;case'keno80-play':playKeno80();return true;
 case'cardsuit-pick':if(CARD_PICKS.some(x=>x[0]===v))state.cardsuitBet=v;break;case'cardsuit-play':playCardsuit();return true;
 case'ladder-pick':if(['red','black'].includes(v))state.ladderChoice=v;break;case'ladder-start':ladderStart();return true;case'ladder-next':ladderNext();return true;case'ladder-cash':ladderCash();return true;
 case'slots5-spin':playSlots5();return true;case'holdem-play':playHoldem();return true;
 case'letitride-start':letItRideStart();return true;case'letitride-pull':letItRideNext(true);return true;case'letitride-ride':letItRideNext(false);return true;
 case'rps-pick':if(RPS_CHOICES.some(x=>x[0]===v))state.rpsChoice=v;break;case'rps-play':playRps();return true;
 case'colors-choice':if(COLORS.includes(v))state.colorsChoice=v;break;case'colors-count':if(COLOR_MULT[v])state.colorsCount=v;break;case'colors-play':playColorDice();return true;
 default:return false;
 }
 render();return true
}
const oldHandleAction=handleAction;
handleAction=function(button){if(!moreHandleAction(button))oldHandleAction(button)};

// Navigation search is deliberately UI-only: it never alters the complete game list.
function syncGameSearch(){
 if(typeof document.querySelectorAll!=='function')return;
 const q=(document.getElementById('gameSearch')?.value||'').toLocaleLowerCase('ru').trim();
 let shown=0;
 document.querySelectorAll('#gameNav .nav-entry').forEach(row=>{
  const button=row.querySelector('.nav-item');
  const matches=Boolean(button)&&(!q||button.textContent.toLocaleLowerCase('ru').includes(q))&&(!favoritesOnly||favoriteGames.has(button.dataset.game));
  row.hidden=!matches;
  if(matches)shown++;
 });
 const count=document.getElementById('favoritesCount');if(count)count.textContent=String(favoriteGames.size);
 const filter=document.getElementById('favoritesFilter');if(filter){filter.setAttribute('aria-pressed',String(favoritesOnly));filter.classList.toggle('active',favoritesOnly)}
 const empty=document.getElementById('sidebarEmpty');if(empty){empty.style.display=shown?'none':'block';empty.textContent=favoritesOnly&&favoriteGames.size===0?'Добавь игру в избранное, нажав ☆':'Игры не найдены'}
 const recent=document.getElementById('recentGames');if(recent)recent.hidden=Boolean(q||favoritesOnly||recentGames.length===0);
}
if(typeof document.getElementById('gameSearch')?.addEventListener==='function')document.getElementById('gameSearch').addEventListener('input',syncGameSearch);

render();
// Debug/test facade deliberately read-only: no hooks to change payouts or randomness.
window.NEON_INFO=Object.freeze({version:'1.8.9',gameCount:GAMES.length,games:GAMES.map(g=>g.name),offline:true,virtualOnly:true});
// The portable desktop launcher runs a loopback-only server and exits after 5 minutes idle.
if(typeof location!=='undefined'&&location.hostname==='127.0.0.1'&&Number(location.port)>=17877&&Number(location.port)<=17888){
 const neonKeepalive=()=>fetch('/__ping',{method:'GET',cache:'no-store'}).catch(()=>{});
 neonKeepalive();setInterval(neonKeepalive,20000);
}
// NEON ROYALE 1.7: self-contained tables; returned stake is INCLUDED in payout.
const V17_GAMES = [
 {id:'caribbean',icon:'♠',name:'Caribbean Stud',title:'Caribbean Stud Poker',sub:'Пятикарточный покер · Ante / Fold / Call ×2'},
 {id:'teenpatti',icon:'🂡',name:'Teen Patti',title:'Teen Patti · Казино',sub:'Три карты · Ante / Play / Fold / Pair Plus'},
 {id:'fantan',icon:'✺',name:'Fan Tan',title:'Fan Tan · Отсчёт четырёх',sub:'Фан, Квок, Ним, тройной охват · выбирай ставки'},
 {id:'crown',icon:'⚓',name:'Crown & Anchor',title:'Crown & Anchor',sub:'Три кубика · шесть символов · выплаты за совпадения'}
];
GAMES.push(...V17_GAMES);
MORE_GAMES.push(...V17_GAMES);
const V17_RULES={
 caribbean:'Caribbean Stud: ставь Ante, затем изучи пять карт и открытую карту дилера. Fold теряет Ante. Call требует дополнительно 2× Ante. Дилер квалифицируется с A-K-high или лучше; иначе Ante выигрывает 1:1, Call возвращается. При победе Ante 1:1, Call по таблице: старшая карта/пара 1:1, две пары 2:1, тройка 3:1, стрит 4:1, флеш 5:1, фулл-хаус 7:1, каре 20:1, стрит-флеш 50:1, роял-флеш 100:1. Максимальный Ante 500 000 фишек.',
 teenpatti:'Teen Patti: Ante, по желанию дополнительная Pair Plus (в размере Ante). После трёх карт выбери Fold или Play (дополнительная ставка 1× Ante). Дилер квалифицируется с дамой или сильнее. В противном случае Ante выигрывает 1:1, Play возвращается. При квалификации победа оплачивается 1:1 по каждой ставке, ничья — возврат. Ante Bonus за стрит (1:1), тройку (4:1), стрит-флеш (5:1) начисляется при Play. Pair Plus оплачивается независимо от Fold по таблице.',
 fantan:'Fan Tan: из кучки отсчитывают по четыре, результат 1–4 равновероятен. Fan: одно число, выигрыш 2,85:1. Kwok: два соседних числа, 0,95:1. Nim: одно выигрышное число (1,9:1) и одно число возврата ставки. Тройной охват: три числа (19:60 к 1). Все коэффициенты после условной комиссии 5%.',
 crown:'Crown & Anchor: три независимых кубика имеют по шесть равновероятных символов. Выбери один символ. Если он появился один раз — выигрыш 1:1, два — 2:1, три — 3:1; во всех случаях возвращается исходная ставка. Если совпадений нет, ставка проиграна.'
};
Object.assign(MORE_RULES,V17_RULES);
const V17_RUNTIME={caribbean:null,teenpatti:null,fantan:null,crown:null};
Object.assign(rt,V17_RUNTIME);
const v17Reset=resetRuntime;
resetRuntime=function(){v17Reset();Object.assign(rt,V17_RUNTIME)};
Object.assign(state,{teenPairPlus:false,fantanBet:'fan:1',crownBet:0});

function qualifiedCaribbean(cards){const score=pokerFiveScore(cards);return score[0]>0||(score[0]===0&&score[1]===14&&score[2]===13)}
function caribbeanCallOdds(cards){const score=pokerFiveScore(cards);return score[0]===8?(score[1]===14?100:50):({7:20,6:7,5:5,4:4,3:3,2:2,1:1,0:1}[score[0]]||1)}
function caribbeanPayment(ante,player,dealer){const p=pokerFiveScore(player),d=pokerFiveScore(dealer),cmp=comparePokerScores(p,d),call=2*ante;if(!qualifiedCaribbean(dealer))return {payout:4*ante,reason:'Дилер не квалифицировался · Ante 1:1, Call возвращена'};if(cmp<0)return {payout:0,reason:'Дилер победил'};if(cmp===0)return{payout:3*ante,reason:'Ничья · возврат ставок'};const odds=caribbeanCallOdds(player);return {payout:2*ante+(1+odds)*call,reason:`Победа! Ante 1:1, Call ${odds}:1`}}
function caribbeanHTML(){const r=rt.caribbean,active=!!r?.active;const cards=r?.player||[];return `<div class="panel"><div class="panel-header"><h2>♠ CARIBBEAN STUD</h2><span class="status-pill green">ANTE / CALL ×2</span></div><div class="panel-body"><span class="panel-label">ТВОИ ПЯТЬ КАРТ</span><div class="poker-cards">${cards.length?cards.map(c=>cardHTML(c)).join(''):'<span class="center-message">Раздача пяти карт</span>'}</div><span class="panel-label">ДИЛЕР ${active?'· ОДНА КАРТА ОТКРЫТА':''}</span><div class="poker-cards">${r?(active?r.dealer.map((c,i)=>cardHTML(c,i!==0)).join(''):r.dealer.map(c=>cardHTML(c)).join('')):'<span class="center-message">?</span>'}</div>${resultNote(r?.notice||'Ante → открой карты → Call или Fold',r?.payout>r?.stake?'win':'')}</div></div><div style="margin-top:16px">${active?`<div class="panel"><div class="panel-body"><p class="tiny">Call стоит ${money(2*r.stake)} дополнительных фишек. Можно отказаться и потерять только Ante.</p><div class="button-row"><button class="btn primary" data-action="caribbean-call">CALL ×2</button><button class="btn ghost" data-action="caribbean-fold">FOLD</button></div></div></div>`:betPanel('РАЗДАТЬ 5 КАРТ','caribbean-start')}</div>`}
function caribbeanStart(){if(rt.caribbean?.active)return;const stake=state.stake;if(stake>500000){toast('Максимум Ante — 500 000',true);return}if(!spend(stake))return;const deck=newDeck(1),player=Array.from({length:5},()=>draw(deck)),dealer=Array.from({length:5},()=>draw(deck));rt.caribbean={active:true,stake,player,dealer,notice:'Посмотри на карты и выбери Call или Fold'};render()}
function caribbeanFinish(call){const r=rt.caribbean;if(!r?.active)return;if(!call){r.active=false;r.payout=0;r.notice='Fold: Ante проиграна';settle('Caribbean Stud',r.stake,0,'Fold');render();return}if(!spend(2*r.stake))return;const outcome=caribbeanPayment(r.stake,r.player,r.dealer);r.active=false;r.payout=Math.min(BALANCE_CAP,Math.round(outcome.payout));r.notice=outcome.reason;settle('Caribbean Stud',3*r.stake,r.payout,outcome.reason);render()}

// Three-card Teen Patti ranking: mini-royal > three-of-kind > straight flush > straight > flush > pair > high.
function teenScore(cards){if(cards.length!==3)throw Error('Three cards required');const ranks=cards.map(c=>c.rank==='A'?14:RANKS.indexOf(c.rank)+1).sort((a,b)=>b-a);const freq=new Map();ranks.forEach(n=>freq.set(n,(freq.get(n)||0)+1));const groups=[...freq.entries()].sort((a,b)=>b[1]-a[1]||b[0]-a[0]);const flush=cards.every(c=>c.suit===cards[0].suit);const unique=[...new Set(ranks)];const straight=unique.length===3&&(ranks[0]-ranks[2]===2||ranks.join(',')==='14,3,2');const top=straight?(ranks[0]===14&&ranks[1]===3?3:ranks[0]):0;const royal=flush&&ranks.join(',')==='14,13,12';if(royal)return[7,14];if(groups[0][1]===3)return[6,groups[0][0]];if(straight&&flush)return[5,top];if(straight)return[4,top];if(flush)return[3,...ranks];if(groups[0][1]===2)return[2,groups[0][0],groups[1][0]];return[1,...ranks]}
function teenPairPlusProfit(score){return {7:100,6:30,5:40,4:5,3:4,2:1}[score[0]]||0}
function teenAnteBonus(score){return score[0]===7||score[0]===5?5:score[0]===6?4:score[0]===4?1:0}
function teenPayment(ante,player,dealer,pairPlus){const p=teenScore(player),d=teenScore(dealer),cmp=comparePokerScores(p,d),qualifies=d[0]>1||d[1]>=12;const pairPay=pairPlus?(teenPairPlusProfit(p)+ (teenPairPlusProfit(p)>0?1:0))*ante:0;let base,reason;if(!qualifies){base=3*ante;reason='Дилер не квалифицировался · Ante выиграла, Play возвращена'}else if(cmp>0){base=4*ante;reason='Победа над дилером'}else if(cmp===0){base=2*ante;reason='Ничья · ставки возвращены'}else{base=0;reason='Дилер победил'}const bonus=teenAnteBonus(p)*ante;return{payout:base+bonus+pairPay,reason:reason+(bonus?` · Ante Bonus +${money(bonus)}`:'')+(pairPlus?` · Pair Plus: ${money(pairPay)}`:''),qualifies}}
function teenHTML(){const r=rt.teenpatti,active=!!r?.active;return `<div class="panel"><div class="panel-header"><h2>🂡 TEEN PATTI</h2><span class="status-pill green">ANTE + PLAY</span></div><div class="panel-body"><span class="panel-label">ТВОЯ РУКА</span><div class="poker-cards">${r?r.player.map(c=>cardHTML(c)).join(''):'Три карты'}</div><span class="panel-label">ДИЛЕР</span><div class="poker-cards">${r?r.dealer.map(c=>cardHTML(c,active)).join(''):'Три закрытые карты'}</div>${resultNote(r?.notice||'За один Ante раздаётся три карты. Опционально Pair Plus.',r?.payout>r?.stake?'win':'')}</div></div><div style="margin-top:16px">${active?`<div class="panel"><div class="panel-body"><p class="tiny">Play — дополнительная ставка ${money(r.stake)}. Fold теряет Ante, но бонус Pair Plus остаётся.</p><div class="button-row"><button class="btn primary" data-action="teen-play">PLAY ×1</button><button class="btn ghost" data-action="teen-fold">FOLD</button></div></div></div>`:betPanel('РАЗДАТЬ КАРТЫ','teen-start',false,`<button class="mode-choice ${state.teenPairPlus?'active':''}" type="button" data-action="teen-pair" aria-pressed="${state.teenPairPlus}">✦ Pair Plus: ${state.teenPairPlus?'ВКЛ':'ВЫКЛ'} (ещё 1× Ante)</button>`)}</div>`}
function teenStart(){if(rt.teenpatti?.active)return;const s=state.stake,extra=state.teenPairPlus;if(extra&&state.balance<2*s){toast('Для Ante + Pair Plus не хватает фишек',true);return}if(!(extra?spendGrouped(s,2):spend(s)))return;const deck=newDeck(1),player=Array.from({length:3},()=>draw(deck)),dealer=Array.from({length:3},()=>draw(deck));rt.teenpatti={active:true,stake:s,pairPlus:extra,player,dealer,notice:'Выбери Play или Fold'};render()}
function teenFinish(play){const r=rt.teenpatti;if(!r?.active)return;const pairPay=r.pairPlus?(teenPairPlusProfit(teenScore(r.player))+(teenPairPlusProfit(teenScore(r.player))>0?1:0))*r.stake:0;if(!play){r.active=false;r.payout=pairPay;r.notice='Fold: Ante проиграна'+(r.pairPlus?` · Pair Plus ${money(pairPay)}`:'');settle('Teen Patti',r.stake*(1+Number(r.pairPlus)),pairPay,'Fold');render();return}if(!spend(r.stake))return;const outcome=teenPayment(r.stake,r.player,r.dealer,r.pairPlus);r.active=false;r.payout=Math.min(BALANCE_CAP,Math.round(outcome.payout));r.notice=outcome.reason;settle('Teen Patti',r.stake*(2+Number(r.pairPlus)),r.payout,r.notice);render()}

// Fan Tan: remainder of beads when counted in fours (1..4); no external RNG.
const FAN_BETS=[...Array.from({length:4},(_,i)=>[`fan:${i+1}`,`Число ${i+1}`,'2,85:1']),...[[1,2],[2,3],[3,4],[4,1]].map(([a,b])=>[`kwok:${a}:${b}`,`${a} или ${b}`,'0,95:1']),...[[1,2],[2,3],[3,4],[4,1]].map(([a,b])=>[`nim:${a}:${b}`,`Ним ${a} · возврат ${b}`,'1,90:1']),...Array.from({length:4},(_,i)=>[`triple:${i+1}`,`Все кроме ${i+1}`,'19:60'])];
function fanPayment(bet,result,stake){const [kind,a,b]=bet.split(':'),v=Number(a),push=Number(b);if(kind==='fan')return result===v?Math.round(stake*3.85):0;if(kind==='kwok')return (result===v||result===push)?Math.round(stake*1.95):0;if(kind==='nim')return result===v?Math.round(stake*2.9):result===push?stake:0;if(kind==='triple')return result!==v?Math.round(stake*(1+19/60)):0;return 0}
function fanHTML(){const r=rt.fantan;return extraPanel('✺ FAN TAN',`<div class="dice-three"><span class="die-face casino-big-number">${r?.result||'✦'}</span></div><div class="center-message">${r?.notice||'На какое число останется остаток при делении на четыре?'}</div><div class="panel-label">ВАРИАНТЫ СТАВОК · ${FAN_BETS.length}</div><div class="bet-option-grid">${FAN_BETS.map(([id,label,m])=>`<button class="mode-choice ${state.fantanBet===id?'active':''}" data-action="fan-pick" data-value="${id}">${label}<small>${m}</small></button>`).join('')}</div>${moreResult(r)}`,'✺ ОТСЧИТАТЬ','fan-play')}
function fanPlay(){const bet=state.fantanBet;if(!FAN_BETS.some(x=>x[0]===bet))return;morePlay('fantan',stake=>{const result=rnd(4)+1,payout=fanPayment(bet,result,stake);return{result,bet,stake,payout,notice:`Осталось ${result} · ${payout?'выплата '+money(payout):'проигрыш'}`}})}

const CROWN_SYMBOLS=['♛','⚓','★','♥','♦','♣'];
function crownPayment(result,selection,stake){const n=result.filter(v=>v===selection).length;return n?stake*(n+1):0}
function crownHTML(){const r=rt.crown;return extraPanel('⚓ CROWN & ANCHOR',`<div class="dice-three">${(r?.dice||[0,1,2]).map(n=>`<span class="die-face">${CROWN_SYMBOLS[n]}</span>`).join('')}</div><div class="center-message">${r?.notice||'Угадай символ на трёх кубиках'}</div><div class="bet-option-grid">${CROWN_SYMBOLS.map((s,i)=>`<button class="mode-choice ${state.crownBet===i?'active':''}" data-action="crown-pick" data-value="${i}">${s} ${['Корона','Якорь','Звезда','Черви','Бубны','Трефы'][i]}</button>`).join('')}</div>${moreResult(r)}`,'⚓ БРОСИТЬ КУБИКИ','crown-play')}
function crownPlay(){const pick=state.crownBet;if(!Number.isInteger(pick)||pick<0||pick>=6)return;morePlay('crown',stake=>{const dice=Array.from({length:3},()=>rnd(6)),payout=crownPayment(dice,pick,stake);return{dice,stake,payout,notice:`Совпадений: ${dice.filter(x=>x===pick).length} · выплата ${money(payout)}`}})}
const v17GameHTML=gameHTML;
gameHTML=function(){const views={caribbean:caribbeanHTML,teenpatti:teenHTML,fantan:fanHTML,crown:crownHTML};return views[state.game]?views[state.game]():v17GameHTML()};
const v17HandleBefore=handleAction;
handleAction=function(button){const a=button.dataset.action,v=button.dataset.value;
 switch(a){
 case 'caribbean-start':caribbeanStart();return;case 'caribbean-call':caribbeanFinish(true);return;case 'caribbean-fold':caribbeanFinish(false);return;
 case 'teen-pair':if(!rt.teenpatti?.active){state.teenPairPlus=!state.teenPairPlus;render()}return;
 case 'teen-start':teenStart();return;case 'teen-play':teenFinish(true);return;case 'teen-fold':teenFinish(false);return;
 case 'fan-pick':if(FAN_BETS.some(x=>x[0]===v)){state.fantanBet=v;render()}return;case 'fan-play':fanPlay();return;
 case 'crown-pick':if(Number.isInteger(Number(v))&&Number(v)>=0&&Number(v)<6){state.crownBet=Number(v);render()}return;case 'crown-play':crownPlay();return;
 case 'favorite-toggle':toggleFavorite(button.dataset.game);return;
 case 'favorites-filter':favoritesOnly=!favoritesOnly;syncGameSearch();return;
 case 'quality-toggle':qualityMode=qualityMode==='normal'?'lite':'normal';try{localStorage.setItem(QUALITY_STORAGE,qualityMode)}catch(e){}applyQualityMode();return;
 default:v17HandleBefore(button)
 }
};
// Persist only the independent visual preference, never alter game mechanics or RNG.
const COMPACT_STORAGE='neon-casino-compact-v1';
let compactShortcuts=false;
try{compactShortcuts=localStorage.getItem(COMPACT_STORAGE)==='1'}catch(e){}
function applyCompactShortcuts(){
 const area=document.querySelector('.featured-section'),button=document.getElementById('compactToggle');
 if(area)area.classList.toggle('featured-collapsed',compactShortcuts);
 if(button){button.setAttribute('aria-expanded',String(!compactShortcuts));button.textContent=compactShortcuts?'Развернуть':'Свернуть'}
}
if(typeof document.getElementById('compactToggle')?.addEventListener==='function')document.getElementById('compactToggle').addEventListener('click',()=>{
 compactShortcuts=!compactShortcuts;
 try{localStorage.setItem(COMPACT_STORAGE,compactShortcuts?'1':'0')}catch(e){toast('Настройку вида не удалось сохранить',true)}
 applyCompactShortcuts();
});
applyCompactShortcuts();
const QUALITY_STORAGE='neon-casino-quality-v1';
let qualityMode='normal';
try{
 const preference=localStorage.getItem(QUALITY_STORAGE);
 const lessMotion=typeof window!=='undefined'&&typeof window.matchMedia==='function'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const limitedMemory=typeof navigator!=='undefined'&&typeof navigator.deviceMemory==='number'&&navigator.deviceMemory<=2;
 qualityMode=preference==='normal'||preference==='lite'?preference:(lessMotion||limitedMemory?'lite':'normal');
}catch(e){}
function applyQualityMode(){document.documentElement?.classList?.toggle('quality-lite',qualityMode==='lite');const b=document.getElementById('qualityToggle');if(b){b.textContent=qualityMode==='lite'?'⚡ ЭКО':'✧ ПЛАВНО';b.setAttribute('aria-pressed',String(qualityMode==='lite'));b.title='Переключить анимации: плавно / экономно'}}
applyQualityMode();
// Data exposed for QA cannot mutate balances or force a result.
restoreFavorites();restoreRecent();lastRenderedNavigation=null;render();renderRecent();
window.NEON_INFO=Object.freeze({version:'1.8.9',gameCount:GAMES.length,games:GAMES.map(g=>g.name),offline:true,virtualOnly:true});


// Cross-window ownership check on every modifying UI action.
const v171HandleAction=handleAction;
handleAction=function(button){
 const readonlyActions=new Set(['nav','wallet','profile','profile-tab','game-guide','fairness','fairness-test','close-modal','modal-overlay','history','daily-history','day-summary','quality-toggle','favorite-toggle','favorites-filter','roulette-table','roulette-anchor','casino-view','hall-zone','hall-open','hall-favorite','hall-search-clear','replay-round']);
 if(!canModify()&&!readonlyActions.has(button.dataset.action)){leaseBlock();return}
 return v171HandleAction(button)
};
if(typeof window!=='undefined'&&typeof window.addEventListener==='function'){
 window.addEventListener('pagehide',()=>{
  if(!canModify())return;
  try{localStorage.removeItem(INSTANCE_KEY)}catch(e){}
 });
}
// Inactive windows never write the balance. Reload after closing the first one.
if(!instanceWritable){setTimeout(()=>leaseBlock(),100)}
else if(volatileMode){setTimeout(()=>toast('Локальное сохранение недоступно: прогресс останется только до закрытия окна.',true),100)}
else{setInterval(leaseHeartbeat,4000)}