#!/usr/bin/env python3
"""Check iOS version, bundle id, schemes, web resources; no Xcode substitute."""
from pathlib import Path
import plistlib
import re
import hashlib

root = Path(__file__).resolve().parents[1]
proj = root / 'ios/NEONROYALE.xcodeproj/project.pbxproj'
plist = root / 'ios/NEONROYALE/Info.plist'
web = root / 'ios/NEONROYALE/Web'
android_web = root / 'BUILD_READY_ANDROID_PROJECT/web'
mac_web = root / 'BUILD_READY_WINDOWS_LAUNCHER/web'
meta = plistlib.loads(plist.read_bytes())
source = proj.read_text(encoding='utf-8')
version = meta['CFBundleShortVersionString']
build = str(meta['CFBundleVersion'])
assert re.fullmatch(r'\d+\.\d+\.\d+', version)
assert re.fullmatch(r'[1-9]\d*', build)
assert set(re.findall(r'MARKETING_VERSION = ([0-9.]+);', source)) == {version}, 'Xcode marketing version mismatch'
assert set(re.findall(r'CURRENT_PROJECT_VERSION = ([0-9]+);', source)) == {build}, 'Xcode build number mismatch'
assert set(re.findall(r'PRODUCT_BUNDLE_IDENTIFIER = ([^;]+);', source)) == {'com.neon.royale.ios'}
assert (root / 'ios/NEONROYALE.xcodeproj/xcshareddata/xcschemes/NEONROYALE.xcscheme').is_file()
script = (web / 'app.js').read_text(encoding='utf-8')
assert script.count("version:'" + version + "',gameCount:GAMES.length") >= 1, 'Bundled JS version mismatch'
swift = (root / 'ios/NEONROYALE/NeonWebView.swift').read_text(encoding='utf-8')
assert f'NEON_IOS_READY_v{version}_games44' in swift, 'CI readiness tag mismatch'
for name in ('index.html','app.js','app.css','sw.js','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png'):
    checksums=[hashlib.sha256((folder/name).read_bytes()).hexdigest() for folder in (web,android_web,mac_web)]
    assert len(set(checksums)) == 1, f'Platform resource mismatch: {name}'
print(f'PASS: iOS {version} ({build}), 8/8 assets identical, bundle id, scheme and Swift smoke log consistent')
print('NOTE: This is static validation, NOT compilation by Xcode or execution on iPhone.')
