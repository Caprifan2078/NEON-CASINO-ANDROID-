#!/usr/bin/env python3
"""Linux Chromium end-to-end test of the real embedded Go launcher and local wallet.

Unlike static browser tests, this test closes the browser AND native server,
then restarts them using the same browser profile and verifies persistence.
It does not prove behavior on Windows/macOS or a native mobile device.
"""
import asyncio
import os
from pathlib import Path
import subprocess
import tempfile
import time
from urllib.request import urlopen
from playwright.async_api import async_playwright, Error as PlaywrightError

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / 'dist/neon-casino-linux'
BASE = 'http://127.0.0.1:17877'


def server():
    p = subprocess.Popen([str(BIN), '--no-browser'], cwd=ROOT,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
    try:
        for _ in range(50):
            if p.poll() is not None:
                raise AssertionError(f'Launcher exited early: {p.returncode}')
            try:
                with urlopen(BASE + '/__appcheck', timeout=.3) as r:
                    if r.headers.get('X-Neon-Simulator') == '1.8.9':
                        return p
            except OSError:
                time.sleep(.12)
        raise AssertionError('Native launcher not ready')
    except BaseException:
        stop(p)
        raise


def stop(p):
    if p.poll() is None:
        p.terminate()
        try: p.wait(timeout=3)
        except subprocess.TimeoutExpired: p.kill(); p.wait(timeout=3)


async def main():
    if not BIN.is_file():
        raise SystemExit('Build Linux native executable first')
    with tempfile.TemporaryDirectory(prefix='neon-native-browser-') as profile:
        async with async_playwright() as playwright:
            first = server()
            failures = []
            try:
                context = await playwright.chromium.launch_persistent_context(
                    profile, executable_path='/usr/bin/chromium', headless=True,
                    args=['--no-sandbox', '--disable-dev-shm-usage'])
                page = context.pages[0] if context.pages else await context.new_page()
                page.on('pageerror', lambda error: failures.append(str(error)))
                await page.goto(BASE + '/index.html', wait_until='domcontentloaded', timeout=15000)
                await page.wait_for_function('window.NEON_INFO && window.NEON_INFO.gameCount === 44', timeout=15000)
                assert await page.locator('#gameNav [data-action=nav]').count() == 44
                before = await page.evaluate('state.balance')
                await page.locator('[data-action=casino-view][data-value=hall]').first.click()
                assert await page.evaluate("localStorage.getItem('neon-casino-view')") == 'hall'
                assert await page.evaluate('state.balance') == before
                await page.evaluate("localStorage.setItem('__neon_native_s3_probe', 'persist')")
                await context.close()
            finally:
                stop(first)
            # Closing the OS process must not delete or reset the browser profile.
            second = server()
            try:
                context = await playwright.chromium.launch_persistent_context(
                    profile, executable_path='/usr/bin/chromium', headless=True,
                    args=['--no-sandbox', '--disable-dev-shm-usage'])
                page = context.pages[0] if context.pages else await context.new_page()
                page.on('pageerror', lambda error: failures.append(str(error)))
                await page.goto(BASE + '/index.html', wait_until='domcontentloaded', timeout=15000)
                await page.wait_for_function('window.NEON_INFO && window.NEON_INFO.gameCount === 44', timeout=15000)
                assert await page.evaluate('state.balance') == before, 'Virtual wallet did not survive restart'
                assert await page.evaluate("localStorage.getItem('neon-casino-view')") == 'hall', 'Casino view lost after restart'
                assert await page.evaluate("localStorage.getItem('__neon_native_s3_probe')") == 'persist', 'Browser localStorage lost after restart'
                assert not await page.locator('#hallStage').get_attribute('hidden'), 'Casino hall not restored'
                assert not failures, 'Browser JS errors: ' + str(failures)
                print('PASS: real Linux launcher + Chromium 44 games, hall, balance and localStorage survived process/browser restart')
                await context.close()
            finally:
                stop(second)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except PlaywrightError as exc:
        if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(exc):
            raise SystemExit('BLOCKED (NOT PASSED): this Chromium environment prohibits direct localhost browsing; run on a normal desktop to test browser persistence')
        raise
