#!/usr/bin/env python3
"""Run the *actual* native launcher on Linux, macOS or Windows and verify embedded assets.

This checks startup and HTTP delivery, not a graphical browser or OS installer.
"""
import os
import hashlib
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'BUILD_READY_WINDOWS_LAUNCHER' / 'web'
RESOURCES = ('index.html', 'app.js', 'app.css', 'sw.js', 'manifest.webmanifest',
             'icon.svg', 'icon-192.png', 'icon-512.png')
VERSION = '1.8.9'
BASE = 'http://127.0.0.1:17877'

def expected_build_id():
    h = hashlib.sha256()
    for item in RESOURCES:
        data = (ASSETS / item).read_bytes()
        h.update(f'{item}:{len(data)}\n'.encode('utf-8'))
        h.update(data)
    return h.hexdigest()


def get(path, base=BASE, headers=None, timeout=2):
    with urlopen(Request(base + path, headers=headers or {}), timeout=timeout) as reply:
        return reply.status, dict(reply.headers), reply.read()

def check_service(base):
    status, headers, body = get('/__appcheck', base)
    assert status == 200 and headers.get('X-Neon-Simulator') == VERSION, (status, headers)
    assert headers.get('X-Neon-Build') == expected_build_id(), 'A stale or mixed build was served'
    assert body == f'NEON CASINO {VERSION}'.encode(), body
    for item in RESOURCES:
        code, _, received = get('/' + item, base)
        original = (ASSETS / item).read_bytes()
        assert code == 200 and received == original, f'{item}: bad content, got {len(received)} expected {len(original)}'
    assert get('/__ping', base)[0] == 204
    try:
        get('/index.html', base, headers={'Host': 'invalid.example'})
    except HTTPError as ex:
        assert ex.code == 400, f'Host validation returned {ex.code}'
    else:
        raise AssertionError('Unexpectedly accepted an external Host header')

def wait_for_service(base, proc, max_seconds=9):
    until = time.monotonic() + max_seconds
    while time.monotonic() < until:
        if proc.poll() is not None:
            raise AssertionError(f'Native executable exited early: {proc.returncode}')
        try:
            if get('/__appcheck', base, timeout=.4)[0] == 200: return
        except (URLError, TimeoutError, ConnectionError):
            pass
        time.sleep(.12)
    raise AssertionError(f'Native executable did not start on {base}')

def launch_and_check(binary, base=BASE):
    with tempfile.TemporaryFile(mode='w+t', encoding='utf-8') as log:
        proc = subprocess.Popen([str(binary), '--no-browser'], stdout=log, stderr=subprocess.STDOUT,
                                cwd=ROOT, stdin=subprocess.DEVNULL)
        try:
            wait_for_service(base, proc)
            check_service(base)
            assert proc.poll() is None, 'Native launcher exited during requests'
        except Exception:
            log.flush(); log.seek(0)
            print('Launcher log:\n' + log.read(), file=sys.stderr)
            raise
        finally:
            proc.terminate()
            try: proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=4)

def same_version_stale_build_check(binary):
    # Fake a port owner that claims the same version but serves DIFFERENT JS.
    # An old launcher accepted the version header alone and silently opened it.
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    import threading
    class StaleBuild(BaseHTTPRequestHandler):
        def do_GET(self):
            payload = b'NEON CASINO 1.8.9'
            self.send_response(200)
            self.send_header('X-Neon-Simulator', VERSION)
            self.send_header('X-Neon-Build', '0' * 64)
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        def log_message(self, *_args): pass
    old = ThreadingHTTPServer(('127.0.0.1', 17877), StaleBuild)
    worker = threading.Thread(target=old.serve_forever, daemon=True)
    worker.start()
    try:
        launch_and_check(binary, 'http://127.0.0.1:17878')
        print('PASS: same version with stale bundled assets is NOT reused')
    finally:
        old.shutdown()
        old.server_close()
        worker.join(timeout=2)


def hung_port_check(binary):
    import threading
    blocker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    blocker.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    blocker.bind(('127.0.0.1', 17877)); blocker.listen(2)
    done = threading.Event()
    def never_respond():
        try:
            blocker.settimeout(5)
            connection, _ = blocker.accept()
            with connection:
                done.wait(3)
        except (socket.timeout, OSError):
            pass
    thread = threading.Thread(target=never_respond, daemon=True); thread.start()
    try:
        start = time.monotonic()
        launch_and_check(binary, 'http://127.0.0.1:17878')
        elapsed = time.monotonic() - start
        assert elapsed < 7, f'Blocked port stalled launcher startup: {elapsed:.2f}s'
        print(f'PASS: stalled primary port skipped; fallback launched in {elapsed:.2f}s')
    finally:
        done.set(); blocker.close(); thread.join(timeout=1)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: verify_desktop_runtime.py <native binary>')
    binary = Path(sys.argv[1]).resolve()
    assert binary.is_file(), binary
    result = subprocess.run([str(binary), '--version'], check=True, capture_output=True, text=True, timeout=4)
    assert result.stdout.strip() == f'NEON CASINO {VERSION}', result.stdout
    launch_and_check(binary)
    print('PASS: native process served all 8 byte-identical game resources and rejected external Host')
    hung_port_check(binary)
    same_version_stale_build_check(binary)
