"""Static format checks for host binaries, not native execution on Windows/Mac."""
from pathlib import Path
import struct, plistlib, zipfile
root=Path(__file__).resolve().parents[1]
dist=root/'dist'
windows=dist/'NEON_CASINO_WIN64.exe'
b=windows.read_bytes();assert b[:2]==b'MZ'
pe=struct.unpack_from('<I',b,0x3c)[0];assert b[pe:pe+4]==b'PE\0\0';assert struct.unpack_from('<H',b,pe+4)[0]==0x8664
print('PASS Windows EXE: PE x86-64 signature')
linux=dist/'neon-casino-linux'
b=linux.read_bytes();assert b[:5]==b'\x7fELF\x02';assert struct.unpack_from('<H',b,18)[0]==62
print('PASS Linux ELF: x86-64 signature')
for arch,cpu in [('APPLE_SILICON',0x0100000c),('INTEL',0x01000007)]:
 app=dist/f'NEON_CASINO_MAC_{arch}.app';exe=app/'Contents/MacOS/NEONROYALE'
 b=exe.read_bytes();assert b[:4] in (b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf')
 assert struct.unpack_from('<I',b,4)[0]==cpu
 info=plistlib.loads((app/'Contents/Info.plist').read_bytes())
 assert info['CFBundleVersion']=='190' and info['CFBundleShortVersionString']=='1.8.9'
 assert info['CFBundleExecutable']=='NEONROYALE'
 assert (app/'Contents/Resources/AppIcon.icns').read_bytes()[:4]==b'icns'
 print(f'PASS Mac {arch}: Mach-O CPU, bundle metadata and application icon')
for archive in [dist/'NEON_CASINO_v1.8.9_STABLE_MAC_ARM.zip',dist/'NEON_CASINO_v1.8.9_STABLE_MAC_INTEL.zip',dist/'NEON_CASINO_v1.8.9_STABLE_LINUX_x64.zip']:
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
 print('PASS ZIP integrity',archive.name)
print('PASS desktop structural preflight (runtime testing on Windows/Mac still required)')
