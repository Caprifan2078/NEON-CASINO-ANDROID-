"""NEON CASINO v1.8.9 cross-platform preflight. No simulator claims.

Run at the root of the extracted STABILIZATION package.
"""
import plistlib
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
android = root / 'BUILD_READY_ANDROID_PROJECT'
windows = root / 'BUILD_READY_WINDOWS_LAUNCHER'
ios = root / 'ios'
version = '1.8.9'
assets = ['index.html','app.js','app.css','icon.svg','icon-192.png','icon-512.png','manifest.webmanifest','sw.js']

assert (android / 'package.json').exists()
import json
assert json.loads((android / 'package.json').read_text())['version'] == version

sources = {
    'shared source': android / 'web',
    'Android assets': android / 'app/src/main/assets/web',
    'Windows/Linux/macOS embedded assets': windows / 'web',
    'iPhone/iPad Xcode web assets': ios / 'NEONROYALE/Web',
    'alternate iOS source copy': root / 'NEON_ROYALE_IOS_XCODE/NEONROYALE/Web',
}
base = sources['shared source']
for name, folder in sources.items():
    for filename in assets:
        assert (folder / filename).is_file(), f'{name}: missing {filename}'
        assert (folder / filename).read_bytes() == (base / filename).read_bytes(), f'{name}: stale {filename}'
    print('PASS', name, '8/8 assets identical')

for path in [ios, root/'NEON_ROYALE_IOS_XCODE']:
    info = plistlib.loads((path/'NEONROYALE/Info.plist').read_bytes())
    assert info['CFBundleShortVersionString'] == version
    # 190 > previous 188/189 build; supports proper sequential iOS updates.
    assert info['CFBundleVersion'] == '190', info['CFBundleVersion']
    project = (path/'NEONROYALE.xcodeproj/project.pbxproj').read_text()
    assert project.count('CURRENT_PROJECT_VERSION = 190;') == 2
    assert project.count('MARKETING_VERSION = 1.8.9;') == 2
    assert 'com.neon.royale.ios' in project
    print('PASS iOS project version/build consistency:', path.name)

manifest = (android/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' not in manifest
buildgradle = (android/'app/build.gradle').read_text()
assert re.search(r'versionCode\s+190\b', buildgradle)
assert re.search(r"versionName\s+'1\.8\.9'", buildgradle)
assert 'NEON_QA_KEYSTORE_PATH' in buildgradle
print('PASS Android offline manifest + version + optional stable signing')

html_file = root/'OFFLINE_v1.8.9.html'
html = html_file.read_text()
assert (base/'app.js').read_text() in html, 'Offline HTML contains stale app.js'
assert (base/'app.css').read_text() in html, 'Offline HTML contains stale CSS'
assert '<script src=' not in html and '<link rel="stylesheet"' not in html
print('PASS standalone HTML contains byte-identical inline JS/CSS')

launcher = (windows/'main.go').read_text()
assert 'X-Neon-Build' in launcher and 'contentFingerprint' in launcher
assert (windows/'main_test.go').is_file()
assert 'same_version_stale_build_check' in (root/'qa/verify_desktop_runtime.py').read_text()
print('PASS desktop build fingerprint and stale-process regression guard present')
print('PASS complete cross-platform preflight')
